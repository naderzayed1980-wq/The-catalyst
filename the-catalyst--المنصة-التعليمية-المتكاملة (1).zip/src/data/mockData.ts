import {
  User,
  UserRole,
  Subject,
  Course,
  Unit,
  Lesson,
  Assignment,
  AssignmentSubmission,
  Quiz,
  QuizAttempt,
  ForumPost,
  DirectMessage,
  EducationalResource,
  GlossaryTerm,
  SystemLog,
  SystemNotification,
  PromotionCampaign,
  AttendanceRecord
} from "../types";

export const defaultUsers: User[] = [
  {
    id: "admin-nader",
    name: "م. نادر زايد",
    email: "naderzayed1980@gmail.com",
    role: UserRole.ADMIN,
    avatar: "https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=200",
    phone: "01012345678",
    password: "74@ 1986"
  },
  {
    id: "teacher-1",
    name: "أ. أحمد كمال (فيزياء)",
    email: "ahmed.kamal@manara.com",
    role: UserRole.TEACHER,
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200",
    phone: "01122334455",
    specialization: "الفيزياء والعلوم الحديثة",
    password: "123456"
  },
  {
    id: "teacher-2",
    name: "أ. سارة أحمد (رياضيات)",
    email: "sara.ahmed@manara.com",
    role: UserRole.TEACHER,
    avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=200",
    phone: "01233445566",
    specialization: "الرياضيات البحتة والتطبيقية",
    password: "123456"
  },
  {
    id: "student-1",
    name: "يوسف محمد المنشاوي",
    email: "youssef@student.com",
    role: UserRole.STUDENT,
    avatar: "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=200",
    phone: "01555554433",
    parentId: "parent-1",
    password: "123456"
  },
  {
    id: "student-2",
    name: "مريم أحمد كمال",
    email: "maryam@student.com",
    role: UserRole.STUDENT,
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200",
    phone: "01555554422",
    parentId: "parent-2",
    password: "123456"
  },
  {
    id: "parent-1",
    name: "م. محمد المنشاوي",
    email: "parent@manara.com",
    role: UserRole.PARENT,
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200",
    phone: "01009988776",
    childrenIds: ["student-1"],
    password: "123456"
  },
  {
    id: "parent-2",
    name: "أ. أحمد كمال",
    email: "parent2@manara.com",
    role: UserRole.PARENT,
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=200",
    phone: "01009988775",
    childrenIds: ["student-2"],
    password: "123456"
  }
];

export const initialAttendance: AttendanceRecord[] = [
  {
    id: "att-1",
    studentId: "student-1",
    studentName: "يوسف محمد المنشاوي",
    date: "2026-07-08",
    status: "PRESENT",
    checkInTime: "08:15 AM",
    checkOutTime: "02:30 PM"
  },
  {
    id: "att-2",
    studentId: "student-2",
    studentName: "مريم أحمد كمال",
    date: "2026-07-08",
    status: "PRESENT",
    checkInTime: "08:30 AM",
    checkOutTime: "02:15 PM"
  },
  {
    id: "att-3",
    studentId: "student-2",
    studentName: "مريم أحمد كمال",
    date: "2026-07-09",
    status: "ABSENT",
    notifiedParent: false
  }
];


export const initialSubjects: Subject[] = [
  {
    id: "sub-1",
    name: "الفيزياء الثانوية العامة",
    description: "شرح شامل لمنهج الفيزياء للثانوية العامة يتضمن الميكانيكا، الكهربية الحديثة، والمغناطيسية.",
    image: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?auto=format&fit=crop&q=80&w=600",
    teacherId: "teacher-1",
    code: "PHY-3"
  },
  {
    id: "sub-2",
    name: "الرياضيات التطبيقية",
    description: "دراسة متعمقة في التفاضل والتكامل، الجبر الخطي، والهندسة الفراغية.",
    image: "https://images.unsplash.com/photo-1635070040809-906471e48f7d?auto=format&fit=crop&q=80&w=600",
    teacherId: "teacher-2",
    code: "MATH-3"
  }
];

export const initialCourses: Course[] = [
  {
    id: "crs-1",
    name: "دورة العلوم الهندسية المتكاملة",
    description: "دورة متكاملة تهدف إلى تأهيل الطلاب للقبول بكليات الهندسة، تغطي منهج الفيزياء للثانوية العامة والرياضيات التطبيقية بكافة فروعها.",
    code: "ENG-SCI",
    subjectIds: ["sub-1", "sub-2"],
    teacherIds: ["teacher-1", "teacher-2"],
    createdAt: "2026-07-01T10:00:00Z"
  },
  {
    id: "crs-2",
    name: "دورة الفيزياء المتقدمة للمتفوقين",
    description: "دورة مكثفة تركز على حل المسائل الصعبة وأسئلة الفهم العالي لمادة الفيزياء وتدريب الطلاب على أنماط الامتحانات الحديثة.",
    code: "ADV-PHY",
    subjectIds: ["sub-1"],
    teacherIds: ["teacher-1"],
    createdAt: "2026-07-03T14:30:00Z"
  }
];

export const initialUnits: Unit[] = [
  // Physics Units
  {
    id: "unit-1",
    subjectId: "sub-1",
    title: "الباب الأول: التيار الكهربي وقانون أوم",
    description: "شرح مفاهيم التيار الكهربي، المقاومة الكهربية، وقوانين كيرشوف بالتفصيل.",
    order: 1
  },
  {
    id: "unit-2",
    subjectId: "sub-1",
    title: "الباب الثاني: التأثير المغناطيسي للتيار الكهربي",
    description: "دراسة المجال المغناطيسي الناشئ عن مرور تيار كهربي وأجهزة القياس الكهربي.",
    order: 2
  },
  // Math Units
  {
    id: "unit-3",
    subjectId: "sub-2",
    title: "الباب الأول: التفاضل والتكامل المتقدم",
    description: "دراسة مشتقات الدوال المثلثية واللوغاريتمية وتطبيقات المعدلات الزمنية المرتبطة.",
    order: 1
  }
];

export const initialLessons: Lesson[] = [
  // Physics Unit 1 Lessons
  {
    id: "les-1",
    unitId: "unit-1",
    subjectId: "sub-1",
    title: "الدرس الأول: مفهوم التيار الكهربي وفرق الجهد",
    content: "### مفهوم التيار الكهربي\n\nالتيار الكهربي هو فيض من الشحنات الكهربية (الإلكترونات الحرة) التي تسري خلال موصل معدني.\n\n#### اتجاه التيار الكهربي:\n1. **الاتجاه التقليدي (الاصطلاحي):** حركة الشحنات الموجبة من القطب الموجب إلى القطب السالب خارج المصدر.\n2. **الاتجاه الفعلي (الإلكتروني):** حركة الإلكترونات من القطب السالب إلى القطب الموجب خارج المصدر.\n\n### شدة التيار الكهربي (I):\nهي كمية الشحنة الكهربية المارة عبر مقطع من موصل في زمن قدره ثانية واحدة.\n*القانون:* `I = Q / t`\n*وحدة القياس:* الأمبير (A) ويساوي كولوم/ثانية.\n\n### فرق الجهد الكهربي (V):\nهو مقدار الشغل المبذول لنقل شحنة كهربية قدرها 1 كولوم بين نقطتين.\n*القانون:* `V = W / Q`\n*وحدة القياس:* الفولت (V) ويساوي جول/كولوم.\n\n### قانون أوم:\nعند ثبوت درجة الحرارة، تتناسب شدة التيار المار في موصل طردياً مع فرق الجهد بين طرفيه.\n*القانون:* `V = I * R` حيث R هي المقاومة الكهربية للموصل وتقاس بالأوم.",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ", // Simulated embed
    pdfName: "ملخص_التيار_الكهربي_وقانون_أوم.pdf",
    pdfUrl: "#",
    order: 1,
    duration: "45 دقيقة"
  },
  {
    id: "les-2",
    unitId: "unit-1",
    subjectId: "sub-1",
    title: "الدرس الثاني: توصيل المقاومات على التوالي والتوازي",
    content: "### توصيل المقاومات الكهربية\n\nتوجد طريقتان رئيسيتان لتوصيل المقاومات في الدوائر الكهربية:\n\n#### 1. التوصيل على التوالي (Series Connection):\n* **الغرض منه:** الحصول على مقاومة كبيرة من مجموعة مقاومات صغيرة.\n* **خصائص الدائرة:**\n  - شدة التيار ثابتة في جميع المقاومات: `I_total = I1 = I2 = I3`\n  - فرق الجهد الكلي يتجزأ: `V_total = V1 + V2 + V3`\n  - المقاومة المكافئة (R_eq): `R_eq = R1 + R2 + R3`\n\n#### 2. التوصيل على التوازي (Parallel Connection):\n* **الغرض منه:** الحصول على مقاومة صغيرة من مجموعة مقاومات كبيرة، وتوصيل الأجهزة المنزلية.\n* **خصائص الدائرة:**\n  - فرق الجهد ثابت بين طرفي جميع المقاومات: `V_total = V1 = V2 = V3`\n  - شدة التيار الكلية تتجزأ: `I_total = I1 + I2 + I3`\n  - مقلوب المقاومة المكافئة: `1/R_eq = 1/R1 + 1/R2 + 1/R3`",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    pdfName: "تمارين_توصيل_المقاومات.pdf",
    pdfUrl: "#",
    order: 2,
    duration: "50 دقيقة"
  },
  // Math Unit 1 Lessons
  {
    id: "les-3",
    unitId: "unit-3",
    subjectId: "sub-2",
    title: "الدرس الأول: اشتقاق الدوال المثلثية المقلوبة والأسية",
    content: "### مشتقات الدوال الأسية واللوغاريتمية\n\nتعتبر الدوال الأسية واللوغاريتمية أساسية في حساب التفاضل المتقدم.\n\n#### 1. مشتقة الدالة الأسية الطبيعية:\nإذا كانت `y = e^x` فإن مشتقتها `dy/dx = e^x`.\nوإذا كانت الدالة مركبة `y = e^f(x)` فإن المشتة هي: `dy/dx = f'(x) * e^f(x)`.\n\n#### 2. مشتقة الدالة اللوغاريتمية الطبيعية:\nإذا كانت `y = ln(x)` فإن مشتقتها `dy/dx = 1/x`.\nوإذا كانت الدالة مركبة `y = ln(f(x))` فإن المشتقة هي: `dy/dx = f'(x) / f(x)`.\n\n### تطبيقات عملية:\nتستخدم هذه المشتقات لحساب معدلات النمو السكاني، التحلل الإشعاعي، وحساب المساحات المعقدة تحت المنحنيات.",
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ",
    pdfName: "قوانين_التفاضل_الكاملة.pdf",
    pdfUrl: "#",
    order: 1,
    duration: "40 دقيقة"
  }
];

export const initialAssignments: Assignment[] = [
  {
    id: "assign-1",
    lessonId: "les-1",
    subjectId: "sub-1",
    title: "واجب الدرس الأول: قانون أوم والمقاومة النوعية",
    description: "قم بحل المسائل التالية بالتفصيل موضحاً خطوات الحل والقوانين المستخدمة.",
    questions: [
      {
        id: "q-1",
        type: "MULTIPLE_CHOICE",
        questionText: "إذا زاد طول سلك معدني إلى الضعف وقلت مساحة مقطعه إلى النصف، فإن مقاومته الكهربية:",
        options: [
          "تزداد إلى الضعف",
          "تزداد إلى أربعة أمثالها",
          "تقل إلى النصف",
          "تظل ثابتة"
        ],
        correctAnswer: "تزداد إلى أربعة أمثالها"
      },
      {
        id: "q-2",
        type: "SHORT_ANSWER",
        questionText: "احسب المقاومة المكافئة لسلك طوله 10م ومساحة مقطعه 2x10^-6 م^2 ومقاومته النوعية 5x10^-7 أوم.متر؟",
        correctAnswer: "2.5 أوم"
      }
    ],
    dueDate: "2026-07-15"
  },
  {
    id: "assign-2",
    lessonId: "les-2",
    subjectId: "sub-1",
    title: "واجب الدرس الثاني: توصيل المقاومات والتجزئة",
    description: "تطبيق على قوانين التوالي والتوازي وتوزيع التيارات والجهود.",
    questions: [
      {
        id: "q-3",
        type: "MULTIPLE_CHOICE",
        questionText: "عند توصيل ثلاث مقاومات متساوية على التوازي تكون المقاومة المكافئة لها:",
        options: [
          "ثلث قيمة المقاومة الواحدة",
          "ثلاثة أمثال المقاومة الواحدة",
          "مساوية للمقاومة الواحدة",
          "أكبر من أكبر مقاومة"
        ],
        correctAnswer: "ثلث قيمة المقاومة الواحدة"
      }
    ],
    dueDate: "2026-07-20"
  }
];

export const initialSubmissions: AssignmentSubmission[] = [
  {
    id: "subm-1",
    assignmentId: "assign-1",
    studentId: "student-1",
    answers: [
      {
        questionId: "q-1",
        answerText: "تزداد إلى أربعة أمثالها"
      },
      {
        questionId: "q-2",
        answerText: "المقاومة = المقاومة النوعية * (الطول / المساحة) = 5x10^-7 * (10 / 2x10^-6) = 2.5 أوم. الإجابة النهائية هي 2.5 أوم"
      }
    ],
    status: "GRADED",
    grade: 95,
    feedback: "حل ممتاز ومنظم جداً! خطوات واضحة ومقنعة. استمر في هذا الأداء الرائع.",
    submittedAt: "2026-07-07T18:30:00Z"
  }
];

export const initialQuizzes: Quiz[] = [
  {
    id: "quiz-1",
    subjectId: "sub-1",
    title: "الاختبار القصير الأول: أساسيات الكهربية وقانون أوم",
    durationMinutes: 10,
    questions: [
      {
        id: "qq-1",
        questionText: "جهاز الأمبير يتصل في الدوائر الكهربية على:",
        options: [
          "التوالي وبمقاومة كبيرة جداً",
          "التوالي وبمقاومة صغيرة جداً",
          "التوازي وبمقاومة كبيرة جداً",
          "التوازي وبمقاومة صغيرة جداً"
        ],
        correctAnswerIndex: 1,
        explanation: "يتصل الأميتر على التوالي لقياس شدة التيار المار في الدائرة كاملة، ويجب أن تكون مقاومته صغيرة جداً حتى لا يؤثر على شدة التيار الكلي المقاس."
      },
      {
        id: "qq-2",
        questionText: "إذا كانت مقاومة موصل هي 10 أوم، ومر به تيار شدته 1 أمبير، فإذا زاد التيار إلى 2 أمبير، فإن مقاومة الموصل تصبح:",
        options: [
          "5 أوم",
          "10 أوم",
          "20 أوم",
          "40 أوم"
        ],
        correctAnswerIndex: 1,
        explanation: "المقاومة خاصية هندسية وفيزيائية للموصل (تعتمد على الطول والمساحة ونوع المادة ودرجة الحرارة) ولا تتأثر بتغير شدة التيار أو فرق الجهد المار بها."
      },
      {
        id: "qq-3",
        questionText: "تقاس كمية الشحنة الكهربية بوحدة:",
        options: [
          "الفولت",
          "الأوم",
          "الكولوم",
          "الأمبير"
        ],
        correctAnswerIndex: 2,
        explanation: "الكولوم هو وحدة قياس كمية الكهربية أو كمية الشحنة الكهربية."
      }
    ]
  }
];

export const initialQuizAttempts: QuizAttempt[] = [
  {
    id: "attempt-1",
    quizId: "quiz-1",
    studentId: "student-1",
    score: 100,
    answers: [1, 1, 2], // All correct
    completedAt: "2026-07-06T15:45:00Z"
  }
];

export const initialForumPosts: ForumPost[] = [
  {
    id: "post-1",
    title: "سؤال بخصوص اتجاه التيار الكهربي الفعلي والتقليدي؟",
    content: "يا شباب، متى نستخدم الاتجاه التقليدي للتيار الكهربي ومتى نستخدم الاتجاه الفعلي في حل المسائل؟ أشعر ببعض التشتت عند رسم الدوائر المعقدة.",
    authorId: "student-1",
    authorName: "يوسف محمد المنشاوي",
    authorRole: UserRole.STUDENT,
    subjectId: "sub-1",
    replies: [
      {
        id: "rep-1",
        content: "مرحباً يوسف. في جميع المسائل والدوائر الكهربائية وقوانين كيرشوف، نعتمد دائماً على 'الاتجاه التقليدي' (من القطب الموجب إلى السالب خارج البطارية) إلا إذا نصت المسألة صراحة على أن الاتجاه إلكتروني أو فعلي.",
        authorId: "teacher-1",
        authorName: "أ. أحمد كمال (فيزياء)",
        authorRole: UserRole.TEACHER,
        createdAt: "2026-07-07T12:00:00Z"
      }
    ],
    createdAt: "2026-07-07T10:30:00Z"
  }
];

export const initialDirectMessages: DirectMessage[] = [
  {
    id: "dm-1",
    senderId: "student-1",
    receiverId: "teacher-1",
    content: "السلام عليكم يا أستاذنا، هل هناك مراجعة إضافية لمسائل كيرشوف هذا الأسبوع؟",
    createdAt: "2026-07-07T09:00:00Z",
    read: true
  },
  {
    id: "dm-2",
    senderId: "teacher-1",
    receiverId: "student-1",
    content: "وعليكم السلام يا يوسف. نعم، سأقوم برفع كتيب مسائل محلولة وبنك أسئلة مخصص لكيرشوف في قسم الموارد الإضافية مساء اليوم إن شاء الله.",
    createdAt: "2026-07-07T11:15:00Z",
    read: false
  },
  {
    id: "dm-3",
    senderId: "parent-1",
    receiverId: "teacher-1",
    content: "مرحباً أستاذ أحمد، أود الاستفسار عن مستوى يوسف في الفيزياء، هل لاحظت أي تحسن؟",
    createdAt: "2026-07-06T14:20:00Z",
    read: true
  },
  {
    id: "dm-4",
    senderId: "teacher-1",
    receiverId: "parent-1",
    content: "أهلاً بك يا باشمهندس محمد. يوسف طالب ممتاز وملتزم جداً، درجاته في الاختبارات القصيرة والواجبات ممتازة وحصل مؤخراً على 100% في الاختبار القصير الأول. مستواه مطمئن جداً.",
    createdAt: "2026-07-06T16:30:00Z",
    read: true
  }
];

export const initialResources: EducationalResource[] = [
  {
    id: "res-1",
    title: "كتاب الفيزياء الأساسية - المرجع الكامل للطلاب",
    type: "BOOK",
    category: "الفيزياء",
    url: "https://example.com/physics-book",
    description: "مرجع علمي شامل مبسط لتفسير ظواهر الكهربية والحديثة بالصور والرسوم التوضيحية."
  },
  {
    id: "res-2",
    title: "محاكاة تفاعلية لحركة الإلكترونات وقانون أوم",
    type: "EXTERNAL_LINK",
    category: "الفيزياء",
    url: "https://phet.colorado.edu/ar/",
    description: "موقع PHET للمحاكاة التفاعلية - ممتاز لفهم توصيل المقاومات وقانون أوم بشكل مرئي."
  },
  {
    id: "res-3",
    title: "سلسلة محاضرات التفاضل المتقدم على اليوتيوب",
    type: "VIDEO",
    category: "الرياضيات",
    url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    description: "شرح مرئي بالفيديو لقواعد الاشتقاق والنهايات والتكامل المتقدم مع أمثلة عملية."
  }
];

export const initialGlossary: GlossaryTerm[] = [
  {
    id: "gl-1",
    term: "المقاومة الكهربية (Electrical Resistance)",
    definition: "الممانعة التي يلقاها التيار الكهربي (الإلكترونات) أثناء مروره في الموصل نتيجة التصادمات والاحتكاك.",
    subjectId: "sub-1"
  },
  {
    id: "gl-2",
    term: "المقاومة النوعية (Resistivity)",
    definition: "مقاومة موصل طوله 1 متر ومساحة مقطعه 1 متر مربع عند درجة حرارة معينة، وهي صفة مميزة للمادة.",
    subjectId: "sub-1"
  },
  {
    id: "gl-3",
    term: "المشتقة الأولى (First Derivative)",
    definition: "ميل مماس المنحنى عند أي نقطة عليه، ويعبر عن معدل تغير الدالة بالنسبة للمتغير المستقل.",
    subjectId: "sub-2"
  }
];

export const initialPromotions: PromotionCampaign[] = [
  {
    id: "promo-1",
    title: "بادر بالتسجيل في معسكر الفيزياء الصيفي المكثف!",
    description: "مراجعة كاملة للبابين الأول والثاني مع حل 500 مسألة متوقعة في امتحانات الثانوية العامة بخصم 30%.",
    imageUrl: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=600",
    linkUrl: "#",
    active: true
  },
  {
    id: "promo-2",
    title: "جديد: دورة التأسيس الرياضي لطلاب المرحلة الثانوية",
    description: "تعلم المهارات الرياضية الأساسية اللازمة لفهم التفاضل والتكامل والفيزياء بسهولة ويسر.",
    imageUrl: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?auto=format&fit=crop&q=80&w=600",
    linkUrl: "#",
    active: true
  }
];

export const initialNotifications: SystemNotification[] = [
  {
    id: "not-1",
    title: "واجب جديد متاح",
    message: "أضافت أ. سارة أحمد واجباً جديداً لمادة الرياضيات التطبيقية: واجب الدرس الأول.",
    targetRole: UserRole.STUDENT,
    createdAt: "2026-07-08T03:00:00Z",
    read: false
  },
  {
    id: "not-2",
    title: "تنبيه هام للآباء",
    message: "تم تحديث درجات الطلاب في الاختبار القصير الأول لمادة الفيزياء. يرجى الاطلاع على تقرير التقدم.",
    targetRole: UserRole.PARENT,
    createdAt: "2026-07-07T16:00:00Z",
    read: false
  },
  {
    id: "not-3",
    title: "صيانة مجدولة للنظام",
    message: "نحيطكم علماً بأنه سيتم إجراء صيانة دورية للنظام يوم الجمعة القادم الساعة 2 صباحاً لمدة ساعة.",
    createdAt: "2026-07-07T08:00:00Z",
    read: false
  }
];

export const initialLogs: SystemLog[] = [
  {
    id: "log-1",
    userId: "admin-1",
    userName: "أ. عبد الرحمن المنشاوي",
    userRole: UserRole.ADMIN,
    action: "تعديل إعدادات النظام",
    details: "تحديث الشعار والاسم التجاري للمنصة التعليمية",
    timestamp: "2026-07-08T01:30:00Z"
  },
  {
    id: "log-2",
    userId: "teacher-1",
    userName: "أ. أحمد كمال (فيزياء)",
    userRole: UserRole.TEACHER,
    action: "رفع مادة علمية",
    details: "إضافة الدرس الثاني وتضمين ملف PDF للمقاومات",
    timestamp: "2026-07-07T11:20:00Z"
  },
  {
    id: "log-3",
    userId: "student-1",
    userName: "يوسف محمد المنشاوي",
    userRole: UserRole.STUDENT,
    action: "تسليم واجب دراسي",
    details: "تسليم إجابات واجب الدرس الأول في الفيزياء",
    timestamp: "2026-07-07T18:30:00Z"
  },
  {
    id: "log-4",
    userId: "teacher-1",
    userName: "أ. أحمد كمال (فيزياء)",
    userRole: UserRole.TEACHER,
    action: "تقييم واجب",
    details: "رصد درجة الطالب يوسف محمد المنشاوي في واجب الدرس الأول (95/100)",
    timestamp: "2026-07-07T19:00:00Z"
  }
];
