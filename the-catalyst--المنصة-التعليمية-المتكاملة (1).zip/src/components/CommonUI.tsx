import React, { useState } from "react";
import { 
  BookOpen, 
  Bell, 
  MessageSquare, 
  User as UserIcon, 
  ChevronDown, 
  Sparkles, 
  Send, 
  X, 
  Activity, 
  Volume2, 
  ArrowLeft,
  Check,
  Smartphone,
  ShieldCheck,
  TrendingUp,
  Sun,
  Moon,
  LogOut,
  Globe
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { User, UserRole, DirectMessage, SystemNotification, PromotionCampaign } from "../types";

// Helper function for nice Arabic relative time
export const formatArabicTime = (dateStr: string) => {
  const diffMs = new Date().getTime() - new Date(dateStr).getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffMins < 1) return "الآن";
  if (diffMins < 60) return `منذ ${diffMins} دقيقة`;
  if (diffHours < 24) {
    if (diffHours === 1) return "منذ ساعة";
    if (diffHours === 2) return "منذ ساعتين";
    return `منذ ${diffHours} ساعات`;
  }
  if (diffDays === 1) return "أمس";
  if (diffDays === 2) return "منذ يومين";
  return `منذ ${diffDays} أيام`;
};

interface HeaderProps {
  currentUser: User;
  onRoleChange: (role: UserRole) => void;
  notifications: SystemNotification[];
  onMarkNotificationRead: (id: string) => void;
  onOpenChat: () => void;
  unreadMessagesCount: number;
  isDarkMode?: boolean;
  onToggleDarkMode?: () => void;
  onLogout?: () => void;
  language?: "ar" | "en";
  onToggleLanguage?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  onRoleChange,
  notifications,
  onMarkNotificationRead,
  onOpenChat,
  unreadMessagesCount,
  isDarkMode = false,
  onToggleDarkMode,
  onLogout,
  language = "ar",
  onToggleLanguage
}) => {
  const [showRoleMenu, setShowRoleMenu] = useState(false);
  const [showNotifMenu, setShowNotifMenu] = useState(false);

  const isAr = language === "ar";
  const unreadNotifs = notifications.filter(n => !n.read);

  const getRoleLabel = (role: UserRole) => {
    switch (role) {
      case UserRole.ADMIN: return { label: isAr ? "مدير النظام" : "System Admin", color: "bg-red-50 text-red-600 border-red-200 dark:bg-red-950/40 dark:text-red-400 dark:border-red-900/50" };
      case UserRole.TEACHER: return { label: isAr ? "معلم المادة" : "Teacher", color: "bg-indigo-50 text-indigo-600 border-indigo-200 dark:bg-indigo-950/40 dark:text-indigo-400 dark:border-indigo-900/50" };
      case UserRole.STUDENT: return { label: isAr ? "طالب علم" : "Student", color: "bg-emerald-50 text-emerald-600 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-400 dark:border-emerald-900/50" };
      case UserRole.PARENT: return { label: isAr ? "ولي الأمر" : "Parent / Guardian", color: "bg-amber-50 text-amber-600 border-amber-200 dark:bg-amber-950/40 dark:text-amber-400 dark:border-amber-900/50" };
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-gray-100 bg-white/95 backdrop-blur-md dark:bg-slate-900/95 dark:border-slate-800 transition-colors duration-300" id="header-main">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        
        {/* Logo and Platform Name */}
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white shadow-md shadow-emerald-100 dark:shadow-none shrink-0">
            <BookOpen className="h-5 w-5" />
          </div>
          <div className={isAr ? "text-right" : "text-left"}>
            <h1 className="font-sans text-xl font-bold tracking-tight text-gray-900 dark:text-white">The Catalyst</h1>
            <p className="font-mono text-[9px] text-gray-400 dark:text-slate-400">
              {isAr ? "المنصة التعليمية المتكاملة" : "The Integrated Education Hub"}
            </p>
          </div>
        </div>

        {/* Current Role Indicator & Switcher Tool */}
        <div className="hidden md:flex items-center gap-2 rounded-lg bg-gray-50 p-1 border border-gray-100 dark:bg-slate-850 dark:border-slate-800">
          <span className="px-3 py-1 font-sans text-xs text-gray-500 dark:text-slate-400">
            {isAr ? "مظهر الحساب:" : "Role View:"}
          </span>
          <div className="relative">
            <button 
              onClick={() => setShowRoleMenu(!showRoleMenu)}
              className={`flex items-center gap-2 rounded-md border px-3 py-1 font-sans text-xs font-medium cursor-pointer transition-all ${getRoleLabel(currentUser.role).color}`}
              id="role-switcher-btn"
            >
              {getRoleLabel(currentUser.role).label}
              <ChevronDown className="h-3 w-3" />
            </button>

            <AnimatePresence>
              {showRoleMenu && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setShowRoleMenu(false)} />
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className={`absolute ${isAr ? "left-0" : "right-0"} mt-2 w-48 origin-top-left rounded-xl border border-gray-100 bg-white p-1 shadow-xl ring-1 ring-black/5 z-50 dark:bg-slate-900 dark:border-slate-800`}
                  >
                    <div className="px-3 py-1.5 border-b border-gray-50 mb-1 dark:border-slate-800">
                      <p className={`font-sans text-[10px] text-gray-400 font-medium dark:text-slate-400 ${isAr ? "text-right" : "text-left"}`}>
                        {isAr ? "تبديل دور المستخدم للمعاينة" : "Switch user role for testing"}
                      </p>
                    </div>
                    {Object.values(UserRole).map((role) => (
                      <button
                        key={role}
                        onClick={() => {
                          onRoleChange(role);
                          setShowRoleMenu(false);
                        }}
                        className={`flex w-full items-center justify-between rounded-lg px-3 py-2 font-sans text-xs hover:bg-gray-50 transition-colors cursor-pointer dark:hover:bg-slate-800 ${isAr ? "text-right" : "text-left"} ${currentUser.role === role ? 'font-semibold text-emerald-600 bg-emerald-50/50 dark:bg-emerald-950/30 dark:text-emerald-400' : 'text-gray-700 dark:text-slate-300'}`}
                      >
                        <span>{getRoleLabel(role).label}</span>
                        {currentUser.role === role && <Check className="h-3 w-3 shrink-0" />}
                      </button>
                    ))}
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Action Controls & Notifications */}
        <div className="flex items-center gap-2 sm:gap-4">
          
          {/* Globe Language Toggle Switch */}
          {onToggleLanguage && (
            <button
              onClick={onToggleLanguage}
              className="flex h-10 px-2.5 items-center justify-center gap-1 rounded-xl border border-gray-100 bg-white text-gray-600 transition-all hover:bg-gray-50 hover:text-emerald-600 shadow-sm cursor-pointer dark:bg-slate-900 dark:border-slate-800 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-emerald-400"
              title={isAr ? "English" : "العربية"}
              id="language-toggle-btn"
            >
              <Globe className="h-4 w-4 shrink-0" />
              <span className="font-sans text-[10px] font-bold tracking-tight">{isAr ? "EN" : "العربية"}</span>
            </button>
          )}

          {/* Dark/Light Mode Toggle Switch */}
          <button
            onClick={onToggleDarkMode}
            className="flex h-10 w-10 items-center justify-center rounded-xl border border-gray-100 bg-white text-gray-600 transition-all hover:bg-gray-50 hover:text-emerald-600 shadow-sm cursor-pointer dark:bg-slate-900 dark:border-slate-800 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-emerald-400"
            title={isAr ? (isDarkMode ? "الوضع الفاتح" : "الوضع المظلم") : (isDarkMode ? "Light Mode" : "Dark Mode")}
            id="dark-mode-toggle-btn"
          >
            {isDarkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </button>

          {/* Direct Messages Shortcut */}
          <button 
            onClick={onOpenChat}
            className="relative flex h-10 w-10 items-center justify-center rounded-xl border border-gray-100 bg-white text-gray-600 transition-all hover:bg-gray-50 hover:text-emerald-600 shadow-sm cursor-pointer dark:bg-slate-900 dark:border-slate-800 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-emerald-400"
            title={isAr ? "الرسائل المباشرة" : "Direct Messages"}
            id="messages-shortcut-btn"
          >
            <MessageSquare className="h-5 w-5" />
            {unreadMessagesCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-emerald-500 text-[10px] font-bold text-white ring-2 ring-white">
                {unreadMessagesCount}
              </span>
            )}
          </button>

          {/* Notifications Dropdown */}
          <div className="relative">
            <button 
              onClick={() => setShowNotifMenu(!showNotifMenu)}
              className="relative flex h-10 w-10 items-center justify-center rounded-xl border border-gray-100 bg-white text-gray-600 transition-all hover:bg-gray-50 hover:text-emerald-600 shadow-sm cursor-pointer dark:bg-slate-900 dark:border-slate-800 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-emerald-400"
              title={isAr ? "الإشعارات" : "Notifications"}
              id="notifications-shortcut-btn"
            >
              <Bell className="h-5 w-5" />
              {unreadNotifs.length > 0 && (
                <span className="absolute -top-1.5 -right-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[9px] font-bold text-white ring-2 ring-white animate-pulse">
                  {unreadNotifs.length}
                </span>
              )}
            </button>

            <AnimatePresence>
              {showNotifMenu && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setShowNotifMenu(false)} />
                  <motion.div
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 15 }}
                    className={`absolute ${isAr ? "left-0" : "right-0"} mt-3 w-80 max-h-96 overflow-y-auto origin-top-left rounded-2xl border border-gray-100 bg-white p-2 shadow-xl ring-1 ring-black/5 z-50 scrollbar-thin dark:bg-slate-900 dark:border-slate-800`}
                  >
                    <div className={`flex items-center justify-between border-b border-gray-50 px-3 py-2.5 mb-1.5 dark:border-slate-850 ${isAr ? "flex-row-reverse" : "flex-row"}`}>
                      <span className="font-sans text-xs font-semibold text-gray-900 dark:text-white">
                        {isAr ? "آخر التنبيهات والأخبار" : "Latest Notifications"}
                      </span>
                      {unreadNotifs.length > 0 && (
                        <span className="rounded-full bg-red-50 px-2 py-0.5 font-sans text-[10px] font-medium text-red-600 dark:bg-red-950/50 dark:text-red-400">
                          {unreadNotifs.length} {isAr ? "غير مقروء" : "unread"}
                        </span>
                      )}
                    </div>

                    {notifications.length === 0 ? (
                      <p className="px-4 py-8 text-center font-sans text-xs text-gray-400">
                        {isAr ? "لا توجد تنبيهات حالياً" : "No notifications yet"}
                      </p>
                    ) : (
                      <div className="space-y-1">
                        {notifications.map((notif) => (
                          <div 
                            key={notif.id} 
                            onClick={() => onMarkNotificationRead(notif.id)}
                            className={`flex flex-col rounded-xl p-3 font-sans transition-colors cursor-pointer dark:hover:bg-slate-800/50 ${isAr ? "text-right" : "text-left"} ${notif.read ? 'hover:bg-gray-50 text-gray-600 dark:text-slate-300' : 'bg-emerald-50/20 hover:bg-emerald-50/30 text-gray-900 dark:text-white border-r-4 border-emerald-500 dark:bg-emerald-950/20'}`}
                          >
                            <div className={`flex items-center justify-between mb-1 ${isAr ? "flex-row-reverse" : "flex-row"}`}>
                              <span className="font-medium text-xs">{notif.title}</span>
                              <span className="font-mono text-[9px] text-gray-400 dark:text-slate-500">{formatArabicTime(notif.createdAt)}</span>
                            </div>
                            <p className="text-[11px] text-gray-500 dark:text-slate-400 leading-relaxed">{notif.message}</p>
                          </div>
                        ))}
                      </div>
                    )}
                  </motion.div>
                </>
              )}
            </AnimatePresence>
          </div>

          {/* Profile Quick view */}
          <div className="flex items-center gap-2 border-r border-gray-100 dark:border-slate-800 pr-3 mr-1">
            <img 
              src={currentUser.avatar} 
              alt={currentUser.name} 
              className="h-9 w-9 rounded-full object-cover border border-emerald-100 dark:border-slate-800 shrink-0"
              referrerPolicy="no-referrer"
            />
            <div className={`hidden lg:flex flex-col ${isAr ? "text-right" : "text-left"}`}>
              <span className="font-sans text-xs font-semibold text-gray-900 dark:text-white">{currentUser.name}</span>
              <span className="font-mono text-[10px] text-gray-400 dark:text-slate-400">{currentUser.email}</span>
            </div>
            {onLogout && (
              <button
                onClick={onLogout}
                className="flex h-8 w-8 items-center justify-center rounded-lg bg-red-50 hover:bg-red-100 text-red-600 transition-all cursor-pointer dark:bg-red-950/20 dark:text-red-400 dark:hover:bg-red-950/40 mr-1.5 shrink-0"
                title={isAr ? "تسجيل الخروج" : "Logout"}
                id="header-logout-btn"
              >
                <LogOut className="h-4 w-4" />
              </button>
            )}
          </div>

        </div>
      </div>

      {/* Mobile role switcher banner for convenience */}
      <div className="md:hidden flex items-center justify-between bg-gray-50 border-t border-b border-gray-100 dark:bg-slate-900 dark:border-slate-800 px-4 py-2">
        <span className="font-sans text-[10px] text-gray-500 font-medium dark:text-slate-400">
          {isAr ? "مظهر الحساب للمعاينة:" : "Preview Role:"}
        </span>
        <div className="flex gap-1.5 flex-wrap">
          {Object.values(UserRole).map((role) => (
            <button
              key={role}
              onClick={() => onRoleChange(role)}
              className={`rounded px-2 py-0.5 font-sans text-[10px] font-semibold transition-all border cursor-pointer ${currentUser.role === role ? 'bg-emerald-600 border-emerald-600 text-white' : 'bg-white border-gray-200 text-gray-600 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-300'}`}
            >
              {role === UserRole.ADMIN ? (isAr ? "مدير" : "Admin") : role === UserRole.TEACHER ? (isAr ? "معلم" : "Teacher") : role === UserRole.STUDENT ? (isAr ? "طالب" : "Student") : (isAr ? "ولي أمر" : "Parent")}
            </button>
          ))}
        </div>
      </div>
    </header>
  );
};


/* AI Assistant Chat Widget */
interface AIChatbotProps {
  studentName?: string;
}

export const AIChatbot: React.FC<AIChatbotProps> = ({ studentName = "يوسف" }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ id: string; sender: "USER" | "AI"; text: string; time: string }[]>([
    {
      id: "1",
      sender: "AI",
      text: `مرحباً بك يا ${studentName}! أنا The Catalyst AI، معلمك المساعد الذكي. كيف يمكنني مساعدتك اليوم في فهم الدروس، حل المسائل، أو تنظيم وقتك؟`,
      time: new Date().toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" })
    }
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);

  const predefinedResponses: { keywords: string[]; answer: string }[] = [
    {
      keywords: ["قانون أوم", "أوم", "مقاومة", "V =", "R ="],
      answer: "قانون أوم يمثل أساس الكهربية وهو يربط بين ثلاثة عناصر أساسية: فرق الجهد (V)، شدة التيار (I)، والمقاومة (R).\n\nالقانون الرياضي: V = I * R\n\n- إذا زاد فرق الجهد مع ثبوت المقاومة، تزداد شدة التيار طردياً.\n- إذا زادت المقاومة مع ثبوت فرق الجهد، تقل شدة التيار عكسياً.\n\nتذكر: المقاومة لا تتغير بتغير التيار أو الجهد بل تعتمد على أبعاد السلك والمادة!"
    },
    {
      keywords: ["كيرشوف", "قوانين كيرشوف", "كيرشوف الأول", "كيرشوف الثاني"],
      answer: "قوانين كيرشوف تستخدم لحل الدوائر الكهربية المعقدة التي لا يمكن حلها بقانون أوم العادي:\n\n1. **قانون كيرشوف الأول (قانون حفظ الشحنة):** مجموع التيارات الداخلة إلى نقطة تفرع يساوي مجموع التيارات الخارجة منها (ΣI_in = ΣI_out).\n\n2. **قانون كيرشوف الثاني (قانون حفظ الطاقة):** المجموع الجبري لفروق الجهد في أي مسار مغلق يساوي صفراً (ΣV = 0 أو ΣV_B = ΣI*R)."
    },
    {
      keywords: ["تفاضل", "اشتقاق", "ln", "أسية", "دوال أسية"],
      answer: "في التفاضل المتقدم:\n- مشتقة الدالة الأسية الطبيعية (e^x) هي نفسها e^x. وإذا كان الأس دالة f(x)، نضرب في مشتقة الأس: f'(x) * e^f(x).\n- مشتقة دالة اللوغاريتم الطبيعي ln(x) هي 1/x. وإذا كانت ln(f(x))، تكون المشتقة هي f'(x)/f(x)."
    },
    {
      keywords: ["امتحان", "اختبار", "مذاكرة", "وقت", "نصيحة", "تنظيم"],
      answer: "لتنظيم وقتك والتحضير للامتحانات بشكل ممتاز، أنصحك بالتالي:\n1. **قسّم وقتك:** ادرس لمدة 25 دقيقة ثم خذ استراحة 5 دقائق (طريقة البومودورو).\n2. **الممارسة العملية:** حل الكثير من الأسئلة والمسائل والواجبات بدلاً من القراءة فقط.\n3. **استعن بالملخصات:** قم بمراجعة ملخص الدرس PDF الموجود في صفحة المناهج قبل البدء في حل التدريبات."
    },
    {
      keywords: ["The Catalyst", "المنصة", "استخدام"],
      answer: "منصة The Catalyst هي تطبيق تعليمي شامل يمكنك من خلاله:\n- تصفح المناهج الدراسية، الوحدات والدروس المكتوبة والمصورة.\n- تقديم الواجبات المنزلية والحصول على تقييم فوري وتصحيح تفاعلي.\n- إجراء الاختبارات القصيرة والمحاكاة للامتحانات النهائية.\n- التواصل المباشر مع معلميك والمشاركة في منتدى النقاش وطرح الأسئلة الاستفسارية."
    }
  ];

  const handleSend = () => {
    if (!input.trim()) return;

    const userMsgText = input.trim();
    const newMsg = {
      id: Math.random().toString(),
      sender: "USER" as const,
      text: userMsgText,
      time: new Date().toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" })
    };

    setMessages(prev => [...prev, newMsg]);
    setInput("");
    setIsTyping(true);

    // AI logic response simulation
    setTimeout(() => {
      let aiText = "أعتذر منك، لم أفهم استفسارك بدقة. هل يمكنك استخدام كلمات مفتاحية مثل (قانون أوم، قوانين كيرشوف، قواعد التفاضل، كيفية استخدام المنصة، أو نصائح المذاكرة) لأتمكن من إجابتك بشكل علمي دقيق؟";
      
      const textLower = userMsgText.toLowerCase();
      for (const item of predefinedResponses) {
        if (item.keywords.some(keyword => textLower.includes(keyword))) {
          aiText = item.answer;
          break;
        }
      }

      setMessages(prev => [...prev, {
        id: Math.random().toString(),
        sender: "AI",
        text: aiText,
        time: new Date().toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" })
      }]);
      setIsTyping(false);
    }, 1200);
  };

  return (
    <>
      {/* Trigger floating button */}
      <button 
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-tr from-emerald-600 to-teal-500 text-white shadow-lg shadow-emerald-200 dark:shadow-none cursor-pointer hover:scale-105 active:scale-95 transition-all"
        id="ai-assistant-trigger"
      >
        <Sparkles className="h-6 w-6 animate-pulse" />
      </button>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 50 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 50 }}
            className="fixed bottom-24 right-6 z-50 w-80 sm:w-96 h-[480px] rounded-2xl border border-gray-100 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xl flex flex-col overflow-hidden"
            id="ai-assistant-window"
          >
            {/* Header */}
            <div className="bg-gradient-to-l from-emerald-600 to-teal-600 px-4 py-3 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/20 text-white">
                  <Sparkles className="h-4 w-4" />
                </div>
                <div className="text-right">
                  <h3 className="font-sans text-xs font-semibold">The Catalyst AI</h3>
                  <p className="font-sans text-[10px] text-emerald-100">المعلم والمساند الشخصي الذكي</p>
                </div>
              </div>
              <button 
                onClick={() => setIsOpen(false)}
                className="text-white hover:text-emerald-200 cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Messages Body */}
            <div className="flex-1 overflow-y-auto p-4 bg-gray-50/50 dark:bg-slate-950/50 space-y-4 scrollbar-thin flex flex-col-reverse">
              <div className="space-y-4">
                {messages.map((msg) => (
                  <div 
                    key={msg.id} 
                    className={`flex flex-col max-w-[85%] ${msg.sender === "USER" ? "mr-auto items-start" : "ml-auto items-end"}`}
                  >
                    <div className={`rounded-2xl p-3 font-sans text-xs leading-relaxed text-right ${msg.sender === "USER" ? "bg-emerald-600 text-white rounded-tl-none" : "bg-white dark:bg-slate-800 text-gray-800 dark:text-slate-100 border border-gray-100 dark:border-slate-750 rounded-tr-none shadow-sm"}`}>
                      {msg.text.split("\n").map((line, i) => (
                        <p key={i} className={i > 0 ? "mt-1.5" : ""}>{line}</p>
                      ))}
                    </div>
                    <span className="font-mono text-[9px] text-gray-400 mt-1 px-1">{msg.time}</span>
                  </div>
                ))}
                
                {isTyping && (
                  <div className="flex flex-col max-w-[80%] ml-auto items-end">
                    <div className="bg-white dark:bg-slate-800 border border-gray-100 dark:border-slate-750 rounded-2xl rounded-tr-none px-4 py-3 shadow-sm flex items-center gap-1">
                      <span className="h-1.5 w-1.5 bg-emerald-500 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                      <span className="h-1.5 w-1.5 bg-emerald-500 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                      <span className="h-1.5 w-1.5 bg-emerald-500 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Quick Prompts Suggestions */}
            <div className="p-2 border-t border-gray-50 dark:border-slate-800 bg-white dark:bg-slate-900 flex gap-1 overflow-x-auto scrollbar-none whitespace-nowrap">
              <button 
                onClick={() => setInput("اشرح لي قانون أوم")}
                className="rounded-full bg-gray-50 dark:bg-slate-800 border border-gray-100 dark:border-slate-700 px-3 py-1 font-sans text-[10px] text-gray-600 dark:text-slate-300 hover:bg-emerald-50 hover:text-emerald-600 transition-colors cursor-pointer"
              >
                شرح قانون أوم 💡
              </button>
              <button 
                onClick={() => setInput("ما هي قوانين كيرشوف؟")}
                className="rounded-full bg-gray-50 dark:bg-slate-800 border border-gray-100 dark:border-slate-700 px-3 py-1 font-sans text-[10px] text-gray-600 dark:text-slate-300 hover:bg-emerald-50 hover:text-emerald-600 transition-colors cursor-pointer"
              >
                قوانين كيرشوف ⚡
              </button>
              <button 
                onClick={() => setInput("نصيحة للمذاكرة قبل الامتحانات")}
                className="rounded-full bg-gray-50 dark:bg-slate-800 border border-gray-100 dark:border-slate-700 px-3 py-1 font-sans text-[10px] text-gray-600 dark:text-slate-300 hover:bg-emerald-50 hover:text-emerald-600 transition-colors cursor-pointer"
              >
                نصيحة للمذاكرة 📚
              </button>
            </div>

            {/* Inputs Box */}
            <div className="p-3 border-t border-gray-100 dark:border-slate-850 bg-white dark:bg-slate-900 flex gap-2 items-center">
              <input 
                type="text" 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSend()}
                placeholder="اكتب سؤالك العلمي هنا..."
                className="flex-1 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl px-3 py-2 font-sans text-xs focus:outline-none focus:border-emerald-500 text-right text-gray-800 dark:text-slate-100"
              />
              <button 
                onClick={handleSend}
                className="h-9 w-9 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white flex items-center justify-center cursor-pointer transition-colors"
              >
                <Send className="h-4 w-4 rotate-180" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};


/* Direct Message Dialog */
interface DirectMessagesHubProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  allUsers: User[];
  messages: DirectMessage[];
  onSendMessage: (receiverId: string, content: string) => void;
}

export const DirectMessagesHub: React.FC<DirectMessagesHubProps> = ({
  isOpen,
  onClose,
  currentUser,
  allUsers,
  messages,
  onSendMessage
}) => {
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [inputText, setInputText] = useState("");

  const chatPartners = allUsers.filter(u => u.id !== currentUser.id);
  const activePartner = chatPartners.find(u => u.id === selectedUserId);

  const activeMessages = messages.filter(
    m => (m.senderId === currentUser.id && m.receiverId === selectedUserId) ||
         (m.senderId === selectedUserId && m.receiverId === currentUser.id)
  ).sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());

  const handleSendMsg = () => {
    if (!inputText.trim() || !selectedUserId) return;
    onSendMessage(selectedUserId, inputText.trim());
    setInputText("");
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4" id="dm-modal-overlay">
      <div className="bg-white dark:bg-slate-900 rounded-2xl w-full max-w-4xl h-[550px] shadow-2xl flex overflow-hidden border border-gray-100 dark:border-slate-800" id="dm-modal-content">
        
        {/* Left Side: Messages Area */}
        <div className="flex-1 flex flex-col bg-gray-50/50 dark:bg-slate-950/40">
          {selectedUserId ? (
            <>
              {/* Chat partner header */}
              <div className="bg-white dark:bg-slate-900 border-b border-gray-100 dark:border-slate-800 px-6 py-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <img 
                    src={activePartner?.avatar} 
                    alt={activePartner?.name} 
                    className="h-10 w-10 rounded-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="text-right">
                    <h4 className="font-sans text-xs font-semibold text-gray-900 dark:text-white">{activePartner?.name}</h4>
                    <p className="font-sans text-[10px] text-gray-400 dark:text-slate-400">
                      {activePartner?.role === UserRole.TEACHER ? "معلم" : activePartner?.role === UserRole.PARENT ? "ولي أمر" : "طالب"}
                    </p>
                  </div>
                </div>
                
                {/* Back button on mobile view */}
                <button 
                  onClick={() => setSelectedUserId(null)}
                  className="md:hidden flex h-8 w-8 items-center justify-center rounded-lg hover:bg-gray-100 dark:hover:bg-slate-800 text-gray-600 dark:text-slate-300"
                >
                  <ArrowLeft className="h-4 w-4" />
                </button>
              </div>

              {/* Message scroll container */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4 scrollbar-thin">
                {activeMessages.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center p-8">
                    <MessageSquare className="h-10 w-10 text-gray-300 dark:text-slate-700 mb-2" />
                    <p className="font-sans text-xs text-gray-400 dark:text-slate-500">ابدأ المحادثة الآن، أرسل رسالة فورية</p>
                  </div>
                ) : (
                  activeMessages.map((msg) => {
                    const isSelf = msg.senderId === currentUser.id;
                    return (
                      <div 
                        key={msg.id}
                        className={`flex flex-col max-w-[70%] ${isSelf ? 'mr-auto items-start' : 'ml-auto items-end'}`}
                      >
                        <div className={`rounded-2xl p-3 font-sans text-xs leading-relaxed text-right ${isSelf ? 'bg-emerald-600 text-white rounded-tl-none' : 'bg-white dark:bg-slate-800 text-gray-800 dark:text-slate-100 border border-gray-100 dark:border-slate-750 rounded-tr-none shadow-sm'}`}>
                          {msg.content}
                        </div>
                        <span className="font-mono text-[9px] text-gray-400 dark:text-slate-500 mt-1 px-1">{formatArabicTime(msg.createdAt)}</span>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Input section */}
              <div className="bg-white dark:bg-slate-900 border-t border-gray-100 dark:border-slate-850 p-4 flex gap-3 items-center">
                <input 
                  type="text"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSendMsg()}
                  placeholder="اكتب رسالتك المباشرة هنا..."
                  className="flex-1 bg-gray-50 dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-xl px-4 py-2 text-right font-sans text-xs focus:outline-none focus:border-emerald-500 dark:text-slate-100"
                />
                <button 
                  onClick={handleSendMsg}
                  className="h-10 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white flex items-center justify-center gap-2 font-sans text-xs font-semibold cursor-pointer transition-colors"
                >
                  <Send className="h-4 w-4 rotate-180" />
                  إرسال
                </button>
              </div>
            </>
          ) : (
            <div className="hidden md:flex flex-col items-center justify-center h-full text-center p-8">
              <MessageSquare className="h-12 w-12 text-emerald-200 dark:text-emerald-950 mb-3 animate-pulse" />
              <h4 className="font-sans text-sm font-semibold text-gray-700 dark:text-slate-300">مراسلات مركز The Catalyst</h4>
              <p className="font-sans text-xs text-gray-400 dark:text-slate-500 mt-1 max-w-sm">
                اختر مستخدماً من القائمة الجانبية لبدء نقاش خاص، أو للتواصل الفوري بين الطلاب والمعلمين وأولياء الأمور.
              </p>
            </div>
          )}
        </div>

        {/* Right Side: Users List */}
        <div className="w-80 border-l border-gray-100 dark:border-slate-850 flex flex-col bg-white dark:bg-slate-900">
          <div className="p-4 border-b border-gray-100 dark:border-slate-800 flex items-center justify-between bg-gray-50/50 dark:bg-slate-900/50">
            <button 
              onClick={onClose}
              className="p-1 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-800 text-gray-500 dark:text-slate-400 cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>
            <span className="font-sans text-sm font-bold text-gray-900 dark:text-white">صندوق الرسائل</span>
          </div>

          <div className="flex-1 overflow-y-auto p-2 space-y-1 scrollbar-thin">
            {chatPartners.map((partner) => {
              const lastMsg = messages.filter(
                m => (m.senderId === currentUser.id && m.receiverId === partner.id) ||
                     (m.senderId === partner.id && m.receiverId === currentUser.id)
              ).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())[0];

              const isSelected = selectedUserId === partner.id;

              return (
                <button
                  key={partner.id}
                  onClick={() => setSelectedUserId(partner.id)}
                  className={`w-full flex items-center gap-3 rounded-xl p-3 text-right font-sans transition-all cursor-pointer ${isSelected ? 'bg-emerald-50 text-emerald-950 border-r-4 border-emerald-600 dark:bg-emerald-950/20 dark:text-emerald-400' : 'hover:bg-gray-50 dark:hover:bg-slate-800/50 text-gray-700 dark:text-slate-300'}`}
                >
                  <img 
                    src={partner.avatar} 
                    alt={partner.name} 
                    className="h-10 w-10 rounded-full object-cover border dark:border-slate-850"
                    referrerPolicy="no-referrer"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-0.5">
                      <span className="font-semibold text-xs truncate">{partner.name}</span>
                      <span className="font-sans text-[9px] bg-gray-100 dark:bg-slate-800 text-gray-500 dark:text-slate-400 px-1.5 py-0.5 rounded-md">
                        {partner.role === UserRole.TEACHER ? "معلم" : partner.role === UserRole.PARENT ? "ولي أمر" : "طالب"}
                      </span>
                    </div>
                    <p className="text-[10px] text-gray-400 dark:text-slate-500 truncate">
                      {lastMsg ? lastMsg.content : "لا توجد رسائل سابقة"}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

      </div>
    </div>
  );
};


/* Promotional Ads Section */
interface PromotionSliderProps {
  campaigns: PromotionCampaign[];
}

export const PromotionSlider: React.FC<PromotionSliderProps> = ({ campaigns }) => {
  const activeCampaigns = campaigns.filter(c => c.active);
  const [activeIndex, setActiveIndex] = useState(0);

  if (activeCampaigns.length === 0) return null;

  return (
    <div className="relative overflow-hidden rounded-2xl bg-gradient-to-l from-emerald-900 to-teal-900 p-6 sm:p-8 text-white shadow-xl mb-8 border border-emerald-800" id="promotions-slider-container">
      {/* Background illustration overlay */}
      <div className="absolute inset-0 bg-cover bg-center opacity-10 mix-blend-overlay" style={{ backgroundImage: `url(${activeCampaigns[activeIndex].imageUrl})` }} />
      
      <div className="relative z-10 grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
        <div className="md:col-span-2 text-right">
          <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/20 px-3 py-1 font-sans text-[10px] font-semibold text-emerald-300 mb-3 border border-emerald-500/30">
            <TrendingUp className="h-3.5 w-3.5" />
            إعلانات المركز والخصومات الحالية
          </span>
          <motion.h3 
            key={activeCampaigns[activeIndex].id + "title"}
            initial={{ opacity: 0, x: -15 }}
            animate={{ opacity: 1, x: 0 }}
            className="font-sans text-lg sm:text-xl font-bold text-white mb-2 leading-tight"
          >
            {activeCampaigns[activeIndex].title}
          </motion.h3>
          <motion.p 
            key={activeCampaigns[activeIndex].id + "desc"}
            initial={{ opacity: 0, x: -15 }}
            animate={{ opacity: 1, x: 0 }}
            className="font-sans text-xs text-emerald-100 leading-relaxed max-w-2xl"
          >
            {activeCampaigns[activeIndex].description}
          </motion.p>
        </div>
        <div className="flex justify-start md:justify-end items-center gap-2">
          {activeCampaigns.length > 1 && (
            <div className="flex gap-1.5 order-2 md:order-1">
              {activeCampaigns.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveIndex(idx)}
                  className={`h-2 w-2 rounded-full cursor-pointer transition-all ${idx === activeIndex ? 'bg-emerald-400 w-4' : 'bg-emerald-700'}`}
                />
              ))}
            </div>
          )}
          <button className="order-1 md:order-2 bg-white text-emerald-900 px-5 py-2 rounded-xl font-sans text-xs font-bold shadow-md hover:bg-emerald-50 transition-colors cursor-pointer">
            سجل الآن
          </button>
        </div>
      </div>
    </div>
  );
};
