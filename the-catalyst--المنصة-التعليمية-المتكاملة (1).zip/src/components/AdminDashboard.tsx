import React, { useState, useRef } from "react";
import { 
  Users, 
  BookOpen, 
  FolderOpen, 
  FileText, 
  Plus, 
  Trash2, 
  Edit, 
  Download, 
  Upload, 
  Settings, 
  AlertTriangle, 
  CheckCircle, 
  Activity, 
  Eye,
  Megaphone,
  UserCheck,
  Calendar,
  Save,
  Clock,
  ArrowRight,
  X,
  GraduationCap
} from "lucide-react";
import { motion } from "motion/react";
import { 
  User, 
  UserRole, 
  Subject, 
  Course,
  Unit, 
  Lesson, 
  SystemLog, 
  PromotionCampaign, 
  SystemNotification 
} from "../types";

interface AdminDashboardProps {
  subjects: Subject[];
  units: Unit[];
  lessons: Lesson[];
  users: User[];
  logs: SystemLog[];
  campaigns: PromotionCampaign[];
  courses: Course[];
  onAddSubject: (subj: Omit<Subject, "id">) => void;
  onDeleteSubject: (id: string) => void;
  onUpdateSubject: (id: string, subj: Partial<Subject>) => void;
  onAddUnit: (unit: Omit<Unit, "id">) => void;
  onDeleteUnit: (id: string) => void;
  onAddLesson: (lesson: Omit<Lesson, "id">) => void;
  onDeleteLesson: (id: string) => void;
  onAddCampaign: (camp: Omit<PromotionCampaign, "id">) => void;
  onToggleCampaign: (id: string) => void;
  onDeleteCampaign: (id: string) => void;
  onUpdateUserRole: (id: string, role: UserRole) => void;
  onImportData: (jsonData: string) => boolean;
  onExportData: () => void;
  onAddCourse: (course: Omit<Course, "id">) => void;
  onDeleteCourse: (id: string) => void;
  onUpdateCourse: (id: string, course: Partial<Course>) => void;
  onAddUser?: (user: Omit<User, "id">) => void;
  onDeleteUser?: (id: string) => void;
  language?: "ar" | "en";
  onToggleLanguage?: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  subjects,
  units,
  lessons,
  users,
  logs,
  campaigns,
  courses,
  onAddSubject,
  onDeleteSubject,
  onUpdateSubject,
  onAddUnit,
  onDeleteUnit,
  onAddLesson,
  onDeleteLesson,
  onAddCampaign,
  onToggleCampaign,
  onDeleteCampaign,
  onUpdateUserRole,
  onImportData,
  onExportData,
  onAddCourse,
  onDeleteCourse,
  onUpdateCourse,
  onAddUser,
  onDeleteUser,
  language = "ar",
  onToggleLanguage
}) => {
  const [activeTab, setActiveTab] = useState<"metrics" | "curriculum" | "courses" | "users" | "campaigns" | "audit" | "database">("metrics");
  
  const isAr = language === "ar";

  // States for CRUD forms
  const [subjForm, setSubjForm] = useState({ name: "", description: "", image: "", teacherId: "teacher-1", code: "" });
  const [unitForm, setUnitForm] = useState({ subjectId: "", title: "", description: "", order: 1 });
  const [lessonForm, setLessonForm] = useState({ unitId: "", subjectId: "", title: "", content: "", duration: "45 دقيقة", videoUrl: "", pdfName: "", pdfUrl: "#" });
  
  const [courseForm, setCourseForm] = useState({ name: "", description: "", code: "", subjectIds: [] as string[], teacherIds: [] as string[] });
  const [editingCourseId, setEditingCourseId] = useState<string | null>(null);
  
  const [promoForm, setPromoForm] = useState({ title: "", description: "", imageUrl: "", linkUrl: "", active: true });
  
  // States for User CRUD
  const [showAddUserForm, setShowAddUserForm] = useState(false);
  const [userForm, setUserForm] = useState({
    name: "",
    email: "",
    phone: "",
    role: UserRole.STUDENT,
    specialization: ""
  });
  
  const [notifMessage, setNotifMessage] = useState<{ text: string; type: "success" | "error" } | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const triggerNotification = (text: string, type: "success" | "error" = "success") => {
    setNotifMessage({ text, type });
    setTimeout(() => setNotifMessage(null), 4000);
  };

  // Handle forms submit
  const handleAddSubjectSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!subjForm.name || !subjForm.code) {
      triggerNotification("يرجى إدخال اسم المادة ورمزها العلمي", "error");
      return;
    }
    onAddSubject({
      ...subjForm,
      image: subjForm.image || "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=400"
    });
    setSubjForm({ name: "", description: "", image: "", teacherId: "teacher-1", code: "" });
    triggerNotification("تمت إضافة المادة الدراسية بنجاح");
  };

  const handleAddUnitSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!unitForm.subjectId || !unitForm.title) {
      triggerNotification("يرجى اختيار المادة وإدخال عنوان الباب أو الوحدة", "error");
      return;
    }
    onAddUnit({
      ...unitForm,
      order: Number(unitForm.order)
    });
    setUnitForm({ subjectId: "", title: "", description: "", order: units.length + 1 });
    triggerNotification("تمت إضافة الوحدة الدراسية بنجاح");
  };

  const handleAddLessonSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!lessonForm.unitId || !lessonForm.title || !lessonForm.content) {
      triggerNotification("يرجى ملء كافة تفاصيل الدرس ومحتواه العلمي", "error");
      return;
    }
    
    // Auto find subjectId from unit
    const selectedUnit = units.find(u => u.id === lessonForm.unitId);
    
    onAddLesson({
      unitId: lessonForm.unitId,
      subjectId: selectedUnit ? selectedUnit.subjectId : "",
      title: lessonForm.title,
      content: lessonForm.content,
      duration: lessonForm.duration,
      videoUrl: lessonForm.videoUrl,
      pdfName: lessonForm.pdfName || undefined,
      pdfUrl: lessonForm.pdfName ? "#" : undefined,
      order: lessons.filter(l => l.unitId === lessonForm.unitId).length + 1
    });

    setLessonForm({ unitId: "", subjectId: "", title: "", content: "", duration: "45 دقيقة", videoUrl: "", pdfName: "", pdfUrl: "#" });
    triggerNotification("تمت إضافة الدرس وتضمينه في الجدول بنجاح");
  };

  const handleAddCampaignSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!promoForm.title || !promoForm.description) {
      triggerNotification("يرجى كتابة عنوان ووصف الحملة الترويجية", "error");
      return;
    }
    onAddCampaign({
      ...promoForm,
      imageUrl: promoForm.imageUrl || "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=600"
    });
    setPromoForm({ title: "", description: "", imageUrl: "", linkUrl: "", active: true });
    triggerNotification("تم نشر الإعلان الترويجي على شاشات الطلاب بنجاح");
  };

  const handleCourseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!courseForm.name || !courseForm.code) {
      triggerNotification("يرجى إدخال اسم الدورة ورمزها العلمي", "error");
      return;
    }
    if (editingCourseId) {
      onUpdateCourse(editingCourseId, courseForm);
      triggerNotification("تم تحديث بيانات الدورة بنجاح");
      setEditingCourseId(null);
    } else {
      onAddCourse(courseForm);
      triggerNotification("تمت إضافة الدورة الدراسية الجديدة بنجاح");
    }
    setCourseForm({ name: "", description: "", code: "", subjectIds: [], teacherIds: [] });
  };

  const handleAddUserSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userForm.name || !userForm.email) {
      triggerNotification(
        isAr ? "يرجى كتابة الاسم والبريد الإلكتروني على الأقل" : "Please provide at least a name and email", 
        "error"
      );
      return;
    }
    
    if (onAddUser) {
      onAddUser({
        name: userForm.name,
        email: userForm.email,
        phone: userForm.phone,
        role: userForm.role,
        avatar: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(userForm.name)}`,
        specialization: userForm.role === UserRole.TEACHER ? userForm.specialization : undefined
      });
      setUserForm({
        name: "",
        email: "",
        phone: "",
        role: UserRole.STUDENT,
        specialization: ""
      });
      setShowAddUserForm(false);
      triggerNotification(
        isAr ? "تمت إضافة العضو الجديد بنجاح" : "New member added successfully", 
        "success"
      );
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const success = onImportData(text);
        if (success) {
          triggerNotification("تم استيراد قاعدة البيانات بنجاح وتحديث النظام!");
        } else {
          triggerNotification("خطأ: بنية الملف غير صالحة لاستيراد قاعدة البيانات", "error");
        }
      } catch (err) {
        triggerNotification("فشل قراءة الملف كصيغة JSON مخصصة", "error");
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className={`py-6 font-sans ${isAr ? "text-right" : "text-left"}`} dir={isAr ? "rtl" : "ltr"} id="admin-dashboard-container">
      
      {/* Dynamic Toast Alert Notification */}
      {notifMessage && (
        <div className={`fixed bottom-6 left-6 z-50 rounded-xl px-4 py-3 text-white flex items-center gap-2 shadow-lg transition-all ${notifMessage.type === "success" ? "bg-emerald-600" : "bg-red-600"}`}>
          {notifMessage.type === "success" ? <CheckCircle className="h-5 w-5" /> : <AlertTriangle className="h-5 w-5" />}
          <span className="text-xs font-semibold">{notifMessage.text}</span>
        </div>
      )}

      {/* Primary Dashboard Navigation Tabs */}
      <div className={`flex flex-wrap items-center gap-2 border-b border-gray-100 pb-4 mb-6 ${isAr ? "justify-start" : "justify-start"}`}>
        <button
          onClick={() => setActiveTab("metrics")}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer transition-all ${activeTab === "metrics" ? "bg-emerald-600 text-white" : "hover:bg-gray-50 text-gray-600 bg-white border border-gray-100"}`}
        >
          <Activity className="h-4 w-4 shrink-0" />
          {isAr ? "مؤشرات المنصة" : "Platform Metrics"}
        </button>
        <button
          onClick={() => setActiveTab("curriculum")}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer transition-all ${activeTab === "curriculum" ? "bg-emerald-600 text-white" : "hover:bg-gray-50 text-gray-600 bg-white border border-gray-100"}`}
        >
          <BookOpen className="h-4 w-4 shrink-0" />
          {isAr ? "تنظيم المناهج" : "Curriculum Planner"}
        </button>
        <button
          onClick={() => setActiveTab("courses")}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer transition-all ${activeTab === "courses" ? "bg-emerald-600 text-white" : "hover:bg-gray-50 text-gray-600 bg-white border border-gray-100"}`}
        >
          <GraduationCap className="h-4 w-4 shrink-0" />
          {isAr ? "إدارة الدورات والمناهج" : "Course Management"}
        </button>
        <button
          onClick={() => setActiveTab("users")}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer transition-all ${activeTab === "users" ? "bg-emerald-600 text-white" : "hover:bg-gray-50 text-gray-600 bg-white border border-gray-100"}`}
        >
          <Users className="h-4 w-4 shrink-0" />
          {isAr ? "صلاحيات الأعضاء" : "User Management"}
        </button>
        <button
          onClick={() => setActiveTab("campaigns")}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer transition-all ${activeTab === "campaigns" ? "bg-emerald-600 text-white" : "hover:bg-gray-50 text-gray-600 bg-white border border-gray-100"}`}
        >
          <Megaphone className="h-4 w-4 shrink-0" />
          {isAr ? "الحملات التسويقية" : "Campaigns & Ads"}
        </button>
        <button
          onClick={() => setActiveTab("audit")}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer transition-all ${activeTab === "audit" ? "bg-emerald-600 text-white" : "hover:bg-gray-50 text-gray-600 bg-white border border-gray-100"}`}
        >
          <UserCheck className="h-4 w-4 shrink-0" />
          {isAr ? "مراقبة العمليات" : "Audit Logs"}
        </button>
        <button
          onClick={() => setActiveTab("database")}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer transition-all ${activeTab === "database" ? "bg-emerald-600 text-white" : "hover:bg-gray-50 text-gray-600 bg-white border border-gray-100"}`}
        >
          <Download className="h-4 w-4 shrink-0" />
          {isAr ? "قاعدة البيانات والنسخ" : "Backup & Database"}
        </button>
      </div>

      {/* Tab Contents */}
      {activeTab === "metrics" && (
        <div className="space-y-6">
          {/* Main Counters Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white border border-gray-100 p-5 rounded-2xl shadow-sm flex items-center justify-between">
              <div>
                <span className="font-sans text-[11px] text-gray-400 font-medium block mb-1">إجمالي الأعضاء</span>
                <span className="font-mono text-2xl font-bold text-gray-900">{users.length}</span>
              </div>
              <div className="h-12 w-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                <Users className="h-6 w-6" />
              </div>
            </div>
            <div className="bg-white border border-gray-100 p-5 rounded-2xl shadow-sm flex items-center justify-between">
              <div>
                <span className="font-sans text-[11px] text-gray-400 font-medium block mb-1">المواد الأكاديمية</span>
                <span className="font-mono text-2xl font-bold text-gray-900">{subjects.length}</span>
              </div>
              <div className="h-12 w-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
                <BookOpen className="h-6 w-6" />
              </div>
            </div>
            <div className="bg-white border border-gray-100 p-5 rounded-2xl shadow-sm flex items-center justify-between">
              <div>
                <span className="font-sans text-[11px] text-gray-400 font-medium block mb-1">الأبواب والوحدات</span>
                <span className="font-mono text-2xl font-bold text-gray-900">{units.length}</span>
              </div>
              <div className="h-12 w-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
                <FolderOpen className="h-6 w-6" />
              </div>
            </div>
            <div className="bg-white border border-gray-100 p-5 rounded-2xl shadow-sm flex items-center justify-between">
              <div>
                <span className="font-sans text-[11px] text-gray-400 font-medium block mb-1">الدروس المنشورة</span>
                <span className="font-mono text-2xl font-bold text-gray-900">{lessons.length}</span>
              </div>
              <div className="h-12 w-12 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center">
                <FileText className="h-6 w-6" />
              </div>
            </div>
          </div>

          {/* Quick Stats Graphs / Custom Vector SVG Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 bg-white border border-gray-100 p-6 rounded-2xl shadow-sm">
              <h3 className="font-sans text-xs font-bold text-gray-900 mb-4">نشاط المنصة الأسبوعي (تسجيل ودخول الطلاب)</h3>
              
              {/* Custom SVG Bar Chart */}
              <div className="h-64 flex items-end gap-6 border-b border-gray-100 pb-2">
                {[
                  { label: "الأحد", count: 45, height: "70%" },
                  { label: "الإثنين", count: 62, height: "95%" },
                  { label: "الثلاثاء", count: 35, height: "55%" },
                  { label: "الأربعاء", count: 58, height: "88%" },
                  { label: "الخميس", count: 75, height: "100%" },
                  { label: "الجمعة", count: 15, height: "25%" },
                  { label: "السبت", count: 28, height: "45%" }
                ].map((item, idx) => (
                  <div key={idx} className="flex-1 flex flex-col items-center group relative h-full justify-end">
                    {/* Tooltip info */}
                    <div className="absolute -top-6 bg-gray-900 text-white rounded text-[10px] font-mono px-1.5 py-0.5 opacity-0 group-hover:opacity-100 transition-opacity z-10">
                      {item.count} عملية
                    </div>
                    {/* Bar */}
                    <div 
                      className="w-full bg-emerald-500 hover:bg-emerald-600 transition-all rounded-t-md" 
                      style={{ height: item.height }}
                    />
                    <span className="font-sans text-[10px] text-gray-400 mt-2">{item.label}</span>
                  </div>
                ))}
              </div>
              <div className="flex justify-between mt-3">
                <span className="font-sans text-[10px] text-gray-400">إجمالي عمليات التفاعل النشط: 318 عملية دخول</span>
                <span className="font-sans text-[10px] text-emerald-600 font-semibold">+24% زيادة عن الأسبوع الماضي</span>
              </div>
            </div>

            <div className="bg-white border border-gray-100 p-6 rounded-2xl shadow-sm flex flex-col justify-between">
              <div>
                <h3 className="font-sans text-xs font-bold text-gray-900 mb-2">توزيع المستخدمين حسب الرتب</h3>
                <p className="font-sans text-[11px] text-gray-400 mb-4">نسب تمثيل الفئات الأساسية على The Catalyst</p>
                
                {/* Visual Circle gauge */}
                <div className="flex justify-center items-center h-40 relative">
                  <svg className="w-36 h-36 transform -rotate-90">
                    <circle cx="72" cy="72" r="50" fill="transparent" stroke="#f3f4f6" strokeWidth="12" />
                    {/* Math circle slice (Student representation ~ 60%) */}
                    <circle cx="72" cy="72" r="50" fill="transparent" stroke="#10b981" strokeWidth="12" strokeDasharray="314" strokeDashoffset="125" />
                    {/* Teacher representation ~ 20% */}
                    <circle cx="72" cy="72" r="50" fill="transparent" stroke="#6366f1" strokeWidth="12" strokeDasharray="314" strokeDashoffset="250" className="opacity-70" />
                  </svg>
                  <div className="absolute flex flex-col items-center">
                    <span className="font-mono text-xl font-bold text-emerald-600">60%</span>
                    <span className="font-sans text-[9px] text-gray-400">أغلبية من الطلاب</span>
                  </div>
                </div>
              </div>

              <div className="space-y-1 mt-2">
                <div className="flex items-center justify-between text-[10px] font-sans">
                  <span className="flex items-center gap-1.5 text-gray-600">
                    <span className="h-2 w-2 rounded-full bg-emerald-500" />
                    الطلاب
                  </span>
                  <span className="font-mono font-bold text-gray-900">
                    {users.filter(u => u.role === UserRole.STUDENT).length} طالب
                  </span>
                </div>
                <div className="flex items-center justify-between text-[10px] font-sans">
                  <span className="flex items-center gap-1.5 text-gray-600">
                    <span className="h-2 w-2 rounded-full bg-indigo-500" />
                    المعلمون
                  </span>
                  <span className="font-mono font-bold text-gray-900">
                    {users.filter(u => u.role === UserRole.TEACHER).length} معلم
                  </span>
                </div>
                <div className="flex items-center justify-between text-[10px] font-sans">
                  <span className="flex items-center gap-1.5 text-gray-600">
                    <span className="h-2 w-2 rounded-full bg-amber-500" />
                    أولياء الأمور
                  </span>
                  <span className="font-mono font-bold text-gray-900">
                    {users.filter(u => u.role === UserRole.PARENT).length} ولي أمر
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Curriculum CRUD Tab */}
      {activeTab === "curriculum" && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Create form columns */}
            <div className="lg:col-span-1 space-y-6">
              {/* Form Add Subject */}
              <div className="bg-white border border-gray-100 p-5 rounded-2xl shadow-sm">
                <h3 className="font-sans text-xs font-bold text-gray-900 mb-4 flex items-center gap-2">
                  <Plus className="h-4 w-4 text-emerald-600" />
                  إضافة مادة دراسية جديدة
                </h3>
                <form onSubmit={handleAddSubjectSubmit} className="space-y-3">
                  <div>
                    <label className="block text-[11px] text-gray-400 mb-1 font-sans">اسم المادة الدراسي</label>
                    <input 
                      type="text"
                      placeholder="مثال: مادة الكيمياء العضوية"
                      value={subjForm.name}
                      onChange={(e) => setSubjForm({...subjForm, name: e.target.value})}
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-right text-xs"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[11px] text-gray-400 mb-1 font-sans">كود المادة</label>
                      <input 
                        type="text"
                        placeholder="مثال: CHEM-3"
                        value={subjForm.code}
                        onChange={(e) => setSubjForm({...subjForm, code: e.target.value})}
                        className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-right text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-gray-400 mb-1 font-sans">المعلم المسؤول</label>
                      <select
                        value={subjForm.teacherId}
                        onChange={(e) => setSubjForm({...subjForm, teacherId: e.target.value})}
                        className="w-full bg-gray-50 border border-gray-200 rounded-xl px-2 py-2 text-right text-xs"
                      >
                        {users.filter(u => u.role === UserRole.TEACHER).map(t => (
                          <option key={t.id} value={t.id}>{t.name}</option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-[11px] text-gray-400 mb-1 font-sans">رابط غلاف المادة (تلقائي إن تُرِك فارغاً)</label>
                    <input 
                      type="text"
                      placeholder="https://..."
                      value={subjForm.image}
                      onChange={(e) => setSubjForm({...subjForm, image: e.target.value})}
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-right text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-gray-400 mb-1 font-sans">وصف موجز للمادة</label>
                    <textarea 
                      placeholder="تفاصيل حول مخرجات التعلم..."
                      value={subjForm.description}
                      onChange={(e) => setSubjForm({...subjForm, description: e.target.value})}
                      rows={2}
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-right text-xs"
                    />
                  </div>
                  <button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-sans text-xs font-semibold py-2 rounded-xl transition-colors cursor-pointer">
                    تأكيد إضافة المادة
                  </button>
                </form>
              </div>

              {/* Form Add Unit */}
              <div className="bg-white border border-gray-100 p-5 rounded-2xl shadow-sm">
                <h3 className="font-sans text-xs font-bold text-gray-900 mb-4 flex items-center gap-2">
                  <Plus className="h-4 w-4 text-emerald-600" />
                  إضافة باب / وحدة دراسية
                </h3>
                <form onSubmit={handleAddUnitSubmit} className="space-y-3">
                  <div>
                    <label className="block text-[11px] text-gray-400 mb-1 font-sans">تابع للمادة الدراسية</label>
                    <select
                      value={unitForm.subjectId}
                      onChange={(e) => setUnitForm({...unitForm, subjectId: e.target.value})}
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl px-2 py-2 text-right text-xs"
                    >
                      <option value="">-- اختر المادة --</option>
                      {subjects.map(s => (
                        <option key={s.id} value={s.id}>{s.name}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-[11px] text-gray-400 mb-1 font-sans">عنوان الوحدة</label>
                    <input 
                      type="text"
                      placeholder="مثال: الباب الثالث: الاتزان الكيميائي"
                      value={unitForm.title}
                      onChange={(e) => setUnitForm({...unitForm, title: e.target.value})}
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-right text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-gray-400 mb-1 font-sans">ترتيب ظهورها</label>
                    <input 
                      type="number"
                      value={unitForm.order}
                      onChange={(e) => setUnitForm({...unitForm, order: Number(e.target.value)})}
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-right text-xs"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] text-gray-400 mb-1 font-sans">تفاصيل الباب</label>
                    <textarea 
                      placeholder="وصف الباب ومحتواه الفرعي..."
                      value={unitForm.description}
                      onChange={(e) => setUnitForm({...unitForm, description: e.target.value})}
                      rows={2}
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-right text-xs"
                    />
                  </div>
                  <button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-sans text-xs font-semibold py-2 rounded-xl transition-colors cursor-pointer">
                    تأكيد إضافة الباب
                  </button>
                </form>
              </div>
            </div>

            {/* List and manage columns */}
            <div className="lg:col-span-2 space-y-6">
              
              {/* Form Add Lesson */}
              <div className="bg-white border border-gray-100 p-5 rounded-2xl shadow-sm">
                <h3 className="font-sans text-xs font-bold text-gray-900 mb-4 flex items-center gap-2">
                  <Plus className="h-4 w-4 text-emerald-600" />
                  إنشاء درس وتضمين المحتوى العلمي
                </h3>
                <form onSubmit={handleAddLessonSubmit} className="space-y-4">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[11px] text-gray-400 mb-1 font-sans">تابع للباب / الوحدة</label>
                      <select
                        value={lessonForm.unitId}
                        onChange={(e) => setLessonForm({...lessonForm, unitId: e.target.value})}
                        className="w-full bg-gray-50 border border-gray-200 rounded-xl px-2 py-2 text-right text-xs"
                      >
                        <option value="">-- اختر الباب --</option>
                        {units.map(u => {
                          const subj = subjects.find(s => s.id === u.subjectId);
                          return (
                            <option key={u.id} value={u.id}>
                              [{subj?.code}] {u.title}
                            </option>
                          );
                        })}
                      </select>
                    </div>
                    <div>
                      <label className="block text-[11px] text-gray-400 mb-1 font-sans">عنوان الدرس</label>
                      <input 
                        type="text"
                        placeholder="مثال: الدرس الثالث: العوامل المؤثرة على سرعة التفاعل"
                        value={lessonForm.title}
                        onChange={(e) => setLessonForm({...lessonForm, title: e.target.value})}
                        className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-right text-xs"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <label className="block text-[11px] text-gray-400 mb-1 font-sans">زمن المحاضرة المقدر</label>
                      <input 
                        type="text"
                        placeholder="45 دقيقة"
                        value={lessonForm.duration}
                        onChange={(e) => setLessonForm({...lessonForm, duration: e.target.value})}
                        className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-right text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-gray-400 mb-1 font-sans">رابط فيديو الشرح (YouTube Embed)</label>
                      <input 
                        type="text"
                        placeholder="https://www.youtube.com/embed/..."
                        value={lessonForm.videoUrl}
                        onChange={(e) => setLessonForm({...lessonForm, videoUrl: e.target.value})}
                        className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-right text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-gray-400 mb-1 font-sans">اسم الكتيب المرفق (PDF)</label>
                      <input 
                        type="text"
                        placeholder="ملخص_الباب_الثالث.pdf"
                        value={lessonForm.pdfName}
                        onChange={(e) => setLessonForm({...lessonForm, pdfName: e.target.value})}
                        className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-right text-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] text-gray-400 mb-1 font-sans">المادة العلمية المكتوبة وشرح الدرس (يدعم التنسيق المبسط)</label>
                    <textarea 
                      placeholder="اكتب تفاصيل المحاضرة والملخص العلمي هنا للطلاب..."
                      value={lessonForm.content}
                      onChange={(e) => setLessonForm({...lessonForm, content: e.target.value})}
                      rows={4}
                      className="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-right text-xs"
                    />
                  </div>
                  <button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-sans text-xs font-semibold py-2.5 rounded-xl transition-colors cursor-pointer">
                    حفظ وإعلان الدرس الجديد
                  </button>
                </form>
              </div>

              {/* View and Delete List items */}
              <div className="bg-white border border-gray-100 p-5 rounded-2xl shadow-sm">
                <h3 className="font-sans text-xs font-bold text-gray-900 mb-4">المناهج والوحدات المتاحة حالياً</h3>
                <div className="space-y-4">
                  {subjects.map(s => (
                    <div key={s.id} className="border border-gray-100 rounded-xl p-4">
                      <div className="flex items-center justify-between mb-3 bg-gray-50/50 p-2.5 rounded-lg">
                        <div className="text-right">
                          <span className="font-sans text-[10px] font-bold bg-indigo-50 text-indigo-600 px-2 py-0.5 rounded-full">{s.code}</span>
                          <h4 className="font-sans text-xs font-bold text-gray-900 mt-1">{s.name}</h4>
                        </div>
                        <button 
                          onClick={() => {
                            onDeleteSubject(s.id);
                            triggerNotification("تم حذف المادة بالكامل");
                          }}
                          className="h-8 w-8 rounded-lg text-red-500 hover:bg-red-50 flex items-center justify-center cursor-pointer transition-colors"
                          title="حذف المادة بالكامل"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>

                      {/* Display Units under this Subject */}
                      <div className="space-y-2 mr-4 border-r-2 border-emerald-100 pr-3">
                        {units.filter(u => u.subjectId === s.id).map(u => (
                          <div key={u.id} className="text-right">
                            <div className="flex items-center justify-between">
                              <span className="font-sans text-xs font-semibold text-gray-800">{u.title}</span>
                              <button 
                                onClick={() => {
                                  onDeleteUnit(u.id);
                                  triggerNotification("تم حذف الباب بنجاح");
                                }}
                                className="text-gray-400 hover:text-red-500 cursor-pointer"
                                title="حذف الباب"
                              >
                                <X className="h-3.5 w-3.5" />
                              </button>
                            </div>

                            {/* Lessons under this unit */}
                            <ul className="list-disc list-inside mr-3 mt-1.5 space-y-1 text-gray-500 text-[11px]">
                              {lessons.filter(l => l.unitId === u.id).map(l => (
                                <li key={l.id} className="flex justify-between items-center bg-gray-50/30 px-2 py-1 rounded">
                                  <span>{l.title} ({l.duration})</span>
                                  <button
                                    onClick={() => {
                                      onDeleteLesson(l.id);
                                      triggerNotification("تم إزالة الدرس بنجاح");
                                    }}
                                    className="text-gray-400 hover:text-red-500 cursor-pointer"
                                  >
                                    إزالة
                                  </button>
                                </li>
                              ))}
                            </ul>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          </div>
        </div>
      )}

      {/* Users Role Permissions Tab */}
      {activeTab === "users" && (
        <div className="space-y-6">
          {/* Header Action Row */}
          <div className="bg-white border border-gray-100 rounded-2xl shadow-sm p-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h3 className="font-sans text-xs font-bold text-gray-900">
                {isAr ? "سجل أعضاء المنصة والصلاحيات الأكاديمية" : "User Database & Academic Permissions"}
              </h3>
              <p className="font-sans text-[11px] text-gray-400 mt-1">
                {isAr 
                  ? "إضافة أعضاء جدد، وحذفهم، وتعديل أدوارهم وصلاحياتهم للتحكم بالبوابة" 
                  : "Create new members, remove them, and modify their roles to control portal access."}
              </p>
            </div>
            
            {onAddUser && (
              <button
                onClick={() => setShowAddUserForm(!showAddUserForm)}
                className="flex items-center gap-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 text-xs font-bold transition-all shadow-sm shadow-emerald-100 dark:shadow-none cursor-pointer self-start sm:self-auto"
                id="add-user-toggle-btn"
              >
                {showAddUserForm ? <X className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
                {showAddUserForm 
                  ? (isAr ? "إلغاء الإضافة" : "Cancel Creation") 
                  : (isAr ? "إضافة عضو جديد" : "Add New Member")}
              </button>
            )}
          </div>

          {/* Add User Expandable Form */}
          {showAddUserForm && onAddUser && (
            <motion.div 
              initial={{ opacity: 0, y: -15 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-white border border-gray-100 rounded-2xl shadow-sm p-6"
            >
              <h4 className="font-sans text-xs font-bold text-gray-900 mb-4 flex items-center gap-2">
                <Users className="h-4 w-4 text-emerald-600" />
                {isAr ? "بيانات العضو الجديد" : "New Member Credentials"}
              </h4>

              <form onSubmit={handleAddUserSubmit} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                  <label className="block text-[11px] text-gray-400 mb-1 font-sans">
                    {isAr ? "الاسم الكامل" : "Full Name"} <span className="text-red-500">*</span>
                  </label>
                  <input 
                    type="text"
                    required
                    placeholder={isAr ? "مثال: أسامة أحمد" : "e.g. Osama Ahmed"}
                    value={userForm.name}
                    onChange={(e) => setUserForm({...userForm, name: e.target.value})}
                    className={`w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs text-gray-900 focus:outline-none focus:ring-1 focus:ring-emerald-500 dark:bg-slate-800 dark:border-slate-700 dark:text-white ${isAr ? "text-right" : "text-left"}`}
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-gray-400 mb-1 font-sans">
                    {isAr ? "البريد الإلكتروني" : "Email Address"} <span className="text-red-500">*</span>
                  </label>
                  <input 
                    type="email"
                    required
                    placeholder={isAr ? "example@domain.com" : "example@domain.com"}
                    value={userForm.email}
                    onChange={(e) => setUserForm({...userForm, email: e.target.value})}
                    className={`w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs text-gray-900 focus:outline-none focus:ring-1 focus:ring-emerald-500 dark:bg-slate-800 dark:border-slate-700 dark:text-white ${isAr ? "text-right" : "text-left"}`}
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-gray-400 mb-1 font-sans">
                    {isAr ? "رقم الهاتف" : "Phone Number"}
                  </label>
                  <input 
                    type="text"
                    placeholder={isAr ? "مثال: 01012345678" : "e.g. 01012345678"}
                    value={userForm.phone}
                    onChange={(e) => setUserForm({...userForm, phone: e.target.value})}
                    className={`w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs text-gray-900 focus:outline-none focus:ring-1 focus:ring-emerald-500 dark:bg-slate-800 dark:border-slate-700 dark:text-white ${isAr ? "text-right" : "text-left"}`}
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-gray-400 mb-1 font-sans">
                    {isAr ? "الدور والصلاحية" : "Role & Authorization"}
                  </label>
                  <select 
                    value={userForm.role}
                    onChange={(e) => setUserForm({...userForm, role: e.target.value as UserRole})}
                    className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs text-gray-900 focus:outline-none focus:ring-1 focus:ring-emerald-500 dark:bg-slate-800 dark:border-slate-700 dark:text-white"
                  >
                    {Object.values(UserRole).map((role) => (
                      <option key={role} value={role}>
                        {role === UserRole.ADMIN ? (isAr ? "مدير النظام (Admin)" : "System Admin") :
                         role === UserRole.TEACHER ? (isAr ? "معلم المادة (Teacher)" : "Teacher") :
                         role === UserRole.STUDENT ? (isAr ? "طالب علم (Student)" : "Student") :
                         (isAr ? "ولي الأمر (Parent)" : "Parent / Guardian")}
                      </option>
                    ))}
                  </select>
                </div>

                {userForm.role === UserRole.TEACHER && (
                  <div className="md:col-span-2">
                    <label className="block text-[11px] text-gray-400 mb-1 font-sans">
                      {isAr ? "التخصص الأكاديمي للمعلم" : "Teacher Academic Specialization"}
                    </label>
                    <input 
                      type="text"
                      placeholder={isAr ? "مثال: معلم أول فيزياء وكيمياء" : "e.g. Physics & Chemistry Senior Teacher"}
                      value={userForm.specialization}
                      onChange={(e) => setUserForm({...userForm, specialization: e.target.value})}
                      className={`w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-xs text-gray-900 focus:outline-none focus:ring-1 focus:ring-emerald-500 dark:bg-slate-800 dark:border-slate-700 dark:text-white ${isAr ? "text-right" : "text-left"}`}
                    />
                  </div>
                )}

                <div className="md:col-span-2 lg:col-span-4 flex justify-end gap-2 pt-2">
                  <button
                    type="submit"
                    className="rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2 text-xs font-bold transition-all cursor-pointer"
                  >
                    {isAr ? "تأكيد إضافة العضو" : "Add Member Credentials"}
                  </button>
                </div>
              </form>
            </motion.div>
          )}

          {/* Members Table */}
          <div className="bg-white border border-gray-100 rounded-2xl shadow-sm p-6 overflow-hidden">
            <div className="overflow-x-auto">
              <table className={`w-full border-collapse text-xs font-sans ${isAr ? "text-right" : "text-left"}`}>
                <thead>
                  <tr className="bg-gray-50 border-b border-gray-100 text-gray-500">
                    <th className="p-3">{isAr ? "العضو" : "Member"}</th>
                    <th className="p-3">{isAr ? "البريد الإلكتروني" : "Email Address"}</th>
                    <th className="p-3">{isAr ? "رقم الهاتف" : "Phone Number"}</th>
                    <th className="p-3">{isAr ? "صلاحية العضوية" : "Assigned Role"}</th>
                    <th className="p-3 text-center">{isAr ? "الإجراءات" : "Management Actions"}</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map((user) => (
                    <tr key={user.id} className="border-b border-gray-50 hover:bg-gray-50/50">
                      <td className="p-3 flex items-center gap-2">
                        <img 
                          src={user.avatar} 
                          alt={user.name} 
                          className="h-8 w-8 rounded-full object-cover border shrink-0" 
                          referrerPolicy="no-referrer" 
                        />
                        <div>
                          <p className="font-bold text-gray-900 dark:text-white">{user.name}</p>
                          {user.specialization && (
                            <span className="text-[10px] text-indigo-500 font-medium block">
                              {user.specialization}
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="p-3 text-gray-600 font-mono text-[11px]">{user.email}</td>
                      <td className="p-3 text-gray-600 font-mono text-[11px]">{user.phone || (isAr ? "غير متوفر" : "N/A")}</td>
                      <td className="p-3">
                        <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          user.role === UserRole.ADMIN ? "bg-red-50 text-red-600" :
                          user.role === UserRole.TEACHER ? "bg-indigo-50 text-indigo-600" :
                          user.role === UserRole.STUDENT ? "bg-emerald-50 text-emerald-600" :
                          "bg-amber-50 text-amber-600"
                        }`}>
                          {user.role === UserRole.ADMIN ? (isAr ? "مدير النظام" : "System Admin") : 
                           user.role === UserRole.TEACHER ? (isAr ? "معلم المادة" : "Teacher") : 
                           user.role === UserRole.STUDENT ? (isAr ? "طالب" : "Student") : (isAr ? "ولي أمر" : "Parent")}
                        </span>
                      </td>
                      <td className="p-3 text-center flex items-center justify-center gap-2">
                        <select
                          value={user.role}
                          onChange={(e) => {
                            onUpdateUserRole(user.id, e.target.value as UserRole);
                            triggerNotification(
                              isAr ? "تم تعديل صلاحية العضو بنجاح" : "User privileges updated successfully",
                              "success"
                            );
                          }}
                          className="bg-gray-50 border border-gray-200 rounded px-1.5 py-1 text-[11px] font-sans dark:bg-slate-800 dark:border-slate-700 dark:text-white"
                        >
                          {Object.values(UserRole).map(role => (
                            <option key={role} value={role}>
                              {role === UserRole.ADMIN ? (isAr ? "مدير النظام" : "System Admin") :
                               role === UserRole.TEACHER ? (isAr ? "معلم" : "Teacher") :
                               role === UserRole.STUDENT ? (isAr ? "طالب" : "Student") :
                               (isAr ? "ولي أمر" : "Parent")}
                            </option>
                          ))}
                        </select>
                        
                        {onDeleteUser && (
                          <button
                            onClick={() => {
                              if (window.confirm(isAr ? `هل أنت متأكد من حذف العضو ${user.name}؟` : `Are you sure you want to delete member ${user.name}?`)) {
                                onDeleteUser(user.id);
                                triggerNotification(
                                  isAr ? "تم حذف العضو بنجاح" : "Member removed successfully",
                                  "success"
                                );
                              }
                            }}
                            className="text-red-500 hover:text-red-700 hover:bg-red-50 p-1.5 rounded-lg transition-colors cursor-pointer dark:hover:bg-red-950/20"
                            title={isAr ? "حذف العضو بالكامل" : "Delete Member"}
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Campaigns & Ads Tab */}
      {activeTab === "campaigns" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Add campaign form */}
          <div className="bg-white border border-gray-100 p-5 rounded-2xl shadow-sm h-fit">
            <h3 className="font-sans text-xs font-bold text-gray-900 mb-4 flex items-center gap-2">
              <Megaphone className="h-4 w-4 text-emerald-600" />
              إنشاء إعلان أو حملة تسويقية جديدة
            </h3>
            <form onSubmit={handleAddCampaignSubmit} className="space-y-3">
              <div>
                <label className="block text-[11px] text-gray-400 mb-1 font-sans">عنوان الإعلان</label>
                <input 
                  type="text"
                  placeholder="مثال: خصم 40% للتسجيل المبكر في مادة الرياضيات"
                  value={promoForm.title}
                  onChange={(e) => setPromoForm({...promoForm, title: e.target.value})}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-right text-xs"
                />
              </div>
              <div>
                <label className="block text-[11px] text-gray-400 mb-1 font-sans">تفاصيل الإعلان أو الشعار الترويجي</label>
                <textarea 
                  placeholder="اكتب محتوى الإعلان الذي سيظهر في الصفحة الرئيسية للطلاب..."
                  value={promoForm.description}
                  onChange={(e) => setPromoForm({...promoForm, description: e.target.value})}
                  rows={3}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-right text-xs"
                />
              </div>
              <div>
                <label className="block text-[11px] text-gray-400 mb-1 font-sans">رابط الصورة التعبيرية المرافقة</label>
                <input 
                  type="text"
                  placeholder="https://..."
                  value={promoForm.imageUrl}
                  onChange={(e) => setPromoForm({...promoForm, imageUrl: e.target.value})}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-right text-xs"
                />
              </div>
              <button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-sans text-xs font-semibold py-2 rounded-xl transition-colors cursor-pointer">
                إطلاق الإعلان فوراً
              </button>
            </form>
          </div>

          {/* List of current campaigns */}
          <div className="lg:col-span-2 bg-white border border-gray-100 p-5 rounded-2xl shadow-sm">
            <h3 className="font-sans text-xs font-bold text-gray-900 mb-4">الحملات النشطة والمعلنة حالياً</h3>
            <div className="space-y-3">
              {campaigns.map((camp) => (
                <div key={camp.id} className="flex flex-col sm:flex-row items-center gap-4 p-4 border border-gray-100 rounded-xl hover:bg-gray-50/50">
                  <img src={camp.imageUrl} alt={camp.title} className="h-20 w-32 object-cover rounded-lg border shadow-sm" referrerPolicy="no-referrer" />
                  <div className="flex-1 text-right">
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="font-sans text-xs font-bold text-gray-900">{camp.title}</h4>
                      <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${camp.active ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' : 'bg-gray-100 text-gray-400 border border-gray-200'}`}>
                        {camp.active ? "نشط حالياً" : "متوقف مؤقتاً"}
                      </span>
                    </div>
                    <p className="font-sans text-[11px] text-gray-500 mb-3">{camp.description}</p>
                    <div className="flex gap-2 justify-end">
                      <button 
                        onClick={() => {
                          onToggleCampaign(camp.id);
                          triggerNotification("تم تغيير حالة تفعيل الإعلان");
                        }}
                        className={`font-sans text-[10px] px-3 py-1 rounded-lg border cursor-pointer ${camp.active ? 'bg-gray-100 border-gray-200 text-gray-600' : 'bg-emerald-50 border-emerald-200 text-emerald-600'}`}
                      >
                        {camp.active ? "إيقاف مؤقت" : "تفعيل ونشر"}
                      </button>
                      <button 
                        onClick={() => {
                          onDeleteCampaign(camp.id);
                          triggerNotification("تم حذف الإعلان بشكل كامل");
                        }}
                        className="font-sans text-[10px] bg-red-50 text-red-600 border border-red-100 px-3 py-1 rounded-lg cursor-pointer hover:bg-red-100"
                      >
                        إزالة كاملة
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

      {/* Courses and Curriculum Management Tab */}
      {activeTab === "courses" && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 text-right">
          
          {/* Right Column: Define / Edit Course Form */}
          <div className="lg:col-span-1 bg-white border border-gray-100 p-6 rounded-2xl shadow-sm h-fit">
            <h3 className="font-sans text-xs font-bold text-gray-900 mb-2 flex items-center justify-end gap-2">
              <GraduationCap className="h-5 w-5 text-emerald-600" />
              {editingCourseId ? "تعديل بيانات الدورة" : "تعريف دورة جديدة"}
            </h3>
            <p className="font-sans text-[11px] text-gray-400 mb-4">
              {editingCourseId ? "تعديل تفاصيل الدورة، المواد الدراسية، والمعلمين المسؤولين عنها" : "إنشاء دورة تعليمية جديدة، وتحديد مناهجها، وتعيين طاقم المعلمين"}
            </p>

            <form onSubmit={handleCourseSubmit} className="space-y-4">
              <div>
                <label className="block font-sans text-[11px] font-bold text-gray-600 mb-1">اسم الدورة *</label>
                <input
                  type="text"
                  value={courseForm.name}
                  onChange={(e) => setCourseForm({ ...courseForm, name: e.target.value })}
                  placeholder="مثال: دورة العلوم الهندسية المتكاملة"
                  className="w-full font-sans text-xs bg-gray-50 border border-gray-100 rounded-xl px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:bg-white transition-all text-right"
                  required
                />
              </div>

              <div>
                <label className="block font-sans text-[11px] font-bold text-gray-600 mb-1">الرمز العلمي / التعريفي للدورة *</label>
                <input
                  type="text"
                  value={courseForm.code}
                  onChange={(e) => setCourseForm({ ...courseForm, code: e.target.value })}
                  placeholder="مثال: ENG-SCI"
                  className="w-full font-sans text-xs bg-gray-50 border border-gray-100 rounded-xl px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:bg-white transition-all text-right"
                  required
                />
              </div>

              <div>
                <label className="block font-sans text-[11px] font-bold text-gray-600 mb-1">وصف الدورة</label>
                <textarea
                  value={courseForm.description}
                  onChange={(e) => setCourseForm({ ...courseForm, description: e.target.value })}
                  placeholder="شرح موجز لأهداف الدورة والجمهور المستهدف..."
                  rows={3}
                  className="w-full font-sans text-xs bg-gray-50 border border-gray-100 rounded-xl px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:bg-white transition-all text-right resize-none"
                />
              </div>

              {/* Subject assignment */}
              <div>
                <label className="block font-sans text-[11px] font-bold text-gray-600 mb-2">المناهج أو المواد الدراسية للدورة</label>
                <div className="bg-gray-50 border border-gray-100 rounded-xl p-3 max-h-40 overflow-y-auto scrollbar-thin space-y-2">
                  {subjects.length === 0 ? (
                    <p className="font-sans text-[10px] text-gray-400 text-center">لا توجد مواد مضافة بعد</p>
                  ) : (
                    subjects.map((subj) => {
                      const checked = courseForm.subjectIds.includes(subj.id);
                      return (
                        <label key={subj.id} className="flex items-center justify-between cursor-pointer group p-1 hover:bg-white rounded transition-colors">
                          <span className="font-sans text-[11px] text-gray-700 group-hover:text-emerald-600 transition-colors">
                            {subj.name} ({subj.code})
                          </span>
                          <input
                            type="checkbox"
                            checked={checked}
                            onChange={() => {
                              const newIds = checked
                                ? courseForm.subjectIds.filter(id => id !== subj.id)
                                : [...courseForm.subjectIds, subj.id];
                              setCourseForm({ ...courseForm, subjectIds: newIds });
                            }}
                            className="h-3.5 w-3.5 text-emerald-600 border-gray-300 rounded focus:ring-emerald-500 cursor-pointer"
                          />
                        </label>
                      );
                    })
                  )}
                </div>
              </div>

              {/* Teacher assignment */}
              <div>
                <label className="block font-sans text-[11px] font-bold text-gray-600 mb-2">المعلمون المسؤولون عن الدورة</label>
                <div className="bg-gray-50 border border-gray-100 rounded-xl p-3 max-h-40 overflow-y-auto scrollbar-thin space-y-2">
                  {users.filter(u => u.role === UserRole.TEACHER).length === 0 ? (
                    <p className="font-sans text-[10px] text-gray-400 text-center">لا يوجد معلمون في النظام</p>
                  ) : (
                    users.filter(u => u.role === UserRole.TEACHER).map((teach) => {
                      const checked = courseForm.teacherIds.includes(teach.id);
                      return (
                        <label key={teach.id} className="flex items-center justify-between cursor-pointer group p-1 hover:bg-white rounded transition-colors">
                          <span className="font-sans text-[11px] text-gray-700 group-hover:text-emerald-600 transition-colors">
                            {teach.name}
                          </span>
                          <input
                            type="checkbox"
                            checked={checked}
                            onChange={() => {
                              const newIds = checked
                                ? courseForm.teacherIds.filter(id => id !== teach.id)
                                : [...courseForm.teacherIds, teach.id];
                              setCourseForm({ ...courseForm, teacherIds: newIds });
                            }}
                            className="h-3.5 w-3.5 text-emerald-600 border-gray-300 rounded focus:ring-emerald-500 cursor-pointer"
                          />
                        </label>
                      );
                    })
                  )}
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="submit"
                  className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-sans text-xs font-semibold py-2.5 rounded-xl cursor-pointer transition-colors shadow-sm text-center"
                >
                  {editingCourseId ? "تحديث الدورة" : "حفظ الدورة وتعميدها"}
                </button>
                {editingCourseId && (
                  <button
                    type="button"
                    onClick={() => {
                      setEditingCourseId(null);
                      setCourseForm({ name: "", description: "", code: "", subjectIds: [], teacherIds: [] });
                      triggerNotification("تم إلغاء التعديل");
                    }}
                    className="bg-gray-100 hover:bg-gray-200 text-gray-600 font-sans text-xs font-semibold px-4 py-2.5 rounded-xl cursor-pointer transition-colors"
                  >
                    إلغاء
                  </button>
                )}
              </div>
            </form>
          </div>

          {/* Left Column: List of Courses */}
          <div className="lg:col-span-2 space-y-4">
            <div className="bg-white border border-gray-100 p-6 rounded-2xl shadow-sm">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-4">
                <div className="text-right">
                  <h3 className="font-sans text-xs font-bold text-gray-900">سجل الدورات المعتمدة</h3>
                  <p className="font-sans text-[11px] text-gray-400 mt-0.5">الدورات الأكاديمية المصنفة والبرامج المتكاملة المسجلة حالياً</p>
                </div>
                <div className="font-sans text-[11px] bg-indigo-50 text-indigo-700 px-3 py-1 rounded-xl font-bold border border-indigo-100">
                  إجمالي البرامج والدورات: {courses.length}
                </div>
              </div>

              {courses.length === 0 ? (
                <div className="text-center py-12 bg-gray-50/50 rounded-2xl border border-dashed border-gray-200">
                  <GraduationCap className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                  <p className="font-sans text-xs font-semibold text-gray-500">لا توجد دورات مسجلة حالياً في النظام</p>
                  <p className="font-sans text-[11px] text-gray-400 mt-1">ابدأ بتعريف أول دورة أكاديمية عبر النموذج الجانبي</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {courses.map((crs) => {
                    // Find subjects
                    const crsSubjects = subjects.filter(s => crs.subjectIds.includes(s.id));
                    // Find teachers
                    const crsTeachers = users.filter(u => crs.teacherIds.includes(u.id));

                    return (
                      <div key={crs.id} className="bg-white border border-gray-100 p-5 rounded-2xl hover:shadow-md hover:border-gray-200 transition-all flex flex-col justify-between space-y-4 relative group">
                        
                        <div>
                          {/* Course name and code */}
                          <div className="flex items-start justify-between mb-2">
                            <h4 className="font-sans text-xs font-extrabold text-gray-950 flex-1 line-clamp-2">
                              {crs.name}
                            </h4>
                            <span className="font-mono text-[10px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded-lg border border-slate-200 font-bold mr-2 select-all">
                              {crs.code}
                            </span>
                          </div>

                          {/* Description */}
                          <p className="font-sans text-[11px] text-gray-500 line-clamp-3 leading-relaxed mb-4">
                            {crs.description || "لا يوجد وصف محدد لهذه الدورة حتى الآن."}
                          </p>

                          {/* Curriculums/Subjects list */}
                          <div className="space-y-2 mb-4">
                            <span className="block font-sans text-[10px] font-bold text-gray-400">المناهج المشمولة ({crsSubjects.length})</span>
                            <div className="flex flex-wrap gap-1.5">
                              {crsSubjects.length === 0 ? (
                                <span className="font-sans text-[9px] text-gray-400 bg-gray-50 px-2 py-0.5 rounded border border-gray-100">غير محدد</span>
                              ) : (
                                crsSubjects.map(s => (
                                  <span key={s.id} className="font-sans text-[10px] bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-lg border border-emerald-100 font-medium">
                                    {s.name}
                                  </span>
                                ))
                              )}
                            </div>
                          </div>

                          {/* Assigned Teachers list */}
                          <div className="space-y-2">
                            <span className="block font-sans text-[10px] font-bold text-gray-400">المعلمون المسؤولون ({crsTeachers.length})</span>
                            <div className="flex flex-wrap gap-2">
                              {crsTeachers.length === 0 ? (
                                <span className="font-sans text-[9px] text-gray-400 bg-gray-50 px-2 py-0.5 rounded border border-gray-100">لم يتم التعيين</span>
                              ) : (
                                crsTeachers.map(t => (
                                  <div key={t.id} className="flex items-center gap-1.5 bg-indigo-50/50 text-indigo-700 px-2 py-1 rounded-lg border border-indigo-100/50">
                                    <img src={t.avatar} alt={t.name} className="h-4 w-4 rounded-full object-cover border border-indigo-200" referrerPolicy="no-referrer" />
                                    <span className="font-sans text-[10px] font-semibold">{t.name.split(" ")[0] || t.name}</span>
                                  </div>
                                ))
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Actions block */}
                        <div className="flex justify-end gap-2 pt-3 border-t border-gray-50 mt-auto">
                          <button
                            type="button"
                            onClick={() => {
                              setEditingCourseId(crs.id);
                              setCourseForm({
                                name: crs.name,
                                description: crs.description,
                                code: crs.code,
                                subjectIds: crs.subjectIds || [],
                                teacherIds: crs.teacherIds || []
                              });
                              triggerNotification("أنت تعدل حالياً على " + crs.name);
                            }}
                            className="p-1.5 rounded-lg text-gray-500 hover:text-indigo-600 hover:bg-indigo-50 border border-transparent hover:border-indigo-100 cursor-pointer transition-all"
                            title="تعديل الدورة"
                          >
                            <Edit className="h-3.5 w-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              if (window.confirm(`هل أنت متأكد من رغبتك في حذف دورة "${crs.name}"؟`)) {
                                onDeleteCourse(crs.id);
                                triggerNotification("تم إزالة الدورة التعليمية بنجاح");
                                if (editingCourseId === crs.id) {
                                  setEditingCourseId(null);
                                  setCourseForm({ name: "", description: "", code: "", subjectIds: [], teacherIds: [] });
                                }
                              }
                            }}
                            className="p-1.5 rounded-lg text-gray-500 hover:text-red-600 hover:bg-red-50 border border-transparent hover:border-red-100 cursor-pointer transition-all"
                            title="حذف الدورة"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>

                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

        </div>
      )}

      {/* Audit Log Tab */}
      {activeTab === "audit" && (
        <div className="bg-white border border-gray-100 rounded-2xl shadow-sm p-6">
          <div className="flex justify-between items-center mb-4">
            <div className="text-right">
              <h3 className="font-sans text-xs font-bold text-gray-900 flex items-center gap-2 justify-end">
                <Activity className="h-4 w-4 text-emerald-600" />
                سجل الأمان والعمليات (Audit Logs)
              </h3>
              <p className="font-sans text-[11px] text-gray-400 mt-0.5">تعقب حركات المستخدمين، دخولهم، إنجاز الواجبات وتعديل الدروس</p>
            </div>
          </div>

          <div className="space-y-2">
            {logs.map((log) => (
              <div key={log.id} className="flex items-center justify-between p-3 rounded-xl border border-gray-50 hover:bg-gray-50 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="font-mono text-[10px] text-gray-400 flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {new Date(log.timestamp).toLocaleTimeString("ar-EG")}
                  </div>
                  <div className="text-right">
                    <span className="font-sans text-xs font-semibold text-gray-800">{log.action}</span>
                    <p className="font-sans text-[10px] text-gray-400 mt-0.5">{log.details}</p>
                  </div>
                </div>
                
                <div className="text-left font-sans">
                  <span className="text-[11px] font-bold text-gray-900 block">{log.userName}</span>
                  <span className={`inline-block text-[9px] bg-gray-100 text-gray-500 px-1.5 py-0.2 rounded`}>
                    {log.userRole === UserRole.ADMIN ? "مدير" : log.userRole === UserRole.TEACHER ? "معلم" : "طالب"}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Database Import/Export Tab */}
      {activeTab === "database" && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          <div className="bg-white border border-gray-100 p-6 rounded-2xl shadow-sm text-right space-y-4">
            <div className="h-12 w-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <Download className="h-6 w-6" />
            </div>
            <div>
              <h4 className="font-sans text-xs font-bold text-gray-900">تصدير النسخة الاحتياطية للمنصة</h4>
              <p className="font-sans text-[11px] text-gray-400 mt-1">تنزيل ملف بصيغة JSON يحتوي على المناهج كاملة، الدروس، الواجبات، التنبيهات، وقائمة المستخدمين لحفظها بأمان.</p>
            </div>
            <button 
              onClick={onExportData}
              className="bg-emerald-600 hover:bg-emerald-700 text-white font-sans text-xs font-semibold px-5 py-2 rounded-xl transition-colors cursor-pointer flex items-center gap-2 justify-center w-full sm:w-auto"
            >
              <Download className="h-4 w-4" />
              تنزيل ملف الاحتياط (JSON)
            </button>
          </div>

          <div className="bg-white border border-gray-100 p-6 rounded-2xl shadow-sm text-right space-y-4">
            <div className="h-12 w-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Upload className="h-6 w-6" />
            </div>
            <div>
              <h4 className="font-sans text-xs font-bold text-gray-900">استعادة البيانات والدمج</h4>
              <p className="font-sans text-[11px] text-gray-400 mt-1">رفع ملف JSON الذي تم تصديره مسبقاً لاستبدال أو دمج بيانات المناهج والصفوف الحالية على الفور.</p>
            </div>
            
            <div className="flex gap-2">
              <input 
                type="file"
                ref={fileInputRef}
                onChange={handleFileUpload}
                accept=".json"
                className="hidden"
              />
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="bg-indigo-600 hover:bg-indigo-700 text-white font-sans text-xs font-semibold px-5 py-2 rounded-xl transition-colors cursor-pointer flex items-center gap-2 justify-center w-full"
              >
                <Upload className="h-4 w-4" />
                اختر ملف الرفع (JSON)
              </button>
            </div>
          </div>

        </div>
      )}

    </div>
  );
};
