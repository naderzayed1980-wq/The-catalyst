import React, { useState } from "react";
import { 
  Plus, 
  BookOpen, 
  ClipboardList, 
  CheckCircle, 
  GraduationCap, 
  FileText, 
  MessageSquare, 
  HelpCircle,
  Clock,
  ExternalLink,
  ChevronRight,
  BookMarked,
  Sparkles,
  Award,
  AlertCircle
} from "lucide-react";
import { 
  User, 
  UserRole, 
  Subject, 
  Course,
  Lesson, 
  Assignment, 
  AssignmentSubmission, 
  Quiz, 
  GlossaryTerm, 
  EducationalResource,
  ForumPost,
  AttendanceRecord
} from "../types";

interface TeacherDashboardProps {
  currentUser: User;
  subjects: Subject[];
  lessons: Lesson[];
  assignments: Assignment[];
  submissions: AssignmentSubmission[];
  glossary: GlossaryTerm[];
  resources: EducationalResource[];
  posts: ForumPost[];
  students: User[];
  courses: Course[];
  attendance: AttendanceRecord[];
  onUpdateAttendance: (
    studentId: string, 
    studentName: string, 
    date: string, 
    status: "PRESENT" | "ABSENT" | "LATE", 
    checkInTime?: string, 
    checkOutTime?: string,
    notifyParent?: boolean
  ) => void;
  onAddAssignment: (assignment: Omit<Assignment, "id">) => void;
  onGradeSubmission: (id: string, grade: number, feedback: string) => void;
  onAddGlossaryTerm: (term: Omit<GlossaryTerm, "id">) => void;
  onAddResource: (resource: Omit<EducationalResource, "id">) => void;
  onAddForumReply: (postId: string, replyContent: string) => void;
}

export const TeacherDashboard: React.FC<TeacherDashboardProps> = ({
  currentUser,
  subjects,
  lessons,
  assignments,
  submissions,
  glossary,
  resources,
  posts,
  students,
  courses,
  attendance,
  onUpdateAttendance,
  onAddAssignment,
  onGradeSubmission,
  onAddGlossaryTerm,
  onAddResource,
  onAddForumReply
}) => {
  const [activeTab, setActiveTab] = useState<"grading" | "assignments" | "resources" | "forum" | "attendance">("grading");
  
  // States for homework creator
  const [assignForm, setAssignForm] = useState({
    subjectId: "",
    lessonId: "",
    title: "",
    description: "",
    dueDate: "2026-07-15"
  });
  
  const [questions, setQuestions] = useState<{ type: "MULTIPLE_CHOICE" | "SHORT_ANSWER"; questionText: string; options: string[]; correctAnswer: string }[]>([
    { type: "MULTIPLE_CHOICE", questionText: "", options: ["", "", "", ""], correctAnswer: "" }
  ]);

  // States for resources/glossary
  const [glossaryForm, setGlossaryForm] = useState({ term: "", definition: "", subjectId: "" });
  const [resourceForm, setResourceForm] = useState({ title: "", type: "BOOK" as const, category: "الفيزياء", url: "", description: "" });
  
  // Active grading sub-state
  const [gradingSubmissionId, setGradingSubmissionId] = useState<string | null>(null);
  const [gradeInput, setGradeInput] = useState<number>(100);
  const [feedbackInput, setFeedbackInput] = useState("");
  
  // Forum reply text
  const [replyText, setReplyText] = useState<{ [postId: string]: string }>({});

  const [notif, setNotif] = useState<string | null>(null);

  const triggerNotif = (text: string) => {
    setNotif(text);
    setTimeout(() => setNotif(null), 3000);
  };

  // Handlers
  const handleAddQuestion = () => {
    setQuestions([...questions, { type: "SHORT_ANSWER", questionText: "", options: ["", "", "", ""], correctAnswer: "" }]);
  };

  const handleQuestionChange = (index: number, field: string, value: any) => {
    const updated = [...questions];
    updated[index] = { ...updated[index], [field]: value };
    setQuestions(updated);
  };

  const handleOptionChange = (qIndex: number, optIndex: number, val: string) => {
    const updated = [...questions];
    if (updated[qIndex].options) {
      updated[qIndex].options![optIndex] = val;
    }
    setQuestions(updated);
  };

  const handleCreateAssignment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!assignForm.subjectId || !assignForm.lessonId || !assignForm.title) {
      alert("يرجى اختيار المادة وتحديد الدرس وعنوان الواجب");
      return;
    }

    const formattedQuestions = questions.map((q, idx) => ({
      id: `q-gen-${idx}-${Date.now()}`,
      type: q.type,
      questionText: q.questionText || "السؤال التقييمي",
      options: q.type === "MULTIPLE_CHOICE" ? q.options.filter(o => o !== "") : undefined,
      correctAnswer: q.correctAnswer || q.options[0]
    }));

    onAddAssignment({
      subjectId: assignForm.subjectId,
      lessonId: assignForm.lessonId,
      title: assignForm.title,
      description: assignForm.description,
      dueDate: assignForm.dueDate,
      questions: formattedQuestions
    });

    // Reset forms
    setAssignForm({ subjectId: "", lessonId: "", title: "", description: "", dueDate: "2026-07-20" });
    setQuestions([{ type: "MULTIPLE_CHOICE", questionText: "", options: ["", "", "", ""], correctAnswer: "" }]);
    triggerNotif("تم إنشاء الواجب المدرسي وربطه بالدرس بنجاح!");
  };

  const handleGradeSubmit = (submId: string) => {
    onGradeSubmission(submId, Number(gradeInput), feedbackInput);
    setGradingSubmissionId(null);
    setFeedbackInput("");
    triggerNotif("تم رصد درجة الطالب بنجاح!");
  };

  const handleAddGlossarySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!glossaryForm.term || !glossaryForm.definition || !glossaryForm.subjectId) return;
    onAddGlossaryTerm({
      term: glossaryForm.term,
      definition: glossaryForm.definition,
      subjectId: glossaryForm.subjectId
    });
    setGlossaryForm({ term: "", definition: "", subjectId: "" });
    triggerNotif("تمت إضافة المصطلح العلمي إلى المعجم");
  };

  const handleAddResourceSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!resourceForm.title || !resourceForm.url) return;
    onAddResource({
      title: resourceForm.title,
      type: resourceForm.type,
      category: resourceForm.category,
      url: resourceForm.url,
      description: resourceForm.description
    });
    setResourceForm({ title: "", type: "BOOK", category: "الفيزياء", url: "", description: "" });
    triggerNotif("تم رفع المرجع والمورد الإضافي بنجاح");
  };

  const handleReplySubmit = (postId: string) => {
    const text = replyText[postId];
    if (!text || !text.trim()) return;
    onAddForumReply(postId, text.trim());
    setReplyText(prev => ({ ...prev, [postId]: "" }));
    triggerNotif("تم الرد على استفسار الطالب ونشر الإجابة العلمية");
  };

  // Filter components taught by teacher
  const teacherSubjects = subjects.filter(s => s.teacherId === currentUser.id);
  const teacherSubjectIds = teacherSubjects.map(s => s.id);
  const teacherCourses = courses.filter(c => c.teacherIds.includes(currentUser.id));

  const relevantSubmissions = submissions.filter(subm => {
    const assign = assignments.find(a => a.id === subm.assignmentId);
    return assign && teacherSubjectIds.includes(assign.subjectId);
  });

  const pendingSubmissions = relevantSubmissions.filter(s => s.status === "SUBMITTED");
  const gradedSubmissions = relevantSubmissions.filter(s => s.status === "GRADED");

  return (
    <div className="py-6 font-sans text-right" dir="rtl" id="teacher-dashboard-container">
      
      {/* Toast Alert */}
      {notif && (
        <div className="fixed bottom-6 left-6 z-50 rounded-xl bg-emerald-600 px-4 py-3 text-white flex items-center gap-2 shadow-lg animate-bounce">
          <CheckCircle className="h-4 w-4" />
          <span className="text-xs font-semibold">{notif}</span>
        </div>
      )}

      {/* Profile Overview */}
      <div className="bg-gradient-to-l from-indigo-900 to-slate-900 rounded-2xl p-6 text-white mb-6 border border-indigo-950 flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-2 justify-end">
            <span className="bg-white/10 text-indigo-300 border border-white/10 px-2.5 py-0.5 rounded-full text-[10px] font-bold">بوابة المعلمين</span>
            <GraduationCap className="h-5 w-5 text-indigo-400" />
          </div>
          <h2 className="font-sans text-lg font-bold">{currentUser.name}</h2>
          <p className="font-sans text-xs text-indigo-200 mt-1">تخصص: {currentUser.specialization || "العلوم الأكاديمية"}</p>
        </div>
        <div className="flex gap-4">
          <div className="bg-white/5 border border-white/5 px-4 py-3 rounded-xl text-center">
            <span className="text-[10px] text-indigo-300 block mb-0.5">واجبات تحتاج تصحيح</span>
            <span className="font-mono text-xl font-bold text-white">{pendingSubmissions.length}</span>
          </div>
          <div className="bg-white/5 border border-white/5 px-4 py-3 rounded-xl text-center">
            <span className="text-[10px] text-indigo-300 block mb-0.5">موادك التدريسية</span>
            <span className="font-mono text-xl font-bold text-white">{teacherSubjects.length}</span>
          </div>
        </div>
      </div>

      {/* Assigned Courses Section */}
      {teacherCourses.length > 0 && (
        <div className="bg-white border border-gray-100 rounded-2xl p-5 mb-6 shadow-sm">
          <h3 className="font-sans text-xs font-bold text-gray-900 mb-3 flex items-center justify-end gap-2">
            <GraduationCap className="h-4 w-4 text-indigo-600" />
            الدورات والبرامج الأكاديمية المسندة إليك ({teacherCourses.length})
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-right">
            {teacherCourses.map((crs) => {
              const crsSubjects = subjects.filter(s => crs.subjectIds.includes(s.id));
              return (
                <div key={crs.id} className="border border-gray-50 bg-gray-50/20 p-4 rounded-xl flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-mono text-[9px] bg-indigo-50 text-indigo-600 px-2 py-0.5 rounded border border-indigo-100 font-bold">
                        {crs.code}
                      </span>
                      <h4 className="font-sans text-xs font-bold text-gray-900">{crs.name}</h4>
                    </div>
                    <p className="font-sans text-[11px] text-gray-500 line-clamp-2 mb-3 mt-1.5">{crs.description || "لا يوجد وصف محدد لهذه الدورة."}</p>
                  </div>
                  
                  <div className="space-y-1">
                    <span className="block font-sans text-[9px] font-bold text-gray-400">المناهج المشمولة:</span>
                    <div className="flex flex-wrap gap-1">
                      {crsSubjects.length === 0 ? (
                        <span className="font-sans text-[9px] text-gray-400">غير محددة</span>
                      ) : (
                        crsSubjects.map(s => (
                          <span key={s.id} className="font-sans text-[9px] bg-white text-gray-700 border border-gray-100 px-1.5 py-0.5 rounded">
                            {s.name}
                          </span>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Navigation tabs */}
      <div className="flex flex-wrap items-center justify-start gap-2 border-b border-gray-100 pb-4 mb-6">
        <button
          onClick={() => setActiveTab("grading")}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer transition-all ${activeTab === "grading" ? "bg-indigo-600 text-white" : "hover:bg-gray-50 text-gray-600 bg-white border border-gray-100"}`}
        >
          <ClipboardList className="h-4 w-4" />
          تصحيح الواجبات
          {pendingSubmissions.length > 0 && (
            <span className="bg-red-500 text-white rounded-full px-1.5 py-0.2 text-[9px] font-bold">
              {pendingSubmissions.length}
            </span>
          )}
        </button>
        <button
          onClick={() => setActiveTab("assignments")}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer transition-all ${activeTab === "assignments" ? "bg-indigo-600 text-white" : "hover:bg-gray-50 text-gray-600 bg-white border border-gray-100"}`}
        >
          <Plus className="h-4 w-4" />
          بناء الواجبات والتمارين
        </button>
        <button
          onClick={() => setActiveTab("resources")}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer transition-all ${activeTab === "resources" ? "bg-indigo-600 text-white" : "hover:bg-gray-50 text-gray-600 bg-white border border-gray-100"}`}
        >
          <BookMarked className="h-4 w-4" />
          المكتبة والمعجم العلمي
        </button>
        <button
          onClick={() => setActiveTab("forum")}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer transition-all ${activeTab === "forum" ? "bg-indigo-600 text-white" : "hover:bg-gray-50 text-gray-600 bg-white border border-gray-100"}`}
        >
          <MessageSquare className="h-4 w-4" />
          منتدى استفسارات الطلاب
        </button>
        <button
          onClick={() => setActiveTab("attendance")}
          className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer transition-all ${activeTab === "attendance" ? "bg-indigo-600 text-white" : "hover:bg-gray-50 text-gray-600 bg-white border border-gray-100"}`}
        >
          <Clock className="h-4 w-4" />
          رصد غياب وحضور الطلاب
        </button>
      </div>

      {/* GRADING TAB */}
      {activeTab === "grading" && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* List of submissions */}
            <div className="lg:col-span-2 space-y-4">
              <div className="bg-white border border-gray-100 p-5 rounded-2xl shadow-sm">
                <h3 className="font-sans text-xs font-bold text-gray-900 mb-3">واجبات الطلاب المسلمة حديثاً</h3>
                <p className="font-sans text-[11px] text-gray-400 mb-4">اضغط على اسم الواجب لبدء عملية التقييم وكتابة الملاحظات التصحيحية</p>

                {pendingSubmissions.length === 0 ? (
                  <div className="p-8 text-center bg-gray-50 rounded-xl border border-dashed border-gray-200">
                    <CheckCircle className="h-10 w-10 text-emerald-500 mx-auto mb-2" />
                    <p className="font-sans text-xs text-gray-700 font-bold">تم تصحيح كافة الواجبات العلمية!</p>
                    <p className="font-sans text-[10px] text-gray-400 mt-1">لا توجد تسليمات معلقة من طلابك حالياً</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {pendingSubmissions.map((subm) => {
                      const assign = assignments.find(a => a.id === subm.assignmentId);
                      const student = students.find(s => s.id === subm.studentId);
                      return (
                        <div 
                          key={subm.id}
                          onClick={() => {
                            setGradingSubmissionId(subm.id);
                            setGradeInput(100);
                          }}
                          className={`p-3.5 border rounded-xl flex items-center justify-between font-sans transition-all cursor-pointer ${gradingSubmissionId === subm.id ? 'border-indigo-600 bg-indigo-50/20 shadow-md' : 'border-gray-100 hover:bg-gray-50/50'}`}
                        >
                          <div className="text-right">
                            <span className="bg-amber-50 text-amber-600 font-bold text-[9px] px-1.5 py-0.5 rounded-full">بانتظار الرصد</span>
                            <h4 className="font-bold text-xs text-gray-900 mt-1">{assign?.title}</h4>
                            <p className="text-[10px] text-gray-400 mt-0.5">الطالب: {student?.name}</p>
                          </div>
                          <ChevronRight className="h-4 w-4 text-gray-400" />
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* History of Graded items */}
              <div className="bg-white border border-gray-100 p-5 rounded-2xl shadow-sm">
                <h3 className="font-sans text-xs font-bold text-gray-900 mb-3">الواجبات المصححة والمقيمة سابقاً</h3>
                <div className="space-y-2">
                  {gradedSubmissions.length === 0 ? (
                    <p className="text-center font-sans text-xs text-gray-400 p-4">لا توجد سجلات لواجبات مصححة بعد.</p>
                  ) : (
                    gradedSubmissions.map((subm) => {
                      const assign = assignments.find(a => a.id === subm.assignmentId);
                      const student = students.find(s => s.id === subm.studentId);
                      return (
                        <div key={subm.id} className="p-3 border border-gray-50 rounded-xl flex items-center justify-between text-right font-sans">
                          <div>
                            <h4 className="font-bold text-xs text-gray-800">{assign?.title}</h4>
                            <span className="text-[10px] text-gray-400">الطالب: {student?.name}</span>
                          </div>
                          <div className="text-left">
                            <span className="font-mono text-xs font-bold text-emerald-600 block">{subm.grade}/100</span>
                            <span className="text-[9px] text-gray-400">تم التصحيح</span>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            </div>

            {/* Submissions grading active screen details */}
            <div className="lg:col-span-1">
              {gradingSubmissionId ? (() => {
                const activeSubm = submissions.find(s => s.id === gradingSubmissionId)!;
                const assign = assignments.find(a => a.id === activeSubm.assignmentId)!;
                const student = students.find(s => s.id === activeSubm.studentId)!;

                return (
                  <div className="bg-white border border-indigo-100 rounded-2xl shadow-md p-5 text-right space-y-4">
                    <div className="border-b border-gray-150 pb-3">
                      <span className="text-[10px] text-indigo-600 font-bold font-sans">تقييم تسليم الطالب</span>
                      <h3 className="font-sans text-xs font-bold text-gray-900 mt-1">{student.name}</h3>
                      <p className="font-sans text-[11px] text-gray-400">{assign.title}</p>
                    </div>

                    {/* Student answers comparison */}
                    <div className="space-y-3">
                      <h4 className="font-sans text-[11px] font-bold text-indigo-950">إجابات الطالب المقدمة:</h4>
                      {assign.questions.map((q, idx) => {
                        const studentAns = activeSubm.answers.find(a => a.questionId === q.id);
                        return (
                          <div key={q.id} className="bg-gray-50 p-3 rounded-xl border border-gray-100 text-xs font-sans">
                            <p className="font-medium text-gray-800">{idx + 1}. {q.questionText}</p>
                            <div className="mt-2 text-[11px]">
                              <span className="text-gray-400 block">إجابة الطالب:</span>
                              <span className="font-semibold text-indigo-700 block mt-0.5">"{studentAns?.answerText || "(لم يتم الإجابة)"}"</span>
                            </div>
                            <div className="mt-1.5 text-[10px] bg-emerald-50 text-emerald-700 p-1.5 rounded">
                              <span className="font-bold">الإجابة النموذجية المبرمجة:</span> {q.correctAnswer}
                            </div>
                          </div>
                        );
                      })}
                    </div>

                    {/* Form Grade */}
                    <div className="space-y-3 border-t border-gray-100 pt-3">
                      <div>
                        <label className="block text-[11px] text-gray-400 mb-1 font-sans">رصد الدرجة (من 100):</label>
                        <input 
                          type="number"
                          max={100}
                          min={0}
                          value={gradeInput}
                          onChange={(e) => setGradeInput(Number(e.target.value))}
                          className="w-full bg-gray-50 border border-gray-200 rounded-lg p-2 font-mono text-center text-xs font-bold"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] text-gray-400 mb-1 font-sans">ملاحظات المعلم والتصحيح التوجيهي:</label>
                        <textarea 
                          placeholder="مثال: أحسنت كتابة القوانين، لكن انتبه لاختصار الأرقام النهائية..."
                          value={feedbackInput}
                          onChange={(e) => setFeedbackInput(e.target.value)}
                          rows={3}
                          className="w-full bg-gray-50 border border-gray-200 rounded-lg p-2 text-right text-xs"
                        />
                      </div>
                      <div className="flex gap-2">
                        <button 
                          onClick={() => handleGradeSubmit(activeSubm.id)}
                          className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white font-sans text-xs font-bold py-2 rounded-xl transition-all cursor-pointer"
                        >
                          رصد الدرجة والتقييم
                        </button>
                        <button 
                          onClick={() => setGradingSubmissionId(null)}
                          className="bg-gray-100 hover:bg-gray-200 text-gray-600 font-sans text-xs py-2 px-3 rounded-xl cursor-pointer"
                        >
                          إلغاء
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })() : (
                <div className="bg-white border border-gray-150 border-dashed rounded-2xl p-8 text-center">
                  <HelpCircle className="h-8 w-8 text-gray-300 mx-auto mb-2" />
                  <p className="font-sans text-xs text-gray-400">يرجى تحديد واجب من القائمة اليمنى لعرض تفاصيل إجابات الطالب وتقييمها ورصد الدرجة</p>
                </div>
              )}
            </div>

          </div>
        </div>
      )}

      {/* CREATING ASSIGNMENTS TAB */}
      {activeTab === "assignments" && (
        <div className="bg-white border border-gray-100 rounded-2xl shadow-sm p-6 max-w-4xl mx-auto">
          <div className="mb-6">
            <h3 className="font-sans text-xs font-bold text-gray-900">إنشاء واجب دراسي جديد وربطه بالمحاضرات</h3>
            <p className="font-sans text-[11px] text-gray-400 mt-1">يتيح لك هذا النموذج صياغة أسئلة تفاعلية للطلاب بتقدير فوري أو تصحيح يدوي</p>
          </div>

          <form onSubmit={handleCreateAssignment} className="space-y-6 text-right">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] text-gray-400 mb-1 font-sans">اختر المادة الدراسية</label>
                <select
                  value={assignForm.subjectId}
                  onChange={(e) => setAssignForm({ ...assignForm, subjectId: e.target.value })}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-2 py-2 text-right text-xs"
                >
                  <option value="">-- اختر مادة --</option>
                  {teacherSubjects.map(s => (
                    <option key={s.id} value={s.id}>{s.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-[11px] text-gray-400 mb-1 font-sans">اربطه بالدرس المخصص</label>
                <select
                  value={assignForm.lessonId}
                  onChange={(e) => setAssignForm({ ...assignForm, lessonId: e.target.value })}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-2 py-2 text-right text-xs"
                >
                  <option value="">-- اختر الدرس --</option>
                  {lessons.filter(l => l.subjectId === assignForm.subjectId).map(l => (
                    <option key={l.id} value={l.id}>{l.title}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[11px] text-gray-400 mb-1 font-sans">عنوان الواجب الدراسي</label>
                <input 
                  type="text"
                  placeholder="مثال: واجب منزلي للباب الأول: قوانين المغناطيسية"
                  value={assignForm.title}
                  onChange={(e) => setAssignForm({ ...assignForm, title: e.target.value })}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 text-right text-xs"
                />
              </div>
              <div>
                <label className="block text-[11px] text-gray-400 mb-1 font-sans">تاريخ التسليم الأقصى (Due Date)</label>
                <input 
                  type="date"
                  value={assignForm.dueDate}
                  onChange={(e) => setAssignForm({ ...assignForm, dueDate: e.target.value })}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 font-mono text-center text-xs"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] text-gray-400 mb-1 font-sans">شرح أو تعليمات موجهة للطلاب</label>
              <textarea 
                placeholder="تفاصيل وشروط حل التدريبات والمراجع المساعدة..."
                value={assignForm.description}
                onChange={(e) => setAssignForm({ ...assignForm, description: e.target.value })}
                rows={2}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl p-3 text-right text-xs"
              />
            </div>

            {/* Questions list creation */}
            <div className="space-y-4 border-t border-gray-100 pt-5">
              <div className="flex items-center justify-between">
                <button 
                  type="button"
                  onClick={handleAddQuestion}
                  className="bg-indigo-50 text-indigo-600 hover:bg-indigo-100 font-sans text-xs font-semibold px-4 py-1.5 rounded-xl cursor-pointer flex items-center gap-1"
                >
                  <Plus className="h-3.5 w-3.5" />
                  إضافة سؤال إضافي
                </button>
                <h4 className="font-sans text-xs font-bold text-gray-900">أسئلة الواجب المدرسي الملحقة</h4>
              </div>

              {questions.map((q, qIdx) => (
                <div key={qIdx} className="p-4 border border-gray-100 rounded-xl bg-gray-50/50 space-y-3">
                  <div className="flex items-center justify-between">
                    <button 
                      type="button" 
                      onClick={() => setQuestions(questions.filter((_, idx) => idx !== qIdx))}
                      className="text-red-500 hover:text-red-700 text-[10px] font-sans"
                    >
                      حذف السؤال
                    </button>
                    <span className="font-sans text-xs font-bold text-indigo-900">السؤال رقم {qIdx + 1}</span>
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <div className="col-span-2">
                      <label className="block text-[10px] text-gray-400 mb-1">نص السؤال الأكاديمي</label>
                      <input 
                        type="text"
                        placeholder="ما هو تأثير زيادة التيار على مقاومة السلك؟"
                        value={q.questionText}
                        onChange={(e) => handleQuestionChange(qIdx, "questionText", e.target.value)}
                        className="w-full bg-white border border-gray-200 rounded-lg px-3 py-1.5 text-right text-xs"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] text-gray-400 mb-1">نوعية السؤال</label>
                      <select
                        value={q.type}
                        onChange={(e) => handleQuestionChange(qIdx, "type", e.target.value)}
                        className="w-full bg-white border border-gray-200 rounded-lg px-2 py-1.5 text-right text-xs font-sans"
                      >
                        <option value="MULTIPLE_CHOICE">اختيار من متعدد</option>
                        <option value="SHORT_ANSWER">إجابة قصيرة / مسائل</option>
                      </select>
                    </div>
                  </div>

                  {q.type === "MULTIPLE_CHOICE" ? (
                    <div className="space-y-2">
                      <label className="block text-[10px] text-gray-400">خيارات الإجابة المقترحة للامتحان:</label>
                      <div className="grid grid-cols-2 gap-2">
                        {q.options.map((opt, optIdx) => (
                          <input 
                            key={optIdx}
                            type="text"
                            placeholder={`خيار ${optIdx + 1}`}
                            value={opt}
                            onChange={(e) => handleOptionChange(qIdx, optIdx, e.target.value)}
                            className="bg-white border border-gray-200 rounded-lg px-2 py-1.5 text-right text-xs"
                          />
                        ))}
                      </div>
                      <div>
                        <label className="block text-[10px] text-gray-400 mb-1">الإجابة الصحيحة (تطابق الإملاء):</label>
                        <input 
                          type="text"
                          placeholder="اكتب الإجابة الصحيحة تماماً من ضمن الخيارات الأربعة"
                          value={q.correctAnswer}
                          onChange={(e) => handleQuestionChange(qIdx, "correctAnswer", e.target.value)}
                          className="w-full bg-white border border-gray-200 rounded-lg px-3 py-1.5 text-right text-xs"
                        />
                      </div>
                    </div>
                  ) : (
                    <div>
                      <label className="block text-[10px] text-gray-400 mb-1">النموذج النموذجي للحل (لأغراض المساعدة والتحقق):</label>
                      <input 
                        type="text"
                        placeholder="الرقم النهائي أو القانون المقبول مثل: 20 أوم"
                        value={q.correctAnswer}
                        onChange={(e) => handleQuestionChange(qIdx, "correctAnswer", e.target.value)}
                        className="w-full bg-white border border-gray-200 rounded-lg px-3 py-1.5 text-right text-xs"
                      />
                    </div>
                  )}
                </div>
              ))}
            </div>

            <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-sans text-xs font-bold py-2.5 rounded-xl transition-all cursor-pointer">
              حفظ ونشر الواجب للطلاب
            </button>
          </form>
        </div>
      )}

      {/* RESOURCES & GLOSSARY TAB */}
      {activeTab === "resources" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* Scientific Glossary Section */}
          <div className="bg-white border border-gray-100 p-5 rounded-2xl shadow-sm text-right space-y-4">
            <div>
              <h3 className="font-sans text-xs font-bold text-gray-900">المعجم العلمي والمفاهيم الأساسية</h3>
              <p className="font-sans text-[11px] text-gray-400 mt-1">أضف المصطلحات والرموز العلمية الصعبة لمساعدة الطلاب على فهم المنهج</p>
            </div>

            <form onSubmit={handleAddGlossarySubmit} className="space-y-3 bg-gray-50/50 p-4 rounded-xl border border-gray-50">
              <div>
                <label className="block text-[10px] text-gray-400 mb-1">المصطلح العلمي (باللغتين العربية والانجليزية)</label>
                <input 
                  type="text"
                  placeholder="مثال: قانون كيرشوف الأول (Kirchhoff's First Law)"
                  value={glossaryForm.term}
                  onChange={(e) => setGlossaryForm({ ...glossaryForm, term: e.target.value })}
                  className="w-full bg-white border border-gray-200 rounded-lg px-3 py-1.5 text-right text-xs"
                />
              </div>
              <div>
                <label className="block text-[10px] text-gray-400 mb-1">التعريف الدقيق والمبسط</label>
                <textarea 
                  placeholder="مجموع شدة التيارات الكهربية المارّة..."
                  value={glossaryForm.definition}
                  onChange={(e) => setGlossaryForm({ ...glossaryForm, definition: e.target.value })}
                  rows={2}
                  className="w-full bg-white border border-gray-200 rounded-lg p-2 text-right text-xs"
                />
              </div>
              <div>
                <label className="block text-[10px] text-gray-400 mb-1">تابع لأي مادة</label>
                <select
                  value={glossaryForm.subjectId}
                  onChange={(e) => setGlossaryForm({ ...glossaryForm, subjectId: e.target.value })}
                  className="w-full bg-white border border-gray-200 rounded-lg p-1.5 text-right text-xs font-sans"
                >
                  <option value="">-- اختر مادة --</option>
                  {teacherSubjects.map(s => (
                    <option key={s.id} value={s.id}>{s.name}</option>
                  ))}
                </select>
              </div>
              <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-sans text-xs font-semibold py-1.5 rounded-lg cursor-pointer">
                إضافة للمصطلحات العلميّة
              </button>
            </form>

            <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
              {glossary.map((g) => {
                const sub = subjects.find(s => s.id === g.subjectId);
                return (
                  <div key={g.id} className="p-3 border border-gray-50 rounded-xl hover:bg-gray-50/50">
                    <span className="text-[9px] font-bold bg-indigo-50 text-indigo-600 px-1.5 py-0.2 rounded-full">{sub?.code || "عام"}</span>
                    <h4 className="font-bold text-xs text-gray-900 mt-1">{g.term}</h4>
                    <p className="text-[10px] text-gray-500 mt-1 leading-relaxed">{g.definition}</p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Reference library & files Section */}
          <div className="bg-white border border-gray-100 p-5 rounded-2xl shadow-sm text-right space-y-4">
            <div>
              <h3 className="font-sans text-xs font-bold text-gray-900">مكتبة المصادر والمراجع الإضافية</h3>
              <p className="font-sans text-[11px] text-gray-400 mt-1">رفع كتب إلكترونية، روابط لمحاكاة علمية وتفاعلية، أو روابط لمقاطع شرح تكميلية</p>
            </div>

            <form onSubmit={handleAddResourceSubmit} className="space-y-3 bg-gray-50/50 p-4 rounded-xl border border-gray-50">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] text-gray-400 mb-1">اسم المرجع / الكتاب</label>
                  <input 
                    type="text"
                    placeholder="مثال: مسائل وحلول بنك الأسئلة"
                    value={resourceForm.title}
                    onChange={(e) => setResourceForm({ ...resourceForm, title: e.target.value })}
                    className="w-full bg-white border border-gray-200 rounded-lg px-3 py-1.5 text-right text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[10px] text-gray-400 mb-1">نوع المورد</label>
                  <select
                    value={resourceForm.type}
                    onChange={(e) => setResourceForm({ ...resourceForm, type: e.target.value as any })}
                    className="w-full bg-white border border-gray-200 rounded-lg p-1.5 text-right text-xs font-sans"
                  >
                    <option value="BOOK">كتيب / ملزمة PDF</option>
                    <option value="EXTERNAL_LINK">محاكاة تفاعلية أو موقع ويب</option>
                    <option value="VIDEO">محاضرة مسجلة (فيديو)</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-[10px] text-gray-400 mb-1">الرابط الإلكتروني للملف أو الموقع</label>
                <input 
                  type="text"
                  placeholder="https://..."
                  value={resourceForm.url}
                  onChange={(e) => setResourceForm({ ...resourceForm, url: e.target.value })}
                  className="w-full bg-white border border-gray-200 rounded-lg px-3 py-1.5 text-right text-xs font-mono"
                />
              </div>
              <div>
                <label className="block text-[10px] text-gray-400 mb-1">وصف المرجع وفائدته للطلاب</label>
                <textarea 
                  placeholder="اكتب توجيهات حول هذا المرجع وكيف يدرسه الطالب..."
                  value={resourceForm.description}
                  onChange={(e) => setResourceForm({ ...resourceForm, description: e.target.value })}
                  rows={2}
                  className="w-full bg-white border border-gray-200 rounded-lg p-2 text-right text-xs"
                />
              </div>
              <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-sans text-xs font-semibold py-1.5 rounded-lg cursor-pointer">
                تأكيد رفع المصدر
              </button>
            </form>

            <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
              {resources.map((r) => (
                <div key={r.id} className="p-3 border border-gray-50 rounded-xl hover:bg-gray-50/50 flex items-start gap-3 justify-between">
                  <div className="text-right">
                    <span className="text-[9px] font-bold bg-amber-50 text-amber-700 px-1.5 py-0.2 rounded">
                      {r.type === "BOOK" ? "كتيب PDF" : r.type === "VIDEO" ? "فيديو" : "رابط خارجي"}
                    </span>
                    <h4 className="font-bold text-xs text-gray-900 mt-1">{r.title}</h4>
                    <p className="text-[10px] text-gray-400 mt-1">{r.description}</p>
                  </div>
                  <a href={r.url} target="_blank" rel="noopener noreferrer" className="text-indigo-600 hover:text-indigo-800">
                    <ExternalLink className="h-4 w-4" />
                  </a>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

      {/* FORUM DISCUSSION TAB */}
      {activeTab === "forum" && (
        <div className="bg-white border border-gray-100 rounded-2xl shadow-sm p-6 max-w-4xl mx-auto text-right">
          <div className="mb-6">
            <h3 className="font-sans text-xs font-bold text-gray-900">منتدى الأسئلة والتفاعلات لطلابك</h3>
            <p className="font-sans text-[11px] text-gray-400 mt-1">الرد على استفسارات وأسئلة الطلاب المتعلقة بالمواد التي تدرسها لتوجيههم دراسياً</p>
          </div>

          <div className="space-y-4">
            {posts.filter(p => teacherSubjectIds.includes(p.subjectId)).length === 0 ? (
              <p className="text-center font-sans text-xs text-gray-400 p-8">لا توجد أسئلة أو نقاشات لطلابك حالياً في منتدى هذا الأسبوع</p>
            ) : (
              posts.filter(p => teacherSubjectIds.includes(p.subjectId)).map((post) => {
                const sub = subjects.find(s => s.id === post.subjectId);
                return (
                  <div key={post.id} className="border border-gray-150 rounded-2xl p-5 space-y-4 bg-gray-50/20">
                    <div className="flex items-center justify-between border-b border-gray-50 pb-3">
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-gray-400 font-mono">{new Date(post.createdAt).toLocaleDateString("ar-EG")}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-[9px] bg-indigo-50 text-indigo-600 font-bold px-2 py-0.5 rounded-full">{sub?.name}</span>
                        <h4 className="font-bold text-xs text-gray-900 mt-1">{post.title}</h4>
                        <p className="text-[10px] text-gray-400">طرح بواسطة الطالب: {post.authorName}</p>
                      </div>
                    </div>

                    <p className="text-xs text-gray-700 leading-relaxed font-sans">{post.content}</p>

                    {/* Replies list */}
                    <div className="space-y-3 mr-4 border-r-2 border-indigo-100 pr-4 mt-3">
                      {post.replies.map((rep) => (
                        <div key={rep.id} className="bg-white border border-gray-100 p-3 rounded-xl">
                          <div className="flex items-center justify-between mb-1.5">
                            <span className="text-[10px] text-gray-400 font-mono">{new Date(rep.createdAt).toLocaleDateString("ar-EG")}</span>
                            <span className="font-semibold text-xs text-indigo-950">{rep.authorName} ({rep.authorRole === UserRole.TEACHER ? "معلم" : "طالب"})</span>
                          </div>
                          <p className="text-[11px] text-gray-600 leading-relaxed">{rep.content}</p>
                        </div>
                      ))}
                    </div>

                    {/* Add reply form */}
                    <div className="flex gap-2 items-center pt-3 border-t border-gray-50">
                      <input 
                        type="text"
                        placeholder="اكتب ردك أو الإيضاح العلمي هنا للجميع..."
                        value={replyText[post.id] || ""}
                        onChange={(e) => setReplyText({ ...replyText, [post.id]: e.target.value })}
                        onKeyDown={(e) => e.key === "Enter" && handleReplySubmit(post.id)}
                        className="flex-1 bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-indigo-500 text-right"
                      />
                      <button 
                        onClick={() => handleReplySubmit(post.id)}
                        className="bg-indigo-600 hover:bg-indigo-700 text-white font-sans text-xs font-bold px-4 py-2 rounded-xl transition-colors cursor-pointer"
                      >
                        نشر الرد
                      </button>
                    </div>

                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* ATTENDANCE WORKSPACE TAB */}
      {activeTab === "attendance" && (
        <div className="space-y-6">
          <div className="bg-white border border-gray-100 rounded-2xl shadow-sm p-6 text-right">
            
            {(() => {
              const getTodayDateString = () => {
                const d = new Date();
                const year = d.getFullYear();
                const month = String(d.getMonth() + 1).padStart(2, "0");
                const dDay = String(d.getDate()).padStart(2, "0");
                return `${year}-${month}-${dDay}`;
              };
              const [selectedDate, setSelectedDate] = useState(getTodayDateString());

              // Calculate statistics for selected date
              const dateRecords = attendance.filter(r => r.date === selectedDate);
              const totalStudents = students.length;
              const presentCount = dateRecords.filter(r => r.status === "PRESENT").length;
              const lateCount = dateRecords.filter(r => r.status === "LATE").length;
              const absentCount = dateRecords.filter(r => r.status === "ABSENT").length;

              // Helper states for custom manual registration form
              const [selectedStudentId, setSelectedStudentId] = useState<string | null>(null);
              const [manualStatus, setManualStatus] = useState<"PRESENT" | "ABSENT" | "LATE">("PRESENT");
              const [manualIn, setManualIn] = useState("08:30 AM");
              const [manualOut, setManualOut] = useState("02:30 PM");

              return (
                <div className="space-y-6">
                  
                  {/* Header Row */}
                  <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-gray-100 pb-5 mb-4">
                    <div>
                      <h3 className="font-sans text-sm font-bold text-gray-900 flex items-center justify-end gap-1.5">
                        رصد الحضور والغياب اليومي للطلاب
                        <span className="h-2.5 w-2.5 rounded-full bg-indigo-600 animate-pulse inline-block"></span>
                      </h3>
                      <p className="font-sans text-[11px] text-gray-400 mt-1">تتبع حضور وانصراف الطلاب، وتحديث الحالات يدوياً، وإرسال تنبيهات فورية لأولياء الأمور عبر نظام الإشعارات المتكامل.</p>
                    </div>

                    <div className="w-full md:w-auto">
                      <div className="flex items-center justify-end gap-2">
                        <span className="font-sans text-[11px] text-gray-500 font-bold whitespace-nowrap">تاريخ كشف الحضور:</span>
                        <input 
                          type="date" 
                          value={selectedDate}
                          onChange={(e) => {
                            setSelectedDate(e.target.value);
                            setSelectedStudentId(null);
                          }}
                          className="bg-gray-50/50 border border-gray-150 rounded-xl px-3 py-1.5 text-xs text-gray-700 font-mono focus:outline-none focus:border-indigo-500"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Stats Cards Row */}
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="bg-indigo-50/30 border border-indigo-100 p-4 rounded-xl text-center">
                      <span className="text-[10px] text-indigo-600 block mb-0.5 font-bold">إجمالي طلاب الفصل</span>
                      <span className="font-mono text-base sm:text-lg font-bold text-indigo-950">{totalStudents} طلاب</span>
                    </div>
                    <div className="bg-emerald-50/30 border border-emerald-100 p-4 rounded-xl text-center">
                      <span className="text-[10px] text-emerald-600 block mb-0.5 font-bold">الحاضرون اليوم</span>
                      <span className="font-mono text-base sm:text-lg font-bold text-emerald-950">{presentCount} حاضرين</span>
                    </div>
                    <div className="bg-amber-50/30 border border-amber-100 p-4 rounded-xl text-center">
                      <span className="text-[10px] text-amber-600 block mb-0.5 font-bold">المتأخرون</span>
                      <span className="font-mono text-base sm:text-lg font-bold text-emerald-950">{lateCount} متأخرين</span>
                    </div>
                    <div className="bg-red-50/30 border border-red-100 p-4 rounded-xl text-center">
                      <span className="text-[10px] text-red-600 block mb-0.5 font-bold">الغائبون والمجازون</span>
                      <span className="font-mono text-base sm:text-lg font-bold text-indigo-950">{absentCount} غائبين</span>
                    </div>
                  </div>

                  {/* Manual entry form if open */}
                  {selectedStudentId && (() => {
                    const student = students.find(s => s.id === selectedStudentId);
                    if (!student) return null;
                    return (
                      <div className="bg-gray-50 border border-gray-200/60 rounded-xl p-5 mb-4 animate-fade-in text-right">
                        <div className="flex items-center justify-between mb-4 border-b border-gray-150 pb-2">
                          <button 
                            onClick={() => setSelectedStudentId(null)}
                            className="text-gray-400 hover:text-gray-600 text-xs font-bold font-sans cursor-pointer"
                          >
                            إغلاق النافذة ✕
                          </button>
                          <h4 className="font-sans text-xs font-bold text-indigo-950">
                            تعديل سجل حضور الطالب: <span className="text-emerald-700">{student.name}</span>
                          </h4>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div>
                            <label className="block text-[10px] font-bold text-gray-500 mb-1">حالة الحضور</label>
                            <select 
                              value={manualStatus} 
                              onChange={(e) => setManualStatus(e.target.value as any)}
                              className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-indigo-500"
                            >
                              <option value="PRESENT">حاضر</option>
                              <option value="LATE">متأخر</option>
                              <option value="ABSENT">غائب</option>
                            </select>
                          </div>
                          
                          {manualStatus !== "ABSENT" && (
                            <>
                              <div>
                                <label className="block text-[10px] font-bold text-gray-500 mb-1">وقت الحضور</label>
                                <input 
                                  type="text" 
                                  placeholder="مثال: 08:30 AM" 
                                  value={manualIn}
                                  onChange={(e) => setManualIn(e.target.value)}
                                  className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs text-center font-mono focus:outline-none focus:border-indigo-500"
                                />
                              </div>
                              <div>
                                <label className="block text-[10px] font-bold text-gray-500 mb-1">وقت الانصراف</label>
                                <input 
                                  type="text" 
                                  placeholder="مثال: 02:15 PM" 
                                  value={manualOut}
                                  onChange={(e) => setManualOut(e.target.value)}
                                  className="w-full bg-white border border-gray-200 rounded-xl px-3 py-2 text-xs text-center font-mono focus:outline-none focus:border-indigo-500"
                                />
                              </div>
                            </>
                          )}
                        </div>

                        <div className="flex gap-2 justify-end mt-4 pt-4 border-t border-gray-200/60">
                          <button
                            onClick={() => setSelectedStudentId(null)}
                            className="bg-white border border-gray-200 hover:bg-gray-100 text-gray-700 font-sans text-xs font-bold px-4 py-2 rounded-xl transition cursor-pointer"
                          >
                            إلغاء
                          </button>
                          <button
                            onClick={() => {
                              onUpdateAttendance(
                                selectedStudentId,
                                student.name,
                                selectedDate,
                                manualStatus,
                                manualStatus === "ABSENT" ? undefined : manualIn,
                                manualStatus === "ABSENT" ? undefined : manualOut,
                                false
                              );
                              setSelectedStudentId(null);
                              triggerNotif(`تم تحديث سجل حضور الطالب ${student.name} بنجاح!`);
                            }}
                            className="bg-indigo-600 hover:bg-indigo-700 text-white font-sans text-xs font-bold px-4 py-2 rounded-xl transition cursor-pointer"
                          >
                            حفظ التعديلات
                          </button>
                        </div>
                      </div>
                    );
                  })()}

                  {/* Students Attendance Table */}
                  <div className="bg-white border border-gray-150 rounded-2xl overflow-hidden shadow-sm">
                    <div className="overflow-x-auto">
                      <table className="w-full text-right font-sans">
                        <thead>
                          <tr className="bg-gray-50 border-b border-gray-100 text-[10px] text-gray-500 font-bold">
                            <th className="p-4">الطالب</th>
                            <th className="p-4 text-center">حالة الحضور</th>
                            <th className="p-4 text-center">وقت الحضور</th>
                            <th className="p-4 text-center">وقت الانصراف</th>
                            <th className="p-4 text-left">الإجراءات والتحكم</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100 text-xs">
                          {students.map((student) => {
                            const record = attendance.find(r => r.studentId === student.id && r.date === selectedDate);
                            return (
                              <tr key={student.id} className="hover:bg-gray-50/50 transition">
                                <td className="p-4">
                                  <div className="flex items-center gap-3 justify-end">
                                    <div className="text-right">
                                      <span className="font-bold text-gray-900 block">{student.name}</span>
                                      <span className="text-[9px] text-gray-400 font-mono block">{student.email}</span>
                                    </div>
                                    <img 
                                      src={student.avatar || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=100"} 
                                      alt={student.name}
                                      className="h-8 w-8 rounded-full border border-gray-100 object-cover"
                                    />
                                  </div>
                                </td>
                                <td className="p-4 text-center">
                                  {record ? (
                                    record.status === "PRESENT" ? (
                                      <span className="inline-block bg-emerald-50 text-emerald-700 border border-emerald-100 px-2.5 py-1 rounded-full text-[10px] font-bold font-sans">
                                        ✓ حاضر
                                      </span>
                                    ) : record.status === "LATE" ? (
                                      <span className="inline-block bg-amber-50 text-amber-700 border border-amber-100 px-2.5 py-1 rounded-full text-[10px] font-bold font-sans">
                                        ⏱ متأخر
                                      </span>
                                    ) : (
                                      <span className="inline-block bg-red-50 text-red-700 border border-red-100 px-2.5 py-1 rounded-full text-[10px] font-bold font-sans">
                                        🚨 غائب
                                      </span>
                                    )
                                  ) : (
                                    <span className="inline-block bg-gray-50 text-gray-400 border border-gray-200 px-2.5 py-1 rounded-full text-[10px] font-bold font-sans">
                                      غير مسجل
                                    </span>
                                  )}
                                </td>
                                <td className="p-4 text-center font-mono text-[11px] text-gray-600">
                                  {record && record.checkInTime ? record.checkInTime : "—"}
                                </td>
                                <td className="p-4 text-center font-mono text-[11px] text-gray-600">
                                  {record && record.checkOutTime ? record.checkOutTime : "—"}
                                </td>
                                <td className="p-4">
                                  <div className="flex flex-wrap items-center justify-start gap-1.5">
                                    <button
                                      onClick={() => {
                                        setSelectedStudentId(student.id);
                                        setManualStatus(record?.status || "PRESENT");
                                        setManualIn(record?.checkInTime || "08:30 AM");
                                        setManualOut(record?.checkOutTime || "02:15 PM");
                                      }}
                                      className="bg-indigo-50 text-indigo-700 hover:bg-indigo-100 border border-indigo-100 px-2.5 py-1 rounded-lg text-[10px] font-bold font-sans cursor-pointer transition"
                                    >
                                      تعديل وتخصيص
                                    </button>

                                    {/* Set absent shortcut */}
                                    {(!record || record.status !== "ABSENT") && (
                                      <button
                                        onClick={() => {
                                          onUpdateAttendance(student.id, student.name, selectedDate, "ABSENT", undefined, undefined, false);
                                          triggerNotif(`تم تسجيل غياب الطالب ${student.name}`);
                                        }}
                                        className="bg-red-50 text-red-700 hover:bg-red-100 border border-red-100 px-2 py-1 rounded-lg text-[10px] font-bold font-sans cursor-pointer transition"
                                      >
                                        تسجيل غياب
                                      </button>
                                    )}

                                    {/* Set present shortcut */}
                                    {(!record || record.status !== "PRESENT") && (
                                      <button
                                        onClick={() => {
                                          const nowStr = new Date().toLocaleTimeString("en-US", { hour: '2-digit', minute: '2-digit' });
                                          onUpdateAttendance(student.id, student.name, selectedDate, "PRESENT", nowStr, undefined, false);
                                          triggerNotif(`تم تسجيل حضور الطالب ${student.name}`);
                                        }}
                                        className="bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-100 px-2 py-1 rounded-lg text-[10px] font-bold font-sans cursor-pointer transition"
                                      >
                                        تسجيل حضور
                                      </button>
                                    )}

                                    {/* Notify Parent Button */}
                                    {record && record.status === "ABSENT" && (
                                      record.notifiedParent ? (
                                        <span className="bg-emerald-50 text-emerald-700 border border-emerald-150 px-2.5 py-1 rounded-lg text-[9px] font-bold font-sans">
                                          ✓ تم تنبيه ولي الأمر
                                        </span>
                                      ) : (
                                        <button
                                          onClick={() => {
                                            onUpdateAttendance(
                                              student.id,
                                              student.name,
                                              selectedDate,
                                              "ABSENT",
                                              undefined,
                                              undefined,
                                              true
                                            );
                                            triggerNotif(`تم تنبيه ولي الأمر بغياب الطالب ${student.name}`);
                                          }}
                                          className="bg-amber-600 hover:bg-amber-700 text-white px-2.5 py-1 rounded-lg text-[10px] font-bold font-sans cursor-pointer flex items-center gap-1 shadow-sm transition"
                                        >
                                          <AlertCircle className="h-3 w-3" />
                                          تنبيه ولي الأمر
                                        </button>
                                      )
                                    )}
                                  </div>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>

                </div>
              );
            })()}

          </div>
        </div>
      )}

    </div>
  );
};
