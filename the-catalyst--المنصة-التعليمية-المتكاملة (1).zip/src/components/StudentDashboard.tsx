import React, { useState } from "react";
import { 
  BookOpen, 
  Play, 
  FileText, 
  CheckCircle, 
  ClipboardList, 
  Award, 
  HelpCircle, 
  MessageSquare, 
  BookMarked, 
  Activity, 
  Calendar,
  ChevronLeft,
  ChevronDown,
  Sparkles,
  Volume2,
  Clock,
  ExternalLink,
  ChevronRight,
  TrendingUp,
  AlertCircle,
  Maximize2,
  Minimize2,
  Type,
  Mic,
  MicOff
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend 
} from "recharts";
import { 
  User, 
  UserRole,
  Subject, 
  Course,
  Unit, 
  Lesson, 
  Assignment, 
  AssignmentSubmission, 
  Quiz, 
  QuizAttempt, 
  ForumPost, 
  EducationalResource, 
  GlossaryTerm,
  AttendanceRecord
} from "../types";

interface VoiceInputButtonProps {
  onTranscript: (text: string) => void;
  size?: "sm" | "md";
  className?: string;
}

const VoiceInputButton: React.FC<VoiceInputButtonProps> = ({ onTranscript, size = "md", className = "" }) => {
  const [isListening, setIsListening] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const startListening = () => {
    setError(null);
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setError("متصفحك لا يدعم التعرف على الصوت. يرجى استخدام متصفح Google Chrome.");
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = "ar-SA";

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognition.onerror = (event: any) => {
        console.error("Speech recognition error:", event);
        if (event.error === "not-allowed") {
          setError("يرجى تفعيل صلاحية استخدام الميكروفون في المتصفح.");
        } else {
          setError("حدث خطأ في التعرف على الصوت.");
        }
        setIsListening(false);
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        if (transcript) {
          onTranscript(transcript);
        }
      };

      recognition.start();
    } catch (e) {
      console.error(e);
      setIsListening(false);
    }
  };

  const toggleListening = () => {
    if (isListening) {
      setIsListening(false);
    } else {
      startListening();
    }
  };

  return (
    <div className={`relative inline-flex items-center ${className}`}>
      <button
        type="button"
        onClick={toggleListening}
        className={`relative rounded-full flex items-center justify-center transition-all cursor-pointer ${
          isListening 
            ? "bg-red-500 hover:bg-red-600 text-white shadow-lg shadow-red-500/25 ring-4 ring-red-500/20" 
            : "bg-emerald-50 hover:bg-emerald-100 text-emerald-600 border border-emerald-100"
        } ${size === "sm" ? "h-7 w-7" : "h-9 w-9"}`}
        title={isListening ? "جاري الاستماع... اضغط لإلغاء التفعيل" : "إدخال بالصوت (تحويل الصوت إلى كتابة)"}
      >
        {isListening ? (
          <>
            <Mic className="h-4 w-4 animate-pulse" />
            <span className="absolute -top-1 -right-1 flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
            </span>
          </>
        ) : (
          <Mic className="h-4 w-4" />
        )}
      </button>

      {/* Floating tooltip/message for errors or active listening */}
      <AnimatePresence>
        {isListening && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 bg-slate-900 text-white text-[10px] px-2.5 py-1.5 rounded-lg whitespace-nowrap shadow-xl z-30 font-sans flex items-center gap-1.5 border border-slate-800"
          >
            <span className="flex h-1.5 w-1.5 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-red-500"></span>
            </span>
            تحدث الآن...
          </motion.div>
        )}
        {error && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            className="absolute bottom-full mb-2 left-1/2 -translate-x-1/2 bg-amber-50 border border-amber-200 text-amber-800 text-[10px] font-sans px-2.5 py-1.5 rounded-lg whitespace-nowrap shadow-xl z-30 flex items-center gap-1.5"
          >
            <span>{error}</span>
            <button 
              onClick={() => setError(null)} 
              className="text-[9px] font-bold text-amber-500 hover:text-amber-700 bg-amber-100 hover:bg-amber-200/60 rounded px-1"
            >
              إغلاق
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

interface StudentDashboardProps {
  currentUser: User;
  subjects: Subject[];
  units: Unit[];
  lessons: Lesson[];
  assignments: Assignment[];
  submissions: AssignmentSubmission[];
  quizzes: Quiz[];
  attempts: QuizAttempt[];
  posts: ForumPost[];
  resources: EducationalResource[];
  glossary: GlossaryTerm[];
  courses: Course[];
  attendance: AttendanceRecord[];
  onCheckIn: (studentId: string, name: string) => void;
  onCheckOut: (studentId: string, name: string) => void;
  onAddForumPost: (title: string, content: string, subjectId: string) => void;
  onAddForumReply: (postId: string, replyContent: string) => void;
  onSubmitAssignment: (assignmentId: string, answers: { questionId: string; answerText: string }[]) => void;
  onSubmitQuizAttempt: (quizId: string, score: number, answers: number[]) => void;
  completedLessonIds: string[];
  onToggleLessonCompleted: (lessonId: string) => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({
  currentUser,
  subjects,
  units,
  lessons,
  assignments,
  submissions,
  quizzes,
  attempts,
  posts,
  resources,
  glossary,
  courses,
  attendance,
  onCheckIn,
  onCheckOut,
  onAddForumPost,
  onAddForumReply,
  onSubmitAssignment,
  onSubmitQuizAttempt,
  completedLessonIds,
  onToggleLessonCompleted
}) => {
  const [activeTab, setActiveTab] = useState<"progress" | "curriculum" | "assignments" | "quizzes" | "forum" | "library">("progress");
  
  // Navigation sub-states
  const [selectedSubjectId, setSelectedSubjectId] = useState<string | null>(null);
  const [selectedLessonId, setSelectedLessonId] = useState<string | null>(null);

  // Reading Mode custom states
  const [isReadingMode, setIsReadingMode] = useState(false);
  const [readingTheme, setReadingTheme] = useState<"light" | "sepia" | "dark">("light");
  const [readingFontSize, setReadingFontSize] = useState<"sm" | "base" | "lg" | "xl">("base");
  
  // Interactive homework solving state
  const [solvingAssignmentId, setSolvingAssignmentId] = useState<string | null>(null);
  const [assignmentAnswers, setAssignmentAnswers] = useState<{ [qId: string]: string }>({});

  // Interactive Quiz solving state
  const [solvingQuizId, setSolvingQuizId] = useState<string | null>(null);
  const [quizAnswers, setQuizAnswers] = useState<{ [qId: string]: number }>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [quizScore, setQuizScore] = useState(0);

  // Forum creation state
  const [newPostSubjId, setNewPostSubjId] = useState("");
  const [newPostTitle, setNewPostTitle] = useState("");
  const [newPostContent, setNewPostContent] = useState("");
  const [replyText, setReplyText] = useState<{ [postId: string]: string }>({});

  const [toastNotif, setToastNotif] = useState<string | null>(null);

  // Listen to dark mode changes for SVG Chart colors
  const [isDark, setIsDark] = React.useState(() => document.documentElement.classList.contains("dark"));
  React.useEffect(() => {
    const observer = new MutationObserver(() => {
      setIsDark(document.documentElement.classList.contains("dark"));
    });
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ["class"] });
    return () => observer.disconnect();
  }, []);

  const triggerToast = (text: string) => {
    setToastNotif(text);
    setTimeout(() => setToastNotif(null), 3500);
  };

  // Calculations
  const studentAttempts = attempts.filter(a => a.studentId === currentUser.id);
  const studentSubmissions = submissions.filter(s => s.studentId === currentUser.id && s.status === "GRADED");

  const averageQuizScore = studentAttempts.length > 0 
    ? Math.round(studentAttempts.reduce((acc, curr) => acc + curr.score, 0) / studentAttempts.length) 
    : 0;

  // Generate dynamic performance dataset
  const basePerformanceData = [
    { name: "الأسبوع ١", "درجة الاختبارات": 82, "درجة الواجبات": 85 },
    { name: "الأسبوع ٢", "درجة الاختبارات": 88, "درجة الواجبات": 90 },
    { name: "الأسبوع ٣", "درجة الاختبارات": 85, "درجة الواجبات": 92 },
    { name: "الأسبوع ٤", "درجة الاختبارات": 90, "درجة الواجبات": 88 },
  ];

  // Map real-time graded submissions and quiz attempts
  const additionalPoints: any[] = [];
  
  studentAttempts.forEach((att, idx) => {
    const quizObj = quizzes.find(q => q.id === att.quizId);
    const label = quizObj ? quizObj.title.replace("الاختبار القصير الأول: ", "").replace("الاختبار القصير الثاني: ", "") : `اختبار ${idx + 1}`;
    
    // Find matching assignment grade near the same timeframe, or fall back to 95%
    const matchingSub = studentSubmissions[idx] || studentSubmissions[0];
    const subGrade = matchingSub ? (matchingSub.grade ?? 95) : 95;
    
    additionalPoints.push({
      name: label.length > 15 ? label.substring(0, 15) + "..." : label,
      "درجة الاختبارات": att.score,
      "درجة الواجبات": subGrade
    });
  });

  // If there are any graded submissions that weren't paired, append them too
  if (studentSubmissions.length > studentAttempts.length) {
    for (let i = studentAttempts.length; i < studentSubmissions.length; i++) {
      const sub = studentSubmissions[i];
      const assignObj = assignments.find(a => a.id === sub.assignmentId);
      const label = assignObj ? assignObj.title.replace("واجب الدرس الأول: ", "واجب ").replace("واجب الدرس الثاني: ", "واجب ") : `واجب ${i + 1}`;
      additionalPoints.push({
        name: label.length > 15 ? label.substring(0, 15) + "..." : label,
        "درجة الاختبارات": averageQuizScore || 90,
        "درجة الواجبات": sub.grade ?? 90
      });
    }
  }

  const unifiedPerformanceData = [...basePerformanceData, ...additionalPoints];

  const getSubjectProgress = (subjectId: string) => {
    const subLessons = lessons.filter(l => l.subjectId === subjectId);
    if (subLessons.length === 0) return 0;
    const completed = subLessons.filter(l => completedLessonIds.includes(l.id));
    return Math.round((completed.length / subLessons.length) * 100);
  };

  const overallProgress = lessons.length > 0 
    ? Math.round((completedLessonIds.length / lessons.length) * 100) 
    : 0;

  // Handlers
  const handleAnswerAssignment = (qId: string, text: string) => {
    setAssignmentAnswers(prev => ({ ...prev, [qId]: text }));
  };

  const handleSendAssignment = (assignId: string) => {
    const questions = assignments.find(a => a.id === assignId)?.questions || [];
    const formattedAnswers = questions.map(q => ({
      questionId: q.id,
      answerText: assignmentAnswers[q.id] || ""
    }));

    onSubmitAssignment(assignId, formattedAnswers);
    setSolvingAssignmentId(null);
    setAssignmentAnswers({});
    triggerToast("تم تسليم الواجب الدراسي وإدراجه للتقييم بنجاح!");
  };

  const handleStartQuiz = (qId: string) => {
    setSolvingQuizId(qId);
    setQuizAnswers({});
    setQuizSubmitted(false);
    setQuizScore(0);
  };

  const handleSelectQuizOption = (qId: string, optIdx: number) => {
    setQuizAnswers(prev => ({ ...prev, [qId]: optIdx }));
  };

  const handleSendQuiz = (quiz: Quiz) => {
    let correctCount = 0;
    quiz.questions.forEach((q) => {
      if (quizAnswers[q.id] === q.correctAnswerIndex) {
        correctCount++;
      }
    });

    const scorePct = Math.round((correctCount / quiz.questions.length) * 100);
    const selectedIndices = quiz.questions.map(q => quizAnswers[q.id] ?? -1);

    onSubmitQuizAttempt(quiz.id, scorePct, selectedIndices);
    setQuizScore(scorePct);
    setQuizSubmitted(true);
    triggerToast(`اكتمل الاختبار! النتيجة المحققة: ${scorePct}%`);
  };

  const handleCreateForumPost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostSubjId || !newPostTitle || !newPostContent) {
      alert("يرجى ملء كافة تفاصيل السؤال");
      return;
    }
    onAddForumPost(newPostTitle, newPostContent, newPostSubjId);
    setNewPostTitle("");
    setNewPostContent("");
    setNewPostSubjId("");
    triggerToast("تم طرح سؤالك في منتدى المادة بنجاح!");
  };

  const handleSendReply = (postId: string) => {
    const text = replyText[postId];
    if (!text || !text.trim()) return;
    onAddForumReply(postId, text.trim());
    setReplyText(prev => ({ ...prev, [postId]: "" }));
    triggerToast("تم نشر ردك ومشاركتك في النقاش");
  };

  return (
    <div className="py-6 font-sans text-right" dir="rtl" id="student-dashboard-container">
      
      {/* Toast Notifier */}
      {toastNotif && (
        <div className="fixed bottom-6 left-6 z-50 rounded-xl bg-emerald-600 px-4 py-3 text-white flex items-center gap-2 shadow-lg">
          <CheckCircle className="h-4 w-4" />
          <span className="text-xs font-semibold">{toastNotif}</span>
        </div>
      )}

      {/* Main Student Header / Card */}
      {!isReadingMode && (
        <div className="bg-gradient-to-l from-emerald-900 to-teal-800 rounded-3xl p-6 sm:p-8 text-white shadow-xl mb-6 border border-emerald-950">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="text-right">
              <span className="bg-emerald-500/25 text-emerald-300 border border-emerald-500/25 px-3 py-1 rounded-full text-[10px] font-bold">طالب متميز</span>
              <h2 className="font-sans text-xl sm:text-2xl font-bold mt-2">أهلاً بك مجدداً يا {currentUser.name} ✨</h2>
              <p className="font-sans text-xs text-emerald-100 mt-1.5 leading-relaxed max-w-xl">
                ثابر واجتهد في دروسك، رحلتك مستمرة لتحقيق التفوق الدراسي. لديك واجبات متبقية ينتهي موعد تسليمها قريباً!
              </p>
            </div>
            
            <div className="flex gap-4 items-center">
              <div className="bg-white/5 border border-white/5 rounded-2xl px-5 py-4 text-center">
                <span className="text-[10px] text-emerald-300 block mb-0.5">دروس أكملتها</span>
                <span className="font-mono text-2xl font-bold text-white">{completedLessonIds.length} <span className="text-xs font-sans text-emerald-300">/ {lessons.length}</span></span>
              </div>
              <div className="bg-white/5 border border-white/5 rounded-2xl px-5 py-4 text-center">
                <span className="text-[10px] text-emerald-300 block mb-0.5">معدل الاختبارات</span>
                <span className="font-mono text-2xl font-bold text-white">{averageQuizScore}%</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Enrolled Academic Programs / Courses */}
      {!isReadingMode && courses.length > 0 && (
        <div className="bg-white border border-gray-100 rounded-3xl p-6 mb-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <span className="font-sans text-[11px] text-gray-400 font-bold">بوابة البرامج الأكاديمية</span>
            <h3 className="font-sans text-xs font-bold text-gray-950 flex items-center gap-2 justify-end">
              <Award className="h-4 w-4 text-emerald-600" />
              البرامج والمناهج الأكاديمية المسجل بها
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-right">
            {courses.map((crs) => {
              // Get subjects that are in this course
              const crsSubjects = subjects.filter(s => crs.subjectIds.includes(s.id));
              
              return (
                <div key={crs.id} className="bg-gray-50/30 hover:bg-gray-50 border border-gray-50 hover:border-gray-100 p-5 rounded-2xl transition-all flex flex-col justify-between">
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <span className="font-mono text-[9px] bg-emerald-50 text-emerald-700 px-2.5 py-0.5 rounded-lg border border-emerald-100/50 font-bold">
                        {crs.code}
                      </span>
                      <h4 className="font-sans text-xs font-extrabold text-gray-900 line-clamp-1">{crs.name}</h4>
                    </div>
                    <p className="font-sans text-[11px] text-gray-500 line-clamp-2 mt-2 leading-relaxed mb-4">
                      {crs.description || "برنامج أكاديمي متكامل لتأهيل الطلاب وتمكينهم في المادة العلمية."}
                    </p>
                  </div>

                  <div className="space-y-2 pt-2 border-t border-gray-100/60">
                    <span className="block font-sans text-[9px] font-bold text-gray-400">مقررات البرنامج الدراسية:</span>
                    <div className="flex flex-wrap gap-1">
                      {crsSubjects.length === 0 ? (
                        <span className="font-sans text-[9px] text-gray-400 bg-white px-2 py-0.5 rounded border border-gray-100">قريباً</span>
                      ) : (
                        crsSubjects.map(s => (
                          <span key={s.id} className="font-sans text-[10px] bg-white text-gray-700 border border-gray-100/70 px-2 py-0.5 rounded-lg">
                            {s.name}
                          </span>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Primary Navigation Tabs */}
      {!isReadingMode && (
        <div className="flex flex-wrap items-center justify-start gap-2 border-b border-gray-100 pb-4 mb-6">
          <button
            onClick={() => setActiveTab("progress")}
            className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer transition-all ${activeTab === "progress" ? "bg-emerald-600 text-white" : "hover:bg-gray-50 text-gray-600 bg-white border border-gray-100"}`}
          >
            <Activity className="h-4 w-4" />
            البوابة العامة للتقدم
          </button>
          <button
            onClick={() => setActiveTab("curriculum")}
            className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer transition-all ${activeTab === "curriculum" ? "bg-emerald-600 text-white" : "hover:bg-gray-50 text-gray-600 bg-white border border-gray-100"}`}
          >
            <BookOpen className="h-4 w-4" />
            مستعرض المناهج والدروس
          </button>
          <button
            onClick={() => {
              setActiveTab("assignments");
              setSolvingAssignmentId(null);
            }}
            className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer transition-all ${activeTab === "assignments" ? "bg-emerald-600 text-white" : "hover:bg-gray-50 text-gray-600 bg-white border border-gray-100"}`}
          >
            <ClipboardList className="h-4 w-4" />
            الواجبات المدرسية
          </button>
          <button
            onClick={() => {
              setActiveTab("quizzes");
              setSolvingQuizId(null);
            }}
            className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer transition-all ${activeTab === "quizzes" ? "bg-emerald-600 text-white" : "hover:bg-gray-50 text-gray-600 bg-white border border-gray-100"}`}
          >
            <Award className="h-4 w-4" />
            الاختبارات القصيرة
          </button>
          <button
            onClick={() => setActiveTab("forum")}
            className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer transition-all ${activeTab === "forum" ? "bg-emerald-600 text-white" : "hover:bg-gray-50 text-gray-600 bg-white border border-gray-100"}`}
          >
            <MessageSquare className="h-4 w-4" />
            منتدى الأسئلة والنقاش
          </button>
          <button
            onClick={() => setActiveTab("library")}
            className={`flex items-center gap-2 rounded-xl px-4 py-2 text-xs font-semibold cursor-pointer transition-all ${activeTab === "library" ? "bg-emerald-600 text-white" : "hover:bg-gray-50 text-gray-600 bg-white border border-gray-100"}`}
          >
            <BookMarked className="h-4 w-4" />
            مكتبة المراجع والمصطلحات
          </button>
        </div>
      )}

      {/* PORTAL PROGRESS & GENERAL ANALYTICS TAB */}
      {activeTab === "progress" && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Visual Progress Graphs column */}
            <div className="lg:col-span-2 space-y-6">
              
              {/* Strengths & Weaknesses analysis / Quiz history Recharts charts */}
              <div className="bg-white border border-gray-100 p-6 rounded-2xl shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <div className="text-[10px] text-gray-400 font-mono flex items-center gap-1">
                    <TrendingUp className="h-3.5 w-3.5 text-emerald-500" />
                    معدل الأداء البياني التراكمي
                  </div>
                  <h3 className="font-sans text-xs font-bold text-gray-900">منحنى تطور درجاتك الأكاديمية (الاختبارات والواجبات)</h3>
                </div>

                {unifiedPerformanceData.length === 0 ? (
                  <p className="text-center text-gray-400 text-xs py-8">لم تقم بإجراء أي اختبارات لعرض النتائج بيانياً</p>
                ) : (
                  <div className="h-64 w-full mt-2 font-sans" dir="ltr">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart
                        data={unifiedPerformanceData}
                        margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
                      >
                        <defs>
                          <linearGradient id="colorQuizzes" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#10b981" stopOpacity={0.2}/>
                            <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                          </linearGradient>
                          <linearGradient id="colorAssignments" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.2}/>
                            <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid 
                          strokeDasharray="3 3" 
                          stroke={isDark ? "#1e293b" : "#f1f5f9"} 
                        />
                        <XAxis 
                          dataKey="name" 
                          tick={{ fill: isDark ? "#94a3b8" : "#64748b", fontSize: 10 }}
                          tickLine={{ stroke: isDark ? "#334155" : "#e2e8f0" }}
                          axisLine={{ stroke: isDark ? "#334155" : "#e2e8f0" }}
                        />
                        <YAxis 
                          domain={[0, 100]} 
                          tick={{ fill: isDark ? "#94a3b8" : "#64748b", fontSize: 10 }}
                          tickLine={{ stroke: isDark ? "#334155" : "#e2e8f0" }}
                          axisLine={{ stroke: isDark ? "#334155" : "#e2e8f0" }}
                        />
                        <Tooltip 
                          content={({ active, payload, label }: any) => {
                            if (active && payload && payload.length) {
                              return (
                                <div className="bg-white dark:bg-slate-900 border border-gray-200 dark:border-slate-800 p-3 rounded-xl shadow-xl font-sans text-right text-xs">
                                  <p className="font-bold text-gray-900 dark:text-white mb-1.5">{label}</p>
                                  {payload.map((item: any, idx: number) => (
                                    <div key={idx} className="flex items-center justify-between gap-4 mt-1">
                                      <span className="font-mono font-bold" style={{ color: item.color || item.fill }}>
                                        {item.value}%
                                      </span>
                                      <span className="text-gray-500 dark:text-slate-400">
                                        {item.name}:
                                      </span>
                                    </div>
                                  ))}
                                </div>
                              );
                            }
                            return null;
                          }}
                        />
                        <Legend 
                          verticalAlign="top" 
                          height={36}
                          iconType="circle"
                          iconSize={8}
                          wrapperStyle={{ fontSize: 11 }}
                          formatter={(value) => <span className="text-gray-600 dark:text-slate-300 font-sans font-medium px-1.5">{value}</span>}
                        />
                        <Area 
                          type="monotone" 
                          dataKey="درجة الاختبارات" 
                          stroke="#10b981" 
                          strokeWidth={2.5}
                          fillOpacity={1} 
                          fill="url(#colorQuizzes)" 
                          activeDot={{ r: 6 }}
                        />
                        <Area 
                          type="monotone" 
                          dataKey="درجة الواجبات" 
                          stroke="#3b82f6" 
                          strokeWidth={2.5}
                          fillOpacity={1} 
                          fill="url(#colorAssignments)" 
                          activeDot={{ r: 6 }}
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </div>

              {/* Subject-wise progress cards */}
              <div className="bg-white border border-gray-100 p-6 rounded-2xl shadow-sm">
                <h3 className="font-sans text-xs font-bold text-gray-900 mb-4">تقدمك الدراسي لكل مادة</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {subjects.map((sub) => {
                    const prog = getSubjectProgress(sub.id);
                    return (
                      <div key={sub.id} className="border border-gray-50 rounded-xl p-4 hover:bg-gray-50/50 transition-colors">
                        <div className="flex items-center justify-between mb-3">
                          <span className="font-mono text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">{prog}%</span>
                          <h4 className="font-sans text-xs font-bold text-gray-900">{sub.name}</h4>
                        </div>
                        <div className="h-2 w-full bg-gray-100 rounded-full overflow-hidden">
                          <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${prog}%` }} />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Smart Reminders & Incomplete Assignments Side panels */}
            <div className="space-y-6">
              
              {/* Daily Attendance & Check-in Widget */}
              <div className="bg-white border border-gray-100 p-6 rounded-2xl shadow-sm text-right">
                <h3 className="font-sans text-xs font-bold text-gray-950 mb-1 flex items-center justify-end gap-1.5">
                  رصد الحضور والانصراف اليومي
                  <Clock className="h-4 w-4 text-emerald-600" />
                </h3>
                <p className="font-sans text-[10px] text-gray-400 mb-4">سجل حضورك وانصرافك اليومي لإثبات تفاعلك مع المنصة</p>

                {(() => {
                  const getTodayDateString = () => {
                    const d = new Date();
                    const year = d.getFullYear();
                    const month = String(d.getMonth() + 1).padStart(2, "0");
                    const day = String(d.getDate()).padStart(2, "0");
                    return `${year}-${month}-${day}`;
                  };
                  const todayDate = getTodayDateString();
                  const todayRecord = attendance.find(r => r.studentId === currentUser.id && r.date === todayDate);

                  // Formatting Today's date nicely in Arabic
                  const formattedToday = new Date().toLocaleDateString("ar-EG", {
                    weekday: 'long',
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  });

                  return (
                    <div className="space-y-4">
                      <div className="bg-gray-50/50 dark:bg-slate-800/40 border border-gray-100 dark:border-slate-800/80 p-3.5 rounded-xl text-center">
                        <span className="text-[10px] text-gray-400 block mb-1">{formattedToday}</span>
                        
                        {todayRecord ? (
                          todayRecord.status === "ABSENT" ? (
                            <div>
                              <span className="inline-block bg-red-50 text-red-600 border border-red-100 px-3 py-1 rounded-full text-xs font-bold font-sans">
                                🚨 غائب
                              </span>
                              <p className="text-[10px] text-red-500 mt-2">لقد تم تسجيلك غائباً اليوم من قبل المعلم. نرجو إبلاغ ولي أمرك للتواصل مع الإدارة.</p>
                            </div>
                          ) : (
                            <div className="space-y-2">
                              <span className="inline-block bg-emerald-50 text-emerald-600 border border-emerald-100 px-3 py-1 rounded-full text-xs font-bold font-sans">
                                {todayRecord.status === "PRESENT" ? "✓ تم تسجيل حضورك اليوم" : "✓ حاضر متأخر"}
                              </span>
                              
                              <div className="grid grid-cols-2 gap-2 text-right mt-2 pt-2 border-t border-gray-100 dark:border-slate-800">
                                <div className="text-center">
                                  <span className="text-[9px] text-gray-400 block">وقت الانصراف</span>
                                  <span className="font-mono text-xs font-bold text-gray-700 dark:text-gray-300">
                                    {todayRecord.checkOutTime || "—:—"}
                                  </span>
                                </div>
                                <div className="text-center border-l border-gray-100 dark:border-slate-800">
                                  <span className="text-[9px] text-gray-400 block">وقت الحضور</span>
                                  <span className="font-mono text-xs font-bold text-gray-700 dark:text-gray-300">
                                    {todayRecord.checkInTime || "غير محدد"}
                                  </span>
                                </div>
                              </div>
                            </div>
                          )
                        ) : (
                          <div>
                            <span className="inline-block bg-amber-50 text-amber-600 border border-amber-100 px-3 py-1 rounded-full text-xs font-bold font-sans">
                              ⏳ لم يتم تسجيل حضورك اليوم
                            </span>
                          </div>
                        )}
                      </div>

                      {/* Control Buttons */}
                      <div className="space-y-2">
                        {!todayRecord && (
                          <button
                            onClick={() => {
                              onCheckIn(currentUser.id, currentUser.name);
                              triggerToast("تم تسجيل حضورك لليوم بنجاح! طاب يومك الدراسي.");
                            }}
                            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-sans text-xs font-bold py-2.5 px-4 rounded-xl shadow-md shadow-emerald-600/10 transition-all cursor-pointer flex items-center justify-center gap-1.5"
                          >
                            <CheckCircle className="h-4 w-4" />
                            تسجيل الحضور الآن
                          </button>
                        )}

                        {todayRecord && todayRecord.status !== "ABSENT" && !todayRecord.checkOutTime && (
                          <button
                            onClick={() => {
                              onCheckOut(currentUser.id, currentUser.name);
                              triggerToast("تم تسجيل انصرافك لليوم بنجاح! رافقتك السلامة.");
                            }}
                            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-sans text-xs font-bold py-2.5 px-4 rounded-xl shadow-md shadow-indigo-600/10 transition-all cursor-pointer flex items-center justify-center gap-1.5"
                          >
                            <Clock className="h-4 w-4" />
                            تسجيل الانصراف والخروج
                          </button>
                        )}
                      </div>

                      {/* Brief statistics */}
                      <div className="mt-4 pt-4 border-t border-gray-100 dark:border-slate-800/80">
                        <span className="text-[10px] text-gray-400 block mb-2 font-sans font-bold">ملخص حضورك العام:</span>
                        {(() => {
                          const studentRecords = attendance.filter(r => r.studentId === currentUser.id);
                          const totalDays = studentRecords.length;
                          const presentDays = studentRecords.filter(r => r.status === "PRESENT" || r.status === "LATE").length;
                          const absentDays = studentRecords.filter(r => r.status === "ABSENT").length;
                          const attendanceRate = totalDays > 0 ? Math.round((presentDays / totalDays) * 100) : 100;

                          return (
                            <div className="grid grid-cols-3 gap-1.5 text-center">
                              <div className="bg-emerald-50/40 p-2 rounded-lg border border-emerald-50/60">
                                <span className="text-[8px] text-emerald-600 block">أيام الحضور</span>
                                <span className="font-mono text-xs font-extrabold text-emerald-700">{presentDays}</span>
                              </div>
                              <div className="bg-red-50/40 p-2 rounded-lg border border-red-50/60">
                                <span className="text-[8px] text-red-600 block">أيام الغياب</span>
                                <span className="font-mono text-xs font-extrabold text-red-700">{absentDays}</span>
                              </div>
                              <div className="bg-blue-50/40 p-2 rounded-lg border border-blue-50/60">
                                <span className="text-[8px] text-blue-600 block">نسبة الالتزام</span>
                                <span className="font-mono text-xs font-extrabold text-blue-700">{attendanceRate}%</span>
                              </div>
                            </div>
                          );
                        })()}
                      </div>
                    </div>
                  );
                })()}
              </div>

              {/* Reminders list */}
              <div className="bg-white border border-gray-100 p-6 rounded-2xl shadow-sm">
                <h3 className="font-sans text-xs font-bold text-gray-900 mb-3 flex items-center justify-end gap-1.5">
                  التذكيرات والمواعيد القادمة
                  <AlertCircle className="h-4 w-4 text-amber-500" />
                </h3>
                <p className="font-sans text-[11px] text-gray-400 mb-4">واجبات واختبارات معلقة يجب عليك تسليمها لتجنب خسارة الدرجات</p>

                <div className="space-y-2">
                  {assignments.map((as) => {
                    const submitted = submissions.some(s => s.assignmentId === as.id);
                    if (submitted) return null;
                    return (
                      <div key={as.id} className="p-3 border border-amber-50 bg-amber-50/10 rounded-xl flex items-start gap-3 justify-between text-right">
                        <div className="flex-1">
                          <h4 className="font-sans text-xs font-bold text-gray-900 leading-tight">{as.title}</h4>
                          <span className="font-sans text-[9px] text-amber-600 font-medium block mt-1">تاريخ التسليم الأقصى: {as.dueDate}</span>
                        </div>
                        <button 
                          onClick={() => {
                            setActiveTab("assignments");
                            setSolvingAssignmentId(as.id);
                          }}
                          className="bg-white text-amber-700 hover:bg-amber-100 border border-amber-200 rounded-lg px-2.5 py-1 text-[10px] font-bold font-sans cursor-pointer whitespace-nowrap"
                        >
                          ابدأ الحل
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Study Strengths Radar Simulation */}
              <div className="bg-white border border-gray-100 p-6 rounded-2xl shadow-sm">
                <h3 className="font-sans text-xs font-bold text-gray-900 mb-4">تحليل المهارات ونقاط القوة</h3>
                <div className="space-y-2">
                  <div>
                    <div className="flex justify-between text-[11px] mb-1">
                      <span className="font-mono font-bold text-emerald-600">ممتاز</span>
                      <span className="font-sans text-gray-600">الفهم والتطبيق</span>
                    </div>
                    <div className="h-1.5 w-full bg-gray-50 rounded-full overflow-hidden">
                      <div className="h-full bg-emerald-500" style={{ width: "92%" }} />
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-[11px] mb-1">
                      <span className="font-mono font-bold text-indigo-600">جيد جداً</span>
                      <span className="font-sans text-gray-600">الحفظ وحصاد المصطلحات</span>
                    </div>
                    <div className="h-1.5 w-full bg-gray-50 rounded-full overflow-hidden">
                      <div className="h-full bg-indigo-500" style={{ width: "80%" }} />
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-[11px] mb-1">
                      <span className="font-mono font-bold text-amber-600">متوسط</span>
                      <span className="font-sans text-gray-600">سرعة حل الاختبارات القصيرة</span>
                    </div>
                    <div className="h-1.5 w-full bg-gray-50 rounded-full overflow-hidden">
                      <div className="h-full bg-amber-500" style={{ width: "65%" }} />
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      )}

      {/* CURRICULUM EXPLORATION TAB */}
      {activeTab === "curriculum" && (
        <div className="space-y-6" id="student-curriculum-view">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            
            {/* Subjects and Lessons sidebar selectors */}
            {!isReadingMode && (
              <div className="lg:col-span-1 bg-white border border-gray-100 p-4 rounded-2xl shadow-sm h-fit space-y-4">
              <h3 className="font-sans text-xs font-bold text-gray-900 border-b border-gray-50 pb-2">مناهجك الأكاديمية</h3>
              
              <div className="space-y-1">
                {subjects.map((sub) => {
                  const isSelected = selectedSubjectId === sub.id;
                  return (
                    <button
                      key={sub.id}
                      onClick={() => {
                        setSelectedSubjectId(sub.id);
                        setSelectedLessonId(null);
                      }}
                      className={`w-full text-right rounded-xl p-3 font-sans transition-all cursor-pointer ${isSelected ? 'bg-emerald-50 text-emerald-950 font-semibold border-r-4 border-emerald-600' : 'hover:bg-gray-50 text-gray-700'}`}
                    >
                      <span className="text-[9px] bg-emerald-100 text-emerald-800 px-1.5 py-0.2 rounded font-bold block w-fit mb-1">{sub.code}</span>
                      <span className="text-xs">{sub.name}</span>
                    </button>
                  );
                })}
              </div>

              {selectedSubjectId && (
                <div className="space-y-3 pt-3 border-t border-gray-50">
                  <h4 className="font-sans text-[11px] font-bold text-gray-900">الأبواب والدروس:</h4>
                  <div className="space-y-3">
                    {units.filter(u => u.subjectId === selectedSubjectId).map(u => (
                      <div key={u.id} className="space-y-1">
                        <span className="text-[10px] text-gray-400 font-bold block">{u.title}</span>
                        <div className="space-y-0.5 mr-2">
                          {lessons.filter(l => l.unitId === u.id).map(l => {
                            const isCompleted = completedLessonIds.includes(l.id);
                            const isSelected = selectedLessonId === l.id;
                            return (
                              <button
                                key={l.id}
                                onClick={() => setSelectedLessonId(l.id)}
                                className={`w-full text-right py-1.5 px-2 rounded font-sans text-xs flex items-center justify-between cursor-pointer ${isSelected ? 'bg-gray-100 text-emerald-700 font-semibold' : 'hover:bg-gray-50 text-gray-600'}`}
                              >
                                <span className="truncate">{l.title}</span>
                                {isCompleted && <CheckCircle className="h-3.5 w-3.5 text-emerald-600 shrink-0 mr-1" />}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              </div>
            )}

            {/* Lesson detail page display area */}
            <div className={isReadingMode ? "lg:col-span-4" : "lg:col-span-3"}>
              {selectedLessonId ? (() => {
                const activeLesson = lessons.find(l => l.id === selectedLessonId)!;
                const isCompleted = completedLessonIds.includes(activeLesson.id);

                return (
                  <div className={`transition-all duration-300 p-6 sm:p-8 space-y-6 text-right rounded-3xl border ${
                    isReadingMode
                      ? (readingTheme === "light" ? "bg-white border-gray-200 shadow-md" :
                         readingTheme === "sepia" ? "bg-[#FDF6E3] border-[#EADFC9] text-[#5c3e16] shadow-md" :
                         "bg-slate-900 border-slate-800 text-slate-100 shadow-md")
                      : "bg-white border border-gray-100 shadow-sm"
                  }`}>
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between border-b border-gray-50 pb-4 gap-3">
                      <div>
                        <span className={`text-[10px] font-bold block ${isReadingMode && readingTheme === "dark" ? "text-slate-400" : "text-gray-400"}`}>مادة الشرح والتحصيل</span>
                        <h3 className={`font-sans text-base sm:text-lg font-bold mt-1 ${
                          isReadingMode
                            ? (readingTheme === "light" ? "text-gray-900" :
                               readingTheme === "sepia" ? "text-[#5c3e16]" :
                               "text-white")
                            : "text-gray-900"
                        }`}>{activeLesson.title}</h3>
                        <p className={`font-sans text-[11px] mt-0.5 ${isReadingMode && readingTheme === "dark" ? "text-slate-400" : "text-gray-400"}`}>مدة المحاضرة المقدرة: {activeLesson.duration}</p>
                      </div>

                      <div className="flex flex-wrap items-center gap-2">
                        {/* Reading Mode Button */}
                        <button
                          onClick={() => setIsReadingMode(!isReadingMode)}
                          className={`font-sans text-xs font-bold px-4 py-2 rounded-xl transition-all border flex items-center gap-1.5 cursor-pointer ${
                            isReadingMode
                              ? 'bg-amber-600 text-white border-amber-600 hover:bg-amber-700'
                              : 'bg-indigo-50 text-indigo-700 border-indigo-200 hover:bg-indigo-100'
                          }`}
                        >
                          {isReadingMode ? (
                            <>
                              <Minimize2 className="h-4 w-4" />
                              خروج من وضع القراءة
                            </>
                          ) : (
                            <>
                              <Maximize2 className="h-4 w-4" />
                              وضع القراءة والتركيز
                            </>
                          )}
                        </button>

                        <button
                          onClick={() => {
                            onToggleLessonCompleted(activeLesson.id);
                            triggerToast(isCompleted ? "تم إلغاء علامة إكمال الدرس" : "تهانينا! أكملت الدرس وتم حساب التقدم العلمي.");
                          }}
                          className={`font-sans text-xs font-bold px-4 py-2 rounded-xl transition-all border cursor-pointer ${isCompleted ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-emerald-600 text-white border-emerald-600 hover:bg-emerald-700'}`}
                        >
                          {isCompleted ? "أكملت الدرس (اضغط للإلغاء)" : "تحديد كمكتمل ومقروء"}
                        </button>
                      </div>
                    </div>

                    {/* Reading Mode Control Strip */}
                    {isReadingMode && (
                      <div className={`p-4 rounded-xl border flex flex-wrap items-center justify-between gap-4 transition-all ${
                        readingTheme === "light" ? "bg-gray-50 border-gray-100 text-gray-700" :
                        readingTheme === "sepia" ? "bg-[#F5ECD5] border-[#E2D5B7] text-[#5c3e16]" :
                        "bg-slate-800 border-slate-700 text-slate-300"
                      }`}>
                        <div className="flex flex-wrap items-center gap-3">
                          <span className="text-xs font-bold font-sans">تنسيق القراءة والتركيز:</span>
                          
                          {/* Theme selectors */}
                          <div className="flex items-center gap-1 border-l border-gray-200/40 pl-3 ml-3">
                            <button
                              onClick={() => setReadingTheme("light")}
                              className={`px-3 py-1.5 text-[11px] font-bold rounded-lg border transition-all cursor-pointer ${
                                readingTheme === "light"
                                  ? "bg-white text-gray-900 border-gray-300 shadow-sm ring-2 ring-emerald-500/20"
                                  : "bg-white/40 text-gray-500 border-transparent hover:bg-white"
                              }`}
                            >
                              نهاراً (أبيض)
                            </button>
                            <button
                              onClick={() => setReadingTheme("sepia")}
                              className={`px-3 py-1.5 text-[11px] font-bold rounded-lg border transition-all cursor-pointer ${
                                readingTheme === "sepia"
                                  ? "bg-[#FDF6E3] text-[#5c3e16] border-[#EADFC9] shadow-sm ring-2 ring-amber-500/20"
                                  : "bg-[#FDF6E3]/40 text-[#5c3e16]/70 border-transparent hover:bg-[#FDF6E3]"
                              }`}
                            >
                              ورقي (دافئ)
                            </button>
                            <button
                              onClick={() => setReadingTheme("dark")}
                              className={`px-3 py-1.5 text-[11px] font-bold rounded-lg border transition-all cursor-pointer ${
                                readingTheme === "dark"
                                  ? "bg-slate-950 text-white border-slate-800 shadow-sm ring-2 ring-indigo-500/20"
                                  : "bg-slate-950/40 text-slate-400 border-transparent hover:bg-slate-950"
                              }`}
                            >
                              ليلاً (مظلم)
                            </button>
                          </div>

                          {/* Font Size selectors */}
                          <div className="flex items-center gap-1">
                            <span className="text-[11px] font-medium font-sans ml-1 text-gray-400 flex items-center gap-0.5">
                              <Type className="h-3.5 w-3.5" />
                              حجم الخط:
                            </span>
                            <button
                              onClick={() => setReadingFontSize("sm")}
                              className={`h-7 w-7 rounded-lg text-xs font-bold transition-all border cursor-pointer ${
                                readingFontSize === "sm" ? "bg-emerald-600 text-white border-emerald-600" : "bg-white text-gray-700 border-gray-200 hover:bg-gray-50"
                              }`}
                              title="صغير"
                            >
                              أ-
                            </button>
                            <button
                              onClick={() => setReadingFontSize("base")}
                              className={`h-7 w-7 rounded-lg text-xs font-bold transition-all border cursor-pointer ${
                                readingFontSize === "base" ? "bg-emerald-600 text-white border-emerald-600" : "bg-white text-gray-700 border-gray-200 hover:bg-gray-50"
                              }`}
                              title="متوسط"
                            >
                              أ
                            </button>
                            <button
                              onClick={() => setReadingFontSize("lg")}
                              className={`h-7 w-7 rounded-lg text-xs font-bold transition-all border cursor-pointer ${
                                readingFontSize === "lg" ? "bg-emerald-600 text-white border-emerald-600" : "bg-white text-gray-700 border-gray-200 hover:bg-gray-50"
                              }`}
                              title="كبير"
                            >
                              أ+
                            </button>
                            <button
                              onClick={() => setReadingFontSize("xl")}
                              className={`h-7 w-7 rounded-lg text-xs font-bold transition-all border cursor-pointer ${
                                readingFontSize === "xl" ? "bg-emerald-600 text-white border-emerald-600" : "bg-white text-gray-700 border-gray-200 hover:bg-gray-50"
                              }`}
                              title="كبير جداً"
                            >
                              أ++
                            </button>
                          </div>
                        </div>

                        <div className="text-[11px] font-sans font-bold text-emerald-600 flex items-center gap-1 bg-emerald-50 px-2 py-1 rounded-lg">
                          <Sparkles className="h-3 w-3" />
                          وضع التركيز نشط الآن
                        </div>
                      </div>
                    )}

                    {/* Responsive video player block */}
                    {activeLesson.videoUrl && (
                      <div className="space-y-2">
                        <h4 className="font-sans text-xs font-bold">شرح المحاضرة بالفيديو:</h4>
                        <div className="relative aspect-video rounded-2xl overflow-hidden border border-gray-150 shadow-sm bg-black">
                          <iframe
                            src={activeLesson.videoUrl}
                            title={activeLesson.title}
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowFullScreen
                            className="absolute inset-0 w-full h-full"
                          />
                        </div>
                      </div>
                    )}

                    {/* Rich text Markdown summary details block */}
                    <div className="space-y-2 border-t border-gray-50 pt-5">
                      <div className="flex justify-between items-center mb-2">
                        {activeLesson.pdfName && (
                          <a 
                            href="#" 
                            onClick={(e) => { e.preventDefault(); triggerToast("بدء تحميل ملف الكتيب PDF..."); }}
                            className="text-indigo-600 hover:text-indigo-800 text-[11px] font-sans font-bold flex items-center gap-1"
                          >
                            <FileText className="h-4 w-4" />
                            تحميل ملخص PDF ({activeLesson.pdfName})
                          </a>
                        )}
                        <h4 className="font-sans text-xs font-bold">الملخص والمادة العلمية المكتوبة:</h4>
                      </div>

                      <div className={`prose max-w-none text-right font-sans p-5 sm:p-8 rounded-2xl border transition-all duration-300 ${
                        isReadingMode
                          ? (readingTheme === "light" ? "bg-gray-50 border-gray-100 text-gray-800" :
                             readingTheme === "sepia" ? "bg-[#F5ECD5] border-[#E2D5B7] text-[#433422]" :
                             "bg-slate-800 border-slate-800 text-slate-200")
                          : "bg-gray-50/50 border border-gray-50 text-gray-700 text-xs leading-relaxed"
                      } ${
                        readingFontSize === "sm" ? "text-sm sm:text-base leading-relaxed" :
                        readingFontSize === "lg" ? "text-lg sm:text-xl leading-loose" :
                        readingFontSize === "xl" ? "text-xl sm:text-2xl leading-loose" :
                        "text-base sm:text-lg leading-relaxed" // base
                      } space-y-5`}>
                        {activeLesson.content.split("\n\n").map((para, pIdx) => {
                          if (para.startsWith("###")) {
                            return (
                              <h4 
                                key={pIdx} 
                                className={`font-bold mt-6 border-r-4 pr-3 ${
                                  isReadingMode
                                    ? (readingTheme === "light" ? "text-emerald-950 border-emerald-500 text-lg sm:text-xl" :
                                       readingTheme === "sepia" ? "text-[#5c3e16] border-amber-600 text-lg sm:text-xl" :
                                       "text-emerald-400 border-emerald-500 text-lg sm:text-xl")
                                    : "text-emerald-950 border-emerald-500 text-sm"
                                }`}
                              >
                                {para.replace("###", "").trim()}
                              </h4>
                            );
                          }
                          if (para.startsWith("####")) {
                            return (
                              <h5 
                                key={pIdx} 
                                className={`font-bold mt-4 ${
                                  isReadingMode
                                    ? (readingTheme === "light" ? "text-gray-900 text-base" :
                                       readingTheme === "sepia" ? "text-[#5c3e16] text-base" :
                                       "text-slate-200 text-base")
                                    : "text-gray-900 text-xs"
                                }`}
                              >
                                {para.replace("####", "").trim()}
                              </h5>
                            );
                          }
                          return <p key={pIdx} className="leading-relaxed sm:leading-loose">{para}</p>;
                        })}
                      </div>
                    </div>

                  </div>
                );
              })() : (
                <div className="bg-white border border-gray-150 border-dashed rounded-3xl p-12 text-center">
                  <BookOpen className="h-12 w-12 text-gray-300 mx-auto mb-3" />
                  <h4 className="font-sans text-sm font-bold text-gray-700">مستودع المناهج التعليمية</h4>
                  <p className="font-sans text-xs text-gray-400 mt-1 max-w-md mx-auto">
                    اختر مادة دراسية من القائمة اليمنى ثم اختر الدرس المطلوب لتصفح ملخص الشرح وتنزيل الملفات ومشاهدة الفيديو التعليمي المرفق.
                  </p>
                </div>
              )}
            </div>

          </div>
        </div>
      )}

      {/* ASSIGNMENTS SUBMISSION TAB */}
      {activeTab === "assignments" && (
        <div className="max-w-4xl mx-auto space-y-6">
          {solvingAssignmentId ? (() => {
            const activeAssign = assignments.find(a => a.id === solvingAssignmentId)!;
            return (
              <div className="bg-white border border-emerald-100 rounded-3xl shadow-xl p-6 text-right space-y-6">
                <div className="border-b border-gray-100 pb-3">
                  <span className="text-[10px] text-emerald-600 font-bold block">إجراء الواجب الدراسي المنزلي</span>
                  <h3 className="font-sans text-sm font-bold text-gray-900 mt-1">{activeAssign.title}</h3>
                  <p className="font-sans text-xs text-gray-400">{activeAssign.description}</p>
                </div>

                <div className="space-y-6">
                  {activeAssign.questions.map((q, idx) => (
                    <div key={q.id} className="bg-gray-50 rounded-2xl p-5 border border-gray-100 space-y-3">
                      <p className="font-sans text-xs font-bold text-gray-800">السؤال {idx + 1}: {q.questionText}</p>
                      
                      {q.type === "MULTIPLE_CHOICE" ? (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-2">
                          {q.options?.map((opt, optIdx) => {
                            const isSelected = assignmentAnswers[q.id] === opt;
                            return (
                              <button
                                key={optIdx}
                                type="button"
                                onClick={() => handleAnswerAssignment(q.id, opt)}
                                className={`text-right rounded-xl px-4 py-2.5 text-xs font-sans transition-all cursor-pointer border ${isSelected ? 'bg-emerald-600 text-white border-emerald-600' : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50'}`}
                              >
                                {opt}
                              </button>
                            );
                          })}
                        </div>
                      ) : (
                        <div className="pt-2 relative">
                          <textarea
                            placeholder="اكتب إجابتك الرياضية أو الفيزيائية المفصلة هنا مع توضيح الخطوات والوحدات..."
                            value={assignmentAnswers[q.id] || ""}
                            onChange={(e) => handleAnswerAssignment(q.id, e.target.value)}
                            rows={3}
                            className="w-full bg-white border border-gray-200 rounded-xl p-3 pl-12 text-right text-xs"
                          />
                          <div className="absolute left-2.5 bottom-2.5">
                            <VoiceInputButton 
                              onTranscript={(transcript) => {
                                const current = assignmentAnswers[q.id] || "";
                                handleAnswerAssignment(q.id, current ? `${current} ${transcript}` : transcript);
                              }}
                              size="sm"
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                <div className="flex gap-3 justify-end pt-4 border-t border-gray-100">
                  <button
                    onClick={() => handleSendAssignment(activeAssign.id)}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white font-sans text-xs font-bold px-6 py-2.5 rounded-xl cursor-pointer"
                  >
                    تسليم الواجب الآن
                  </button>
                  <button
                    onClick={() => setSolvingAssignmentId(null)}
                    className="bg-gray-100 hover:bg-gray-200 text-gray-600 font-sans text-xs px-4 py-2.5 rounded-xl cursor-pointer"
                  >
                    إلغاء والتراجع
                  </button>
                </div>
              </div>
            );
          })() : (
            <div className="bg-white border border-gray-100 p-6 rounded-2xl shadow-sm">
              <h3 className="font-sans text-xs font-bold text-gray-900 mb-4">الواجبات الدراسية المتاحة</h3>
              
              <div className="space-y-3">
                {assignments.map((as) => {
                  const sub = submissions.find(s => s.assignmentId === as.id);
                  const isGraded = sub?.status === "GRADED";

                  return (
                    <div key={as.id} className="p-4 border border-gray-50 rounded-xl hover:bg-gray-50/50 flex flex-col sm:flex-row sm:items-center justify-between text-right gap-3">
                      <div>
                        <h4 className="font-sans text-xs font-bold text-gray-900">{as.title}</h4>
                        <span className="text-[10px] text-gray-400 block mt-1">تاريخ التسليم: {as.dueDate}</span>
                      </div>

                      <div className="flex gap-2 items-center justify-end">
                        {sub ? (
                          <div className="text-left">
                            <span className={`inline-block px-2.5 py-0.5 rounded-full text-[9px] font-bold ${isGraded ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>
                              {isGraded ? `تم التقييم: ${sub.grade}/100` : "بانتظار تصحيح المعلم"}
                            </span>
                            {isGraded && sub.feedback && (
                              <p className="text-[10px] text-gray-400 mt-1 italic max-w-xs truncate">"{sub.feedback}"</p>
                            )}
                          </div>
                        ) : (
                          <button
                            onClick={() => setSolvingAssignmentId(as.id)}
                            className="bg-emerald-600 hover:bg-emerald-700 text-white font-sans text-xs font-semibold px-4 py-1.5 rounded-xl transition-colors cursor-pointer"
                          >
                            تقديم الحل الآن
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* QUIZZES TAB */}
      {activeTab === "quizzes" && (
        <div className="max-w-4xl mx-auto space-y-6">
          {solvingQuizId ? (() => {
            const quiz = quizzes.find(q => q.id === solvingQuizId)!;
            const currentAttempt = attempts.find(at => at.quizId === quiz.id);

            return (
              <div className="bg-white border border-emerald-100 rounded-3xl shadow-xl p-6 text-right space-y-6">
                <div className="border-b border-gray-100 pb-3 flex justify-between items-center">
                  <div className="font-mono text-xs bg-red-50 text-red-600 px-2.5 py-1 rounded-lg flex items-center gap-1 font-semibold">
                    <Clock className="h-4 w-4" />
                    الوقت المقدر: {quiz.durationMinutes} دقيقة
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-emerald-600 font-bold block">اختبار تفاعلي قصير</span>
                    <h3 className="font-sans text-sm font-bold text-gray-900 mt-1">{quiz.title}</h3>
                  </div>
                </div>

                {!quizSubmitted ? (
                  <div className="space-y-6">
                    {quiz.questions.map((q, idx) => (
                      <div key={q.id} className="bg-gray-50 rounded-2xl p-5 border border-gray-100 space-y-3">
                        <p className="font-sans text-xs font-bold text-gray-800">{idx + 1}. {q.questionText}</p>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {q.options.map((opt, optIdx) => {
                            const isSelected = quizAnswers[q.id] === optIdx;
                            return (
                              <button
                                key={optIdx}
                                type="button"
                                onClick={() => handleSelectQuizOption(q.id, optIdx)}
                                className={`text-right rounded-xl px-4 py-2 text-xs font-sans transition-all cursor-pointer border ${isSelected ? 'bg-emerald-600 text-white border-emerald-600' : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50'}`}
                              >
                                {opt}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    ))}

                    <div className="flex gap-2 justify-end pt-3">
                      <button
                        onClick={() => handleSendQuiz(quiz)}
                        className="bg-emerald-600 hover:bg-emerald-700 text-white font-sans text-xs font-bold px-6 py-2.5 rounded-xl cursor-pointer"
                      >
                        إنهاء وتسليم الاختبار القصير
                      </button>
                      <button
                        onClick={() => setSolvingQuizId(null)}
                        className="bg-gray-100 text-gray-600 font-sans text-xs px-4 py-2.5 rounded-xl cursor-pointer"
                      >
                        إلغاء
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-6 text-center py-6">
                    <div className="h-20 w-20 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto mb-2 shadow-inner">
                      <Award className="h-10 w-10 animate-bounce" />
                    </div>
                    <div>
                      <h4 className="font-sans text-base font-bold text-gray-900">أحسنت تسليم الاختبار بنجاح!</h4>
                      <p className="font-sans text-xs text-gray-400 mt-1">حصلت على تقييم فوري بنسبة:</p>
                      <span className="font-mono text-3xl font-extrabold text-emerald-600 block mt-2">{quizScore}%</span>
                    </div>

                    <div className="text-right border-t border-gray-100 pt-5 space-y-4 max-w-2xl mx-auto">
                      <h5 className="font-sans text-xs font-bold text-gray-900 mb-2">مراجعة الإجابات والتفسيرات العلمية:</h5>
                      {quiz.questions.map((q, idx) => {
                        const selectedOptIdx = quizAnswers[q.id];
                        const isCorrect = selectedOptIdx === q.correctAnswerIndex;
                        return (
                          <div key={q.id} className={`p-4 rounded-xl border ${isCorrect ? 'border-emerald-100 bg-emerald-50/10' : 'border-red-100 bg-red-50/10'} text-xs font-sans space-y-2`}>
                            <p className="font-bold text-gray-800">{idx + 1}. {q.questionText}</p>
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between text-[11px] text-gray-600 mt-1 gap-1">
                              <span>إجابتك: <strong className={isCorrect ? "text-emerald-700" : "text-red-700"}>{q.options[selectedOptIdx] || "(لم يجب)"}</strong></span>
                              <span>الإجابة الصحيحة: <strong className="text-emerald-700">{q.options[q.correctAnswerIndex]}</strong></span>
                            </div>
                            <p className="text-[10px] text-gray-400 italic bg-white p-2 rounded border border-gray-50 leading-relaxed mt-2">
                              💡 <strong>التفسير العلمي:</strong> {q.explanation}
                            </p>
                          </div>
                        );
                      })}
                    </div>

                    <button
                      onClick={() => setSolvingQuizId(null)}
                      className="bg-emerald-600 hover:bg-emerald-700 text-white font-sans text-xs font-bold px-6 py-2.5 rounded-xl cursor-pointer mt-4"
                    >
                      العودة للرئيسية
                    </button>
                  </div>
                )}
              </div>
            );
          })() : (
            <div className="bg-white border border-gray-100 p-6 rounded-2xl shadow-sm">
              <h3 className="font-sans text-xs font-bold text-gray-900 mb-4">الاختبارات الدورية وقصيرة المدى المتاحة</h3>
              <div className="space-y-3">
                {quizzes.map((q) => {
                  const attempt = attempts.find(at => at.quizId === q.id);
                  return (
                    <div key={q.id} className="p-4 border border-gray-50 rounded-xl hover:bg-gray-50/50 flex items-center justify-between text-right">
                      <div>
                        <h4 className="font-sans text-xs font-bold text-gray-900">{q.title}</h4>
                        <span className="text-[10px] text-gray-400 block mt-1">زمن الاختبار: {q.durationMinutes} دقائق | عدد الأسئلة: {q.questions.length} أسئلة</span>
                      </div>

                      <div>
                        {attempt ? (
                          <div className="text-left">
                            <span className="font-mono text-xs font-bold text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-lg">درجتك: {attempt.score}%</span>
                            <span className="text-[9px] text-gray-400 block mt-1">اكتملت المحاولة</span>
                          </div>
                        ) : (
                          <button
                            onClick={() => handleStartQuiz(q.id)}
                            className="bg-emerald-600 hover:bg-emerald-700 text-white font-sans text-xs font-semibold px-4 py-1.5 rounded-xl transition-colors cursor-pointer"
                          >
                            بدء تقديم الاختبار
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* DISCUSSION FORUM TAB */}
      {activeTab === "forum" && (
        <div className="max-w-4xl mx-auto space-y-6">
          
          {/* Post creation form */}
          <div className="bg-white border border-gray-100 p-5 rounded-2xl shadow-sm text-right space-y-4">
            <h3 className="font-sans text-xs font-bold text-gray-900 flex items-center justify-end gap-1.5">
              اطرح سؤالاً علمياً جديداً للأساتذة
              <HelpCircle className="h-4 w-4 text-emerald-600" />
            </h3>

            <form onSubmit={handleCreateForumPost} className="space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] text-gray-400 mb-1">المادة ذات العلاقة بسؤالك</label>
                  <select
                    value={newPostSubjId}
                    onChange={(e) => setNewPostSubjId(e.target.value)}
                    className="w-full bg-gray-50 border border-gray-200 rounded-lg p-1.5 text-right text-xs font-sans"
                  >
                    <option value="">-- اختر مادة --</option>
                    {subjects.map(s => (
                      <option key={s.id} value={s.id}>{s.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] text-gray-400 mb-1">عنوان موجز وجذاب للسؤال</label>
                  <input 
                    type="text"
                    placeholder="مثال: استفسار بخصوص توصيل الفولتميتر"
                    value={newPostTitle}
                    onChange={(e) => setNewPostTitle(e.target.value)}
                    className="w-full bg-gray-50 border border-gray-200 rounded-lg px-3 py-1.5 text-right text-xs"
                  />
                </div>
              </div>
              <div>
                <label className="block text-[10px] text-gray-400 mb-1">شرح مفصل للاستفسار أو المشكلة الأكاديمية</label>
                <div className="relative">
                  <textarea 
                    placeholder="اكتب كل التفاصيل أو الرموز والمسائل الرياضية التي تحتاج المساعدة في حلها..."
                    value={newPostContent}
                    onChange={(e) => setNewPostContent(e.target.value)}
                    rows={2}
                    className="w-full bg-gray-50 border border-gray-200 rounded-lg p-2 pl-12 text-right text-xs"
                  />
                  <div className="absolute left-2.5 bottom-2">
                    <VoiceInputButton 
                      onTranscript={(transcript) => {
                        setNewPostContent(prev => prev ? `${prev} ${transcript}` : transcript);
                      }}
                      size="sm"
                    />
                  </div>
                </div>
              </div>
              <button type="submit" className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-sans text-xs font-bold py-2 rounded-xl transition-colors cursor-pointer">
                طرح السؤال فوراً بالمنتدى
              </button>
            </form>
          </div>

          {/* Posts feed */}
          <div className="space-y-4">
            {posts.map((post) => {
              const sub = subjects.find(s => s.id === post.subjectId);
              return (
                <div key={post.id} className="bg-white border border-gray-100 rounded-2xl p-5 space-y-4 text-right shadow-sm">
                  <div className="flex items-center justify-between border-b border-gray-50 pb-2">
                    <span className="text-[10px] text-gray-400 font-mono">{new Date(post.createdAt).toLocaleDateString("ar-EG")}</span>
                    <div>
                      <span className="text-[9px] bg-emerald-50 text-emerald-600 font-bold px-2 py-0.5 rounded-full">{sub?.name}</span>
                      <h4 className="font-bold text-xs text-gray-900 mt-1">{post.title}</h4>
                      <p className="text-[10px] text-gray-400">بواسطة: {post.authorName} ({post.authorRole === UserRole.TEACHER ? "معلم" : "طالب"})</p>
                    </div>
                  </div>

                  <p className="text-xs text-gray-700 leading-relaxed font-sans">{post.content}</p>

                  {/* Replies list */}
                  <div className="space-y-2.5 mr-3 border-r-2 border-emerald-100 pr-3 mt-3">
                    {post.replies.map((rep) => (
                      <div key={rep.id} className="bg-gray-50 p-2.5 rounded-xl border border-gray-100 text-xs text-right">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-[9px] text-gray-400 font-mono">{new Date(rep.createdAt).toLocaleDateString("ar-EG")}</span>
                          <span className="font-semibold text-gray-800 text-[11px]">{rep.authorName} ({rep.authorRole === UserRole.TEACHER ? "معلم" : "طالب"})</span>
                        </div>
                        <p className="text-[11px] text-gray-600 leading-relaxed">{rep.content}</p>
                      </div>
                    ))}
                  </div>

                  {/* Post a reply */}
                  <div className="flex gap-2 items-center pt-3 border-t border-gray-50">
                    <div className="relative flex-1">
                      <input 
                        type="text"
                        placeholder="اكتب تعليقك أو إضافتك هنا..."
                        value={replyText[post.id] || ""}
                        onChange={(e) => setReplyText({ ...replyText, [post.id]: e.target.value })}
                        onKeyDown={(e) => e.key === "Enter" && handleSendReply(post.id)}
                        className="w-full bg-gray-50 border border-gray-200 rounded-lg pr-3 pl-12 py-1.5 text-xs focus:outline-none text-right"
                      />
                      <div className="absolute left-2.5 top-1/2 -translate-y-1/2">
                        <VoiceInputButton 
                          onTranscript={(transcript) => {
                            const current = replyText[post.id] || "";
                            setReplyText({ ...replyText, [post.id]: current ? `${current} ${transcript}` : transcript });
                          }}
                          size="sm"
                        />
                      </div>
                    </div>
                    <button 
                      onClick={() => handleSendReply(post.id)}
                      className="bg-emerald-600 hover:bg-emerald-700 text-white font-sans text-xs font-bold px-4 py-1.5 rounded-lg transition-colors cursor-pointer"
                    >
                      إرسال الرد
                    </button>
                  </div>

                </div>
              );
            })}
          </div>

        </div>
      )}

      {/* LIBRARY & GLOSSARY TAB */}
      {activeTab === "library" && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* Reference materials list */}
          <div className="bg-white border border-gray-100 p-6 rounded-2xl shadow-sm space-y-4 text-right">
            <h3 className="font-sans text-xs font-bold text-gray-900 border-b border-gray-50 pb-2 flex items-center justify-end gap-1.5">
              مكتبة الكتب والمراجع الإضافية
              <BookMarked className="h-4 w-4 text-emerald-600" />
            </h3>

            <div className="space-y-3">
              {resources.map((res) => (
                <div key={res.id} className="p-3 border border-gray-50 rounded-xl hover:bg-gray-50/50 flex justify-between items-start text-right">
                  <div className="flex-1">
                    <span className="text-[9px] bg-amber-50 text-amber-700 font-bold px-2 py-0.2 rounded inline-block mb-1">
                      {res.type === "BOOK" ? "مرجع PDF" : res.type === "VIDEO" ? "فيديو" : "رابط خارجي"}
                    </span>
                    <h4 className="font-sans text-xs font-bold text-gray-900 leading-snug">{res.title}</h4>
                    <p className="text-[10px] text-gray-400 mt-1 leading-relaxed">{res.description}</p>
                  </div>
                  <a href={res.url} target="_blank" rel="noopener noreferrer" className="text-emerald-600 hover:text-emerald-800 p-1">
                    <ExternalLink className="h-4 w-4" />
                  </a>
                </div>
              ))}
            </div>
          </div>

          {/* Scientific terms glossary lookup */}
          <div className="bg-white border border-gray-100 p-6 rounded-2xl shadow-sm space-y-4 text-right">
            <h3 className="font-sans text-xs font-bold text-gray-900 border-b border-gray-50 pb-2 flex items-center justify-end gap-1.5">
              المعجم والمصطلحات المنهجية
              <BookOpen className="h-4 w-4 text-emerald-600" />
            </h3>

            <div className="space-y-3 max-h-96 overflow-y-auto pr-1">
              {glossary.map((term) => (
                <div key={term.id} className="p-3 bg-gray-50/50 border border-gray-50 rounded-xl">
                  <h4 className="font-sans text-xs font-bold text-emerald-950">{term.term}</h4>
                  <p className="text-[10px] text-gray-500 mt-1 leading-relaxed">{term.definition}</p>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

    </div>
  );
};
