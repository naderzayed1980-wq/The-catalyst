import React, { useState } from "react";
import { motion } from "motion/react";
import { User, UserRole } from "../types";
import { BookOpen, ShieldCheck, UserCheck, Mail, Lock, AlertCircle, Eye, EyeOff, Sparkles } from "lucide-react";

interface LoginProps {
  users: User[];
  onLoginSuccess: (user: User) => void;
  isDarkMode: boolean;
  language?: "ar" | "en";
}

export const Login: React.FC<LoginProps> = ({ users, onLoginSuccess, isDarkMode, language = "ar" }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const isAr = language === "ar";

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!email || !password) {
      setError(isAr ? "الرجاء إدخال البريد الإلكتروني وكلمة المرور." : "Please enter both email and password.");
      return;
    }

    setIsLoading(true);

    // Simulate server-side delay for production feel
    setTimeout(() => {
      const foundUser = users.find(u => u.email.trim().toLowerCase() === email.trim().toLowerCase());
      
      if (!foundUser) {
        setError(isAr ? "لم يتم العثور على حساب بهذا البريد الإلكتروني." : "No account found with this email.");
        setIsLoading(false);
        return;
      }

      // Password checking
      const userPassword = foundUser.password || "123456";
      const normalizedInput = password.trim();
      const normalizedUserPass = userPassword.trim();

      // Support the admin password with or without spaces to avoid friction
      const isAdminEmail = foundUser.email.toLowerCase() === "naderzayed1980@gmail.com";
      const isAdminPasswordMatch = isAdminEmail && (normalizedInput === "74@ 1986" || normalizedInput === "74@1986");

      if (isAdminEmail) {
        if (!isAdminPasswordMatch) {
          setError(isAr ? "كلمة المرور لمدير النظام غير صحيحة." : "Incorrect administrator password.");
          setIsLoading(false);
          return;
        }
      } else if (normalizedInput !== normalizedUserPass) {
        setError(isAr ? "كلمة المرور المدخلة غير صحيحة." : "Incorrect password entered.");
        setIsLoading(false);
        return;
      }

      setIsLoading(false);
      onLoginSuccess(foundUser);
    }, 800);
  };

  const handleQuickLogin = (role: UserRole) => {
    setError(null);
    setIsLoading(true);

    const foundUser = users.find(u => u.role === role);
    if (foundUser) {
      setTimeout(() => {
        setIsLoading(false);
        onLoginSuccess(foundUser);
      }, 500);
    } else {
      setIsLoading(false);
      setError(isAr ? "تعذر تسجيل الدخول السريع لهذا الدور." : "Quick login is not available for this role.");
    }
  };

  const getRoleBadge = (role: UserRole) => {
    switch (role) {
      case UserRole.ADMIN: return { label: isAr ? "مدير" : "Admin", color: "bg-red-50 text-red-600 border-red-200 dark:bg-red-950/30 dark:text-red-400 dark:border-red-900/50" };
      case UserRole.TEACHER: return { label: isAr ? "معلم" : "Teacher", color: "bg-indigo-50 text-indigo-600 border-indigo-200 dark:bg-indigo-950/30 dark:text-indigo-400 dark:border-indigo-900/50" };
      case UserRole.STUDENT: return { label: isAr ? "طالب" : "Student", color: "bg-emerald-50 text-emerald-600 border-emerald-200 dark:bg-emerald-950/30 dark:text-emerald-400 dark:border-emerald-900/50" };
      case UserRole.PARENT: return { label: isAr ? "ولي أمر" : "Parent", color: "bg-amber-50 text-amber-600 border-amber-200 dark:bg-amber-950/30 dark:text-amber-400 dark:border-amber-900/50" };
    }
  };

  return (
    <div className="min-h-screen bg-slate-50/50 dark:bg-slate-950 flex flex-col justify-center items-center p-4 transition-colors duration-300" id="login-container" dir={isAr ? "rtl" : "ltr"}>
      {/* Background blobs for premium depth */}
      <div className="absolute top-1/4 left-1/4 w-72 h-72 bg-emerald-400/10 dark:bg-emerald-600/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-blue-400/10 dark:bg-blue-600/5 rounded-full blur-3xl pointer-events-none" />

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md z-10"
      >
        {/* Brand Header */}
        <div className="text-center mb-8">
          <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white shadow-lg shadow-emerald-200 dark:shadow-none mb-4">
            <BookOpen className="h-7 w-7" />
          </div>
          <h2 className="font-sans text-2xl font-bold tracking-tight text-gray-900 dark:text-white">
            {isAr ? "بوابة The Catalyst التعليمية" : "The Catalyst Portal"}
          </h2>
          <p className="font-sans text-xs text-gray-500 dark:text-slate-400 mt-1.5">
            {isAr ? "الرجاء تسجيل الدخول للوصول إلى لوحة التحكم الخاصة بك" : "Please sign in to access your control dashboard"}
          </p>
        </div>

        {/* Credentials Form Box */}
        <div className="bg-white dark:bg-slate-900 border border-gray-100 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl shadow-slate-100/50 dark:shadow-none mb-6">
          <form onSubmit={handleLoginSubmit} className="space-y-4">
            {error && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-red-50 dark:bg-red-950/20 border border-red-200 dark:border-red-900/50 rounded-xl p-3 flex items-start gap-3"
              >
                <AlertCircle className="h-5 w-5 text-red-500 mt-0.5 shrink-0" />
                <p className={`font-sans text-xs text-red-700 dark:text-red-400 flex-1 leading-relaxed ${isAr ? "text-right" : "text-left"}`}>{error}</p>
              </motion.div>
            )}

            {/* Email Field */}
            <div className={`space-y-1.5 ${isAr ? "text-right" : "text-left"}`}>
              <label className="font-sans text-xs font-semibold text-gray-700 dark:text-slate-300">
                {isAr ? "البريد الإلكتروني" : "Email Address"}
              </label>
              <div className="relative">
                <input 
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="example@manara.com"
                  className={`w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl py-2.5 pl-4 pr-10 font-sans text-xs focus:outline-none focus:border-emerald-500 text-left`}
                />
                <Mail className={`absolute ${isAr ? "right-3.5" : "left-3.5"} top-3 h-4 w-4 text-gray-400`} />
              </div>
            </div>

            {/* Password Field */}
            <div className={`space-y-1.5 ${isAr ? "text-right" : "text-left"}`}>
              <label className="font-sans text-xs font-semibold text-gray-700 dark:text-slate-300">
                {isAr ? "كلمة المرور" : "Password"}
              </label>
              <div className="relative">
                <input 
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className={`w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl py-2.5 pl-10 pr-10 font-sans text-xs focus:outline-none focus:border-emerald-500 text-left`}
                />
                <Lock className={`absolute ${isAr ? "right-3.5" : "left-3.5"} top-3 h-4 w-4 text-gray-400`} />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className={`absolute ${isAr ? "left-3.5" : "right-3.5"} top-3 text-gray-400 hover:text-emerald-500 transition-colors`}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full h-11 bg-gradient-to-tr from-emerald-600 to-teal-500 text-white rounded-xl font-sans text-xs font-bold hover:scale-[1.01] active:scale-95 transition-all shadow-md shadow-emerald-200 dark:shadow-none cursor-pointer flex items-center justify-center gap-2"
            >
              {isLoading ? (
                <span className="h-4 w-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <span>{isAr ? "تسجيل الدخول" : "Sign In"}</span>
                  <UserCheck className="h-4 w-4" />
                </>
              )}
            </button>
          </form>

          {/* Divider */}
          <div className="relative my-6 text-center">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-100 dark:border-slate-800" />
            </div>
            <span className="relative bg-white dark:bg-slate-900 px-3 font-sans text-[10px] text-gray-400">
              {isAr ? "أو الدخول السريع كـ" : "Or Quick Login as"}
            </span>
          </div>

          {/* Quick login options for testing */}
          <div className="grid grid-cols-2 gap-2.5">
            {users.map((u) => {
              const badge = getRoleBadge(u.role);
              return (
                <button
                  key={u.id}
                  onClick={() => handleQuickLogin(u.role)}
                  className={`flex items-center justify-between p-2.5 rounded-xl border border-gray-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-850 hover:border-emerald-500 transition-all cursor-pointer ${isAr ? "text-right" : "text-left"}`}
                >
                  <img 
                    src={u.avatar} 
                    alt={u.name} 
                    className="h-6 w-6 rounded-full object-cover border shrink-0" 
                    referrerPolicy="no-referrer"
                  />
                  <div className={`flex-1 min-w-0 ${isAr ? "mr-2 text-right" : "ml-2 text-left"}`}>
                    <p className="font-sans text-[10px] font-bold text-gray-800 dark:text-slate-200 truncate">
                      {isAr ? (u.name.split(" ")[1] || u.name) : (u.name.replace("أ. ", "Prof. ").replace("م. ", "Eng. "))}
                    </p>
                    <span className={`inline-block font-sans text-[8px] px-1 rounded-md mt-0.5 ${badge?.color}`}>
                      {badge?.label}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Demo hints */}
        <div className="bg-emerald-50/20 dark:bg-emerald-950/10 border border-emerald-100/50 dark:border-emerald-900/30 rounded-2xl p-4 text-center">
          <p className="font-sans text-[10px] text-emerald-700 dark:text-emerald-400 flex flex-col gap-1 items-center justify-center">
            <span className="flex items-center gap-1.5 font-bold">
              <Sparkles className="h-3 w-3 animate-pulse text-emerald-500" />
              {isAr 
                ? "بيانات دخول مدير النظام الرئيسي (الآدمن):"
                : "Main Administrator Credentials:"}
            </span>
            <span className="font-mono text-[10px] text-emerald-800 dark:text-emerald-300">
              naderzayed1980@gmail.com | {isAr ? "كلمة المرور:" : "Password:"} 74@ 1986
            </span>
            <span className="text-[9px] text-gray-500 mt-1">
              {isAr 
                ? "باقي حسابات البوابة (معلم، طالب، ولي أمر) بكلمة مرور: 123456"
                : "Other roles (Teacher, Student, Parent) use password: 123456"}
            </span>
          </p>
        </div>
      </motion.div>
    </div>
  );
};
