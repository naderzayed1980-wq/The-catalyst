import React from "react";
import { 
  User as UserIcon, 
  TrendingUp, 
  CheckCircle, 
  AlertCircle, 
  ClipboardList, 
  Award, 
  MessageSquare, 
  BookOpen, 
  Smartphone,
  ChevronLeft,
  Clock
} from "lucide-react";
import { 
  User, 
  Subject, 
  Lesson, 
  Assignment, 
  AssignmentSubmission, 
  QuizAttempt,
  Course,
  AttendanceRecord
} from "../types";

interface ParentDashboardProps {
  currentUser: User;
  students: User[];
  subjects: Subject[];
  lessons: Lesson[];
  assignments: Assignment[];
  submissions: AssignmentSubmission[];
  attempts: QuizAttempt[];
  completedLessonIds: string[];
  courses: Course[];
  attendance: AttendanceRecord[];
  onOpenDirectChat: (teacherId: string) => void;
}

export const ParentDashboard: React.FC<ParentDashboardProps> = ({
  currentUser,
  students,
  subjects,
  lessons,
  assignments,
  submissions,
  attempts,
  completedLessonIds,
  courses,
  attendance,
  onOpenDirectChat
}) => {
  // Find child linked to this parent
  const child = students.find(s => currentUser.childrenIds?.includes(s.id));

  if (!child) {
    return (
      <div className="py-12 text-center bg-white border border-gray-150 rounded-2xl font-sans" dir="rtl">
        <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-3" />
        <h3 className="font-bold text-gray-900 text-sm">خطأ: لم يتم ربط أي حسابات طلاب بحسابك كأب</h3>
        <p className="text-gray-400 text-xs mt-1">يرجى مراجعة إدارة مركز The Catalyst لتأكيد الربط الأبوي للهوية.</p>
      </div>
    );
  }

  // Child statistics calculations
  const childSubmissions = submissions.filter(s => s.studentId === child.id);
  const childAttempts = attempts.filter(a => a.studentId === child.id);
  
  const childCompletedLessons = lessons.filter(l => completedLessonIds.includes(l.id));
  const childProgressPct = lessons.length > 0 
    ? Math.round((childCompletedLessons.length / lessons.length) * 100) 
    : 0;

  const childAvgGrade = childSubmissions.filter(s => s.status === "GRADED").length > 0
    ? Math.round(childSubmissions.filter(s => s.status === "GRADED").reduce((acc, curr) => acc + (curr.grade || 0), 0) / childSubmissions.filter(s => s.status === "GRADED").length)
    : 85; // Fallback simulation

  const childQuizAvg = childAttempts.length > 0
    ? Math.round(childAttempts.reduce((acc, curr) => acc + curr.score, 0) / childAttempts.length)
    : 100;

  return (
    <div className="py-6 font-sans text-right" dir="rtl" id="parent-dashboard-container">
      
      {/* Visual greeting and child card */}
      <div className="bg-gradient-to-l from-amber-900 to-slate-900 rounded-3xl p-6 text-white mb-6 border border-amber-950 flex flex-col md:flex-row items-center justify-between gap-6 shadow-md">
        <div className="text-right">
          <span className="bg-white/10 text-amber-300 border border-white/10 px-2.5 py-0.5 rounded-full text-[10px] font-bold">حساب ولي الأمر</span>
          <h2 className="font-sans text-lg font-bold mt-2">مرحباً بك يا {currentUser.name} 🌾</h2>
          <p className="font-sans text-xs text-amber-100 mt-1">تتابع حالياً الملف الدراسي والتحصيل الأكاديمي لابنك: <strong>{child.name}</strong></p>
        </div>

        <div className="flex gap-4">
          <div className="bg-white/5 border border-white/5 rounded-2xl px-5 py-3.5 text-center">
            <span className="text-[10px] text-amber-300 block mb-0.5">درجة الواجبات</span>
            <span className="font-mono text-xl font-bold text-white">{childAvgGrade}%</span>
          </div>
          <div className="bg-white/5 border border-white/5 rounded-2xl px-5 py-3.5 text-center">
            <span className="text-[10px] text-amber-300 block mb-0.5">مستوى الاختبارات</span>
            <span className="font-mono text-xl font-bold text-white">{childQuizAvg}%</span>
          </div>
          <div className="bg-white/5 border border-white/5 rounded-2xl px-5 py-3.5 text-center">
            <span className="text-[10px] text-amber-300 block mb-0.5">الدروس المنجزة</span>
            <span className="font-mono text-xl font-bold text-white">{childCompletedLessons.length}</span>
          </div>
        </div>
      </div>

      {/* Student Course Enrolment Catalog (Parent View) */}
      {courses.length > 0 && (
        <div className="bg-white border border-gray-100 rounded-3xl p-6 mb-6 shadow-sm">
          <h3 className="font-sans text-xs font-bold text-gray-950 mb-3 flex items-center gap-2 justify-end">
            <Award className="h-4 w-4 text-amber-600" />
            البرامج والمسارات الأكاديمية المسجل بها ابنك
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-right">
            {courses.map((crs) => {
              const crsSubjects = subjects.filter(s => crs.subjectIds.includes(s.id));
              return (
                <div key={crs.id} className="bg-gray-50/40 border border-gray-50 p-4 rounded-2xl flex flex-col justify-between">
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-1.5">
                      <span className="font-mono text-[9px] bg-amber-50 text-amber-700 px-2 py-0.5 rounded-lg border border-amber-100 font-bold">
                        {crs.code}
                      </span>
                      <h4 className="font-sans text-xs font-bold text-gray-900">{crs.name}</h4>
                    </div>
                    <p className="font-sans text-[11px] text-gray-500 line-clamp-2 mt-1 leading-relaxed mb-3">
                      {crs.description || "مسار دراسي متكامل مخصص لرفع تحصيل الطالب الدراسي وتمكينه أكاديمياً."}
                    </p>
                  </div>

                  <div className="space-y-1 pt-2 border-t border-gray-100/60">
                    <span className="block font-sans text-[9px] font-bold text-gray-400">مقررات البرنامج المعتمدة:</span>
                    <div className="flex flex-wrap gap-1">
                      {crsSubjects.length === 0 ? (
                        <span className="font-sans text-[9px] text-gray-400 bg-white px-2 py-0.5 rounded border border-gray-100">غير محدد</span>
                      ) : (
                        crsSubjects.map(s => (
                          <span key={s.id} className="font-sans text-[10px] bg-white text-gray-700 border border-gray-150 px-2 py-0.5 rounded-lg">
                            {s.name}
                          </span>
                        ))
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Progress bars of each subject */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white border border-gray-100 p-6 rounded-2xl shadow-sm space-y-4">
            <h3 className="font-sans text-xs font-bold text-gray-900">معدلات إكمال ابنك للمقررات والدروس</h3>
            <p className="font-sans text-[11px] text-gray-400">تحديث فوري عند نقر الابن على علامة إكمال الدروس داخل صفحته</p>

            <div className="space-y-4">
              {subjects.map((sub) => {
                const subLessons = lessons.filter(l => l.subjectId === sub.id);
                const subCompleted = subLessons.filter(l => completedLessonIds.includes(l.id));
                const pct = subLessons.length > 0 ? Math.round((subCompleted.length / subLessons.length) * 100) : 0;

                return (
                  <div key={sub.id} className="border border-gray-50 rounded-xl p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-mono text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">{pct}% إنجاز</span>
                      <h4 className="font-sans text-xs font-bold text-gray-900">{sub.name}</h4>
                    </div>
                    <div className="h-2 w-full bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full bg-emerald-500 rounded-full" style={{ width: `${pct}%` }} />
                    </div>
                    <span className="font-sans text-[10px] text-gray-400 mt-2 block">أكمل {subCompleted.length} من أصل {subLessons.length} دروس مسجلة</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Child homework submissions details */}
          <div className="bg-white border border-gray-100 p-6 rounded-2xl shadow-sm space-y-4">
            <h3 className="font-sans text-xs font-bold text-gray-900">تقرير تسليم الواجبات والتقييم الذاتي</h3>
            
            <div className="space-y-3">
              {assignments.map((as) => {
                const sub = submissions.find(s => s.assignmentId === as.id && s.studentId === child.id);
                return (
                  <div key={as.id} className="p-4 border border-gray-50 rounded-xl flex items-center justify-between text-right">
                    <div>
                      <h4 className="font-sans text-xs font-bold text-gray-900 leading-snug">{as.title}</h4>
                      <span className="font-sans text-[9px] text-gray-400 block mt-1">تاريخ التسليم: {as.dueDate}</span>
                    </div>

                    <div>
                      {sub ? (
                        <div className="text-left font-sans">
                          <span className={`inline-block px-2.5 py-0.5 rounded-full text-[9px] font-bold ${sub.status === "GRADED" ? "bg-emerald-50 text-emerald-600" : "bg-amber-50 text-amber-600"}`}>
                            {sub.status === "GRADED" ? `تم التصحيح: ${sub.grade}/100` : "بانتظار تقييم المعلم"}
                          </span>
                          {sub.feedback && (
                            <p className="text-[10px] text-gray-400 italic max-w-xs truncate mt-1">"{sub.feedback}"</p>
                          )}
                        </div>
                      ) : (
                        <span className="font-sans text-[10px] text-red-500 bg-red-50 border border-red-100 px-2.5 py-1 rounded-xl font-bold flex items-center gap-1">
                          <AlertCircle className="h-3.5 w-3.5" />
                          لم يُسلّم بعد
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Side panel: smart reminders, communication with teachers */}
        <div className="space-y-6">
          
          {/* Child Attendance & Daily Safety Tracker */}
          <div className="bg-white border border-gray-100 p-6 rounded-2xl shadow-sm text-right space-y-4">
            <h3 className="font-sans text-xs font-bold text-gray-950 flex items-center justify-end gap-1.5">
              رصد حضور وسلامة الابن اليومي
              <Clock className="h-4 w-4 text-emerald-600" />
            </h3>
            <p className="font-sans text-[11px] text-gray-400">تابع وقت وصول وانصراف ابنك لتطمئن على تواجده الأكاديمي والتعليمي في الوقت المحدد.</p>

            {(() => {
              const childRecords = attendance.filter(r => r.studentId === child.id);
              const totalDays = childRecords.length;
              const presentDays = childRecords.filter(r => r.status === "PRESENT").length;
              const lateDays = childRecords.filter(r => r.status === "LATE").length;
              const absentDays = childRecords.filter(r => r.status === "ABSENT").length;
              const rate = totalDays > 0 ? Math.round(((presentDays + lateDays) / totalDays) * 100) : 100;

              const getTodayDateString = () => {
                const d = new Date();
                const year = d.getFullYear();
                const month = String(d.getMonth() + 1).padStart(2, "0");
                const day = String(d.getDate()).padStart(2, "0");
                return `${year}-${month}-${day}`;
              };
              const todayDate = getTodayDateString();
              const todayRecord = childRecords.find(r => r.date === todayDate);

              return (
                <div className="space-y-4 font-sans text-xs">
                  {/* Today Status Alert Banner */}
                  <div className="bg-gray-50/50 border border-gray-100 p-3.5 rounded-xl text-center">
                    <span className="text-[10px] text-gray-400 block mb-1">حالة الحضور لليوم ({todayDate}):</span>
                    {todayRecord ? (
                      todayRecord.status === "PRESENT" ? (
                        <div className="space-y-1.5">
                          <span className="inline-block bg-emerald-50 text-emerald-700 border border-emerald-100 px-3 py-1 rounded-full text-xs font-bold font-sans">
                            ✓ متواجد بالمؤسسة (حاضر)
                          </span>
                          <div className="grid grid-cols-2 gap-2 text-right mt-2 pt-2 border-t border-gray-100">
                            <div className="text-center">
                              <span className="text-[9px] text-gray-400 block">انصرف في تمام</span>
                              <span className="font-mono text-xs font-bold text-gray-700">{todayRecord.checkOutTime || "لم ينصرف بعد"}</span>
                            </div>
                            <div className="text-center border-l border-gray-100">
                              <span className="text-[9px] text-gray-400 block">وصل في تمام</span>
                              <span className="font-mono text-xs font-bold text-gray-700">{todayRecord.checkInTime || "غير محدد"}</span>
                            </div>
                          </div>
                        </div>
                      ) : todayRecord.status === "LATE" ? (
                        <div className="space-y-1.5">
                          <span className="inline-block bg-amber-50 text-amber-700 border border-amber-100 px-3 py-1 rounded-full text-xs font-bold font-sans">
                            ⏱ متواجد متأخر
                          </span>
                          <div className="grid grid-cols-2 gap-2 text-right mt-2 pt-2 border-t border-gray-100">
                            <div className="text-center">
                              <span className="text-[9px] text-gray-400 block">انصرف في تمام</span>
                              <span className="font-mono text-xs font-bold text-gray-700">{todayRecord.checkOutTime || "لم ينصرف بعد"}</span>
                            </div>
                            <div className="text-center border-l border-gray-100">
                              <span className="text-[9px] text-gray-400 block">وصل في تمام</span>
                              <span className="font-mono text-xs font-bold text-amber-700">{todayRecord.checkInTime || "متأخر"}</span>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="p-1 text-center space-y-1">
                          <span className="inline-block bg-red-100 text-red-700 border border-red-200 px-3 py-1 rounded-full text-xs font-extrabold font-sans animate-pulse">
                            🚨 غائب اليوم
                          </span>
                          <p className="text-[10px] text-red-500 font-bold mt-1.5">انتبه: تم تسجيل ابنك غائباً اليوم من قبل المعلم المشرف.</p>
                        </div>
                      )
                    ) : (
                      <span className="inline-block bg-gray-50 text-gray-400 border border-gray-150 px-3 py-1 rounded-full text-xs font-bold font-sans">
                        ⏳ بانتظار بدء تسجيل الحضور
                      </span>
                    )}
                  </div>

                  {/* Attendance Rate Progress bar */}
                  <div className="space-y-1.5">
                    <div className="flex justify-between items-center text-[10px] text-gray-500 font-bold">
                      <span className="font-mono text-emerald-600">{rate}% ملتزم</span>
                      <span>معدل الالتزام بالحضور</span>
                    </div>
                    <div className="h-2 w-full bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full bg-emerald-500" style={{ width: `${rate}%` }} />
                    </div>
                  </div>

                  {/* Fast counters */}
                  <div className="grid grid-cols-3 gap-2 text-center pt-2">
                    <div className="bg-emerald-50/50 p-2 rounded-xl border border-emerald-50/60">
                      <span className="text-[8px] text-emerald-600 block font-bold">أيام الحضور</span>
                      <span className="font-mono text-xs font-extrabold text-emerald-700">{presentDays + lateDays}</span>
                    </div>
                    <div className="bg-amber-50/50 p-2 rounded-xl border border-amber-50/60">
                      <span className="text-[8px] text-amber-600 block font-bold">مرات التأخير</span>
                      <span className="font-mono text-xs font-extrabold text-amber-700">{lateDays}</span>
                    </div>
                    <div className="bg-red-50/50 p-2 rounded-xl border border-red-50/60">
                      <span className="text-[8px] text-red-600 block font-bold">أيام الغياب</span>
                      <span className="font-mono text-xs font-extrabold text-red-700">{absentDays}</span>
                    </div>
                  </div>

                  {/* Historic Attendance Log list */}
                  <div className="pt-3 border-t border-gray-100">
                    <span className="text-[10px] text-gray-400 block mb-2 font-bold font-sans">سجل الأيام السابقة:</span>
                    {childRecords.length === 0 ? (
                      <p className="text-center text-[9px] text-gray-400">لا يوجد سجلات حضور سابقة مسجلة.</p>
                    ) : (
                      <div className="space-y-1.5 max-h-[140px] overflow-y-auto pr-1">
                        {childRecords.slice(-5).reverse().map((rec, rIdx) => (
                          <div key={rIdx} className="flex items-center justify-between p-2 border border-gray-50/60 rounded-lg hover:bg-gray-50/30 text-[10px]">
                            <span className={`font-bold ${rec.status === 'PRESENT' ? 'text-emerald-600' : rec.status === 'LATE' ? 'text-amber-600' : 'text-red-500'}`}>
                              {rec.status === 'PRESENT' ? 'حاضر' : rec.status === 'LATE' ? 'متأخر' : 'غائب'}
                            </span>
                            <span className="text-gray-400 font-mono text-[9px]">{rec.checkInTime ? `${rec.checkInTime} - ${rec.checkOutTime || "—"}` : "—"}</span>
                            <span className="text-gray-700 font-mono font-bold">{rec.date}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                </div>
              );
            })()}
          </div>

          {/* Smart behavioral reminders */}
          <div className="bg-white border border-gray-100 p-6 rounded-2xl shadow-sm text-right space-y-4">
            <h3 className="font-sans text-xs font-bold text-gray-900 flex items-center justify-end gap-1.5">
              تذكيرات سلوكية ذكية للابن
              <AlertCircle className="h-4 w-4 text-amber-500" />
            </h3>
            <p className="font-sans text-[11px] text-gray-400">تساعدك هذه التنبيهات على تحفيز ابنك لدراسة الأبواب المتبقية في جدول هذا الأسبوع</p>

            <div className="space-y-2 text-xs font-sans">
              {assignments.some(as => !submissions.some(s => s.assignmentId === as.id && s.studentId === child.id)) ? (
                <div className="p-3 bg-amber-50/20 border border-amber-100 rounded-xl flex items-start gap-3">
                  <AlertCircle className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <h5 className="font-bold text-amber-950">واجبات دراسية معلقة!</h5>
                    <p className="text-[10px] text-amber-800 mt-0.5 leading-relaxed">يرجى تذكير الابن بضرورة تقديم حلول واجبي مادة الفيزياء والرياضيات لتجنب تراجع النقاط.</p>
                  </div>
                </div>
              ) : (
                <div className="p-3 bg-emerald-50/20 border border-emerald-100 rounded-xl flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-emerald-600 shrink-0 mt-0.5" />
                  <div>
                    <h5 className="font-bold text-emerald-950">إنجاز رائع ومبهر!</h5>
                    <p className="text-[10px] text-emerald-800 mt-0.5 leading-relaxed">أكمل الابن يوسف كافة الفروض والمسائل المقررة لهذا الأسبوع في موعدها!</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Quick hotline to teachers */}
          <div className="bg-white border border-gray-100 p-6 rounded-2xl shadow-sm text-right space-y-4">
            <h3 className="font-sans text-xs font-bold text-gray-900">تواصل سريع مع معلمي الابن</h3>
            <p className="font-sans text-[11px] text-gray-400">يمكنك النقر على زر المراسلة لبدء شات آمن وخاص ومباشر مع معلّمي المواد لمتابعة ابنك</p>

            <div className="space-y-2 font-sans text-xs">
              {subjects.map((sub) => (
                <div key={sub.id} className="flex items-center justify-between p-3 border border-gray-50 rounded-xl hover:bg-gray-50/50">
                  <button 
                    onClick={() => onOpenDirectChat(sub.teacherId)}
                    className="bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded-lg px-3 py-1 font-bold font-sans text-[10px] cursor-pointer"
                  >
                    مراسلة المعلم
                  </button>
                  <div className="text-right">
                    <span className="font-bold text-gray-800 block">أستاذ المادة ({sub.code})</span>
                    <span className="text-[10px] text-gray-400 block mt-0.5">{sub.name}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
